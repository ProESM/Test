﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.ServiceBroker.Models
{
    public class CalculationInfo
    {
        public long Id { get; set; }
        public DateTime CalculationStart { get; set; }
        public int Status { get; set; }
        public int? TimeZone { get; set; }
    }
}
