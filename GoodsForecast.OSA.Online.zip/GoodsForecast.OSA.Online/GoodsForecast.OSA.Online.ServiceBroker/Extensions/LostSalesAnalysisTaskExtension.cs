﻿using AutoMapper;
using GoodsForecast.OSA.Online.Common.Forecasting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.ServiceBroker.Extensions
{
    /// <summary>
    /// Формирование батчей по задачам
    /// </summary>
    public static class LostSalesAnalysisTaskExtension
    {
        public static Dictionary<int, Dictionary<int, IEnumerable<Suspect>>> ToSuspectBatch(this IEnumerable<LostSalesAnalysisTaskViewModel> tasks, IMapper _mapper)
        {
            var suspects = tasks.GroupBy(t => t.LocationId)
                .ToDictionary(l => l.Key,
                    g =>
                        g.GroupBy(t => t.ProductId)
                            .ToDictionary(p => p.Key,
                                s =>
                                    s.Select(c => _mapper.Map<Suspect>(c))));

            return suspects;
        }
    }
}
