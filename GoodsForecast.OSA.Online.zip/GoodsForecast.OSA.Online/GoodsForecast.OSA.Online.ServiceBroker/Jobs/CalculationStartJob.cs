﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Quartz;
using System;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Repositories;
using System.Linq;
using AutoMapper;
using System.Collections.Generic;
using GoodsForecast.OSA.Online.ServiceBroker.Extensions;
using System.Diagnostics;
using GoodsForecast.OSA.Online.Common.Messaging.Messages.ForecastMessages;

namespace GoodsForecast.OSA.Online.ServiceBroker.Jobs
{
    /// <summary>
    /// Обработка задания на расчет
    /// </summary>
    public class CalculationStartJob : IJob, IServiceJob
    {
        private readonly OsaLogger<CalculationStartJob> _logger;
        private IConfiguration _config;
        private IServiceProvider _serviceProvider;
        private readonly IBus _bus;
        private readonly IBrokerRepository _repository;
        private readonly IMapper _mapper;

        public CalculationStartJob(
            OsaLogger<CalculationStartJob> logger,
            IConfiguration configuration,
            IServiceProvider serviceProvider,
            IBus bus,
            IBrokerRepository repository,
            IMapper mapper
            )
        {
            _logger = logger;
            _config = configuration;
            _serviceProvider = serviceProvider;
            _bus = bus;
            _repository = repository;
            _mapper = mapper;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            int jobSheduleId = 0;
            try
            {
                _logger.LogInformation(Environment.MachineName, $"Запущен {nameof(CalculationStartJob)}...");

                jobSheduleId = context.JobDetail.JobDataMap.GetIntValue(nameof(CalculationStartJob));

                await _bus.SendReceive.SendAsync(
                   nameof(QueueName.BrokerToBroker),
                   new StartForecastMessage
                   {
                       JobScheduleId = jobSheduleId,
                       RestartCount = 0
                   });

            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(CalculationStartJob)}. Произошла ошибка во время запуска расчета по расписанию jobSheduleId = {jobSheduleId}.", ex);

                await _bus.SendReceive.SendAsync(
                    nameof(QueueName.BrokerToMessenger),
                    new BrokerToMessengerMessage
                    {
                        Body = $"Произошла ошибка во время запуска расчета по расписанию jobSheduleId = {jobSheduleId}. \nТекст ошибки: {ex}",
                        Priority = System.Net.Mail.MailPriority.High,
                        Subject = "Ошибка запуска расчета"
                    });
            }

            _logger.LogInformation(Environment.MachineName, $"{nameof(CalculationStartJob)} Завершает работу");
        }

        public Task Execute()
        {
            throw new NotImplementedException();
        }          
    }
}
