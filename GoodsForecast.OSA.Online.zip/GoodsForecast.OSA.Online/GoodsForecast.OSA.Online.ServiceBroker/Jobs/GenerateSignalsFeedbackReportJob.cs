﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Quartz;
using System;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages.ReportsMessages;

namespace GoodsForecast.OSA.Online.ServiceBroker.Jobs
{
    /// <summary>
    /// Обработка задания по генерации отчета по сигналам
    /// </summary>
    public class GenerateSignalsFeedbackReportJob : IJob, IServiceJob
    {
        private readonly OsaLogger<GenerateSignalsFeedbackReportJob> _logger;
        private IConfiguration _config;
        private IServiceProvider _serviceProvider;
        private readonly IBus _bus;
        private readonly IBrokerRepository _repository;

        public GenerateSignalsFeedbackReportJob(
            OsaLogger<GenerateSignalsFeedbackReportJob> logger,
            IConfiguration configuration,
            IServiceProvider serviceProvider,
            IBus bus,
            IBrokerRepository repository)
        {
            _logger = logger;
            _config = configuration;
            _serviceProvider = serviceProvider;
            _bus = bus;
            _repository = repository;
        }

        public async Task Execute(IJobExecutionContext context)
        {
            Job Job = null;
            try
            {
                _logger.LogInformation(Environment.MachineName, $"Запущен {nameof(GenerateSignalsFeedbackReportJob)}...");

                using var serviceScope = _serviceProvider.CreateScope();

                //Создаем джоб
                Job = new Job()
                {
                    Status = 1,
                    StartDate = DateTime.Now,
                    JobScheduleId = context.JobDetail.JobDataMap.GetIntValue(nameof(GenerateSignalsFeedbackReportJob))
                };

                //Добавляем/Обновляем в БД
                await _repository.UpdateJob(Job);

                //Отправляем в очередь
                await _bus.SendReceive.SendAsync(nameof(QueueName.BrokerToReporter), new DailySignalsReportMessage()
                {
                    JobId = Job.Id,
                });

                _logger.LogInformation(Environment.MachineName, $"Получена обратная связь по сигналам", Job.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка в  {nameof(GenerateSignalsFeedbackReportJob)}", ex, Job.Id);
            }

            _logger.LogInformation(Environment.MachineName, $"{nameof(GenerateSignalsFeedbackReportJob)} завершает работу");
        }

        public Task Execute()
        {
            throw new NotImplementedException();
        }
    }
}
