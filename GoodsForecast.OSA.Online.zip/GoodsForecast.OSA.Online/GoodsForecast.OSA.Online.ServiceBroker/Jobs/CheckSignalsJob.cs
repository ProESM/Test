﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Messaging;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Quartz;
using System;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using System.Text;
using System.Linq;
using GoodsForecast.OSA.Online.ServiceBroker.Models;

namespace GoodsForecast.OSA.Online.ServiceBroker.Jobs
{
    /// <summary>
    /// Обработка задания по генерации отчета
    /// </summary>
    public class CheckSignalsJob : IJob, IServiceJob
    {
        private readonly OsaLogger<CheckSignalsJob> _logger;
        private IConfiguration _config;
        private IServiceProvider _serviceProvider;
        private readonly IBus _bus;
        private readonly IBrokerRepository _repository;

        public CheckSignalsJob(
            OsaLogger<CheckSignalsJob> logger,
            IConfiguration configuration,
            IServiceProvider serviceProvider,
            IBus bus,
            IBrokerRepository repository)
        {
            _logger = logger;
            _config = configuration;
            _serviceProvider = serviceProvider;
            _bus = bus;
            _repository = repository;
        }


        public async Task Execute(IJobExecutionContext context)
        {
            Job Job = null;
            try
            {
                _logger.LogInformation(Environment.MachineName, $"Запущен {nameof(CheckSignalsJob)}...");

                using var serviceScope = _serviceProvider.CreateScope();

                //Создаем джоб
                Job = new Job()
                {
                    Status = 1,
                    StartDate = DateTime.Now,
                    JobScheduleId = context.JobDetail.JobDataMap.GetIntValue(nameof(CheckSignalsJob))
                };

                //Добовляем/Обновляем в БД
                await _repository.UpdateJob(Job);

                //Получаем список непосчитанных сигналов с email'ами для рассылки
                var emptySignals = await _repository.GetEmptySignals();

                //Получаем дефолтных получателей
                var defaultRecepients = await _repository.GetRecepients(nameof(CheckSignalsJob));

                if (emptySignals.Count > 0)
                {
                    foreach (var signal in emptySignals)
                    {
                        StringBuilder emailMessage = new StringBuilder("Следующие сигналы не были рассчитаны:");
                        emailMessage.Append("<br/>");
                        emailMessage.Append(signal.Description);

                        signal.Recepients.AddRange(defaultRecepients);

                        //Отправляем в очередь
                        await _bus.SendReceive.SendAsync(nameof(QueueName.BrokerToMessenger), new BrokerToMessengerMessage()
                        {
                            JobId = Job.Id,
                            Priority = System.Net.Mail.MailPriority.High,
                            Body = emailMessage.ToString(),
                            Subject = "Не выполнился расчет",
                            Recipients = signal.Recepients
                        });

                    }
                    _logger.LogInformation(Environment.MachineName, $"Отправлено оповещение об отсутствии сигналов", Job.Id);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка в  {nameof(CheckSignalsJob)}", ex, Job.Id);
            }

            _logger.LogInformation(Environment.MachineName, $"{nameof(CheckSignalsJob)} завершает работу");
        }

        public Task Execute()
        {
            throw new NotImplementedException();
        }

    }
}
