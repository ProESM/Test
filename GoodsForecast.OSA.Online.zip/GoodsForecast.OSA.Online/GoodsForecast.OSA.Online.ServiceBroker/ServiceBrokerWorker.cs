using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.ServiceBroker.Jobs;
using GoodsForecast.OSA.Online.ServiceBroker.Repositories;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Quartz;
using Quartz.Spi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.ServiceBroker
{
    /// <summary>
    /// Занимается первоначальной маршрутизацией всех данных и запросов
    /// </summary>
    public class ServiceBrokerWorker : BackgroundService
    {
        private readonly OsaLogger _logger;
        private readonly IServiceProvider _services;
        private readonly IBus _bus;
        private readonly IJobFactory _jobFactory;
        private readonly Quartz.IScheduler _scheduler;
        private readonly IBrokerRepository _jobRepository;
        private readonly IEnumerable<IQueueMessageHandler> _handlers;


        public ServiceBrokerWorker(
            OsaLogger<ServiceBrokerWorker> logger,
            IServiceProvider services,
            IBus bus,
            ISchedulerFactory schedulerFactory,
            IJobFactory jobFactory,
            IBrokerRepository jobRepository,
            IEnumerable<IQueueMessageHandler> handlers)
        {
            _logger = logger;
            _services = services;
            _bus = bus;
            _handlers = handlers;
            _jobFactory = jobFactory;
            _scheduler = schedulerFactory.GetScheduler().Result;
            _scheduler.JobFactory = _jobFactory;
            _jobRepository = jobRepository;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                _logger.LogInformation(Environment.MachineName, "ServiceBroker запущен");

                using (var scope = _services.CreateScope())
                {
                    foreach (var handler in _handlers)
                    {
                        await handler.Register();
                    }

                    var jobTypes = new List<Type>()
                    {
                        typeof(CalculationStartJob),
                        typeof(GenerateReportJob),
                        typeof(CheckSignalsJob),
                        typeof(GenerateSignalsFeedbackReportJob)
                    };

                    //Получаем список расписаний из репозитория
                    var jobsSсhedules = await _jobRepository.GetJobSchedules();

                    //Для каждого джоба задаем расписание
                    foreach (var jobType in jobTypes)
                    {
                        var schedules = jobsSсhedules.Where(x => x.JobName == jobType.Name).ToList();

                        //Если такого джоба нет, то выводим сообщение об ошибке
                        if (schedules == null || schedules.Count == 0)
                        {
                            _logger.LogError($"Ошибка в ServiceBroker. {jobType.Name} отсутствует в БД", null);
                        }
                        else
                        {
                            foreach (var jobSchedule in schedules)
                            {
                                var schedule = new JobSchedule(jobType, jobSchedule.CronExpression);
                                var job = CreateJob(schedule, jobSchedule.ScheduleId);
                                var trigger = CreateTrigger(schedule, jobSchedule.ScheduleId);

                                await _scheduler.ScheduleJob(job, trigger, stoppingToken);
                            }
                        }
                    }

                    await _scheduler.Start(stoppingToken);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, "Ошибка в ServiceBroker", ex);
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "ServiceBroker завершает работу");
            await Task.CompletedTask;
        }

        private static IJobDetail CreateJob(JobSchedule schedule, int scheduleId)
        {
            var jobType = schedule.JobType;
            return JobBuilder
                .Create(jobType)
                .WithIdentity($"{jobType.FullName}_{scheduleId}")
                .WithDescription(jobType.Name)
                .UsingJobData(jobType.Name, scheduleId)
                .Build();
        }

        private static ITrigger CreateTrigger(JobSchedule schedule, int scheduleId)
        {
            return TriggerBuilder
                .Create()
                .WithIdentity($"{schedule.JobType.FullName}_{scheduleId}.trigger")
                .WithCronSchedule(schedule.CronExpression)
                .WithDescription(schedule.CronExpression)
                .Build();
        }

        public override void Dispose()
        {
            _scheduler.Clear();
            _scheduler.Shutdown();
            _bus.Dispose();
            base.Dispose();
        }
    }
}
