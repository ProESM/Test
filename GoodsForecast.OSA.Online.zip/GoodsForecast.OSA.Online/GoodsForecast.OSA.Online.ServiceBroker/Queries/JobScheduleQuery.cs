﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.ServiceBroker.Queries
{
    public class JobScheduleQuery
    {
        public int ScheduleId { get; set; }
        public string JobName { get; set; }
        public string CronExpression { get; set; }
    }
}
