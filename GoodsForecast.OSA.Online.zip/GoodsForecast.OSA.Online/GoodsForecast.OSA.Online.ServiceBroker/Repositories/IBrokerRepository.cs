﻿using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Models;
using GoodsForecast.OSA.Online.ServiceBroker.Queries;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Reports;

namespace GoodsForecast.OSA.Online.ServiceBroker.Repositories
{
    /// <summary>
    /// Получение данных для брокера
    /// </summary>
    public interface IBrokerRepository
    {

        /// <summary>
        /// Расписания задач
        /// </summary>
        /// <returns></returns>
        Task<List<JobScheduleQuery>> GetJobSchedules();


        /// <summary>
        /// Создать/обновить джоб
        /// </summary>
        /// <param name="job"></param>
        Task UpdateJob(Job job);

        /// <summary>
        /// Сохранение файла отчета 
        /// </summary>
        /// <param name="report"></param>
        Task AddReport(ReportHistory report);

        /// <summary>
        /// Обновить джоб по расчету
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task UpdateLostSalesAnalisysJob(LostSalesAnalysisJob job);

        /// <summary>
        /// Получить дату анализа периода
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task<DateTime> GetAnilizeDate(long jobId);

        /// <summary>
        /// Получить инфу о расчете
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<CalculationInfo> GetCalculateInfo(long id);

        /// <summary>
        /// Подготовить параметры
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task PrepareParams(long jobId);

        /// <summary>
        /// Откат части расчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="stage"></param>
        /// <returns></returns>
        Task RollbackCalculate(long jobId, byte stage);

        /// <summary>
        /// Заполнить задания на расчет
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task FillTasks(long jobId);

        /// <summary>
        /// Разделить батчи на пачки с заданным размером
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task SplitBatches(long jobId);

        /// <summary>
        /// Получить джоб по идентификатору
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        Task<LostSalesAnalysisJob> GetLostSalesAnalysisJobs(long jobId);

        /// <summary>
        /// Переместить расчет в историю
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task MoveToHistory(long jobId);

        /// <summary>
        /// Перенести сигналы
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        Task JobResultsProceed(long jobId, long? subJobId = null, long? batchId = null, long? subBatchId = null);

        /// <summary>
        /// Получить тип рассылки
        /// </summary>
        /// <param name="notificationType"></param>
        /// <returns></returns>
        Task<Notification> GetNotification(string notificationType);

        /// <summary>
        /// Получить джоб с заданиями на расчет
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        Task<List<LostSalesAnalysisTaskViewModel>> GetLostSalesAnalysisJobTasks(long jobId);

        /// <summary>
        /// Получение параметра по названию
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        Task<string> GetParam(string paramName);

        /// <summary>
        /// Проверка необходимости перемещения в историю
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        Task<bool> NeedMoveToHistory(long jobId);

        /// <summary>
        /// Получить список отсутствующих сигналов
        /// </summary>
        /// <returns></returns>
        Task<List<UncalculatedSignal>> GetEmptySignals();

        /// <summary>
        /// Получить список адресов для отправки сообщения об ошибке
        /// </summary>
        /// <returns></returns>
        Task<List<string>> GetRecepients(string type);
    }
}
