﻿using GoodsForecast.OSA.Online.Data;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Jobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GoodsForecast.OSA.Online.ServiceBroker.Queries;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.ServiceBroker.Models;
using AutoMapper;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Reports;

namespace GoodsForecast.OSA.Online.ServiceBroker.Repositories
{
    /// <summary>
    /// Получение данных для брокера
    /// </summary>
    public class BrokerRepository : IBrokerRepository
    {
        private readonly OsaLogger<BrokerRepository> _logger;
        IServiceScopeFactory _serviceScopeFactory;

        public BrokerRepository(OsaLogger<BrokerRepository> logger,
                             IServiceScopeFactory serviceScopeFactory,
                             IMapper mapper)
        {
            _logger = logger;
            _serviceScopeFactory = serviceScopeFactory;
        }

        /// <summary>
        /// Получение расписаний
        /// </summary>
        /// <returns></returns>
        public async Task<List<JobScheduleQuery>> GetJobSchedules()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return await context.JobSchedules.Where(s => s.IsActive)
                        .Select(schedule => new JobScheduleQuery()
                        {
                            ScheduleId = schedule.Id,
                            JobName = schedule.JobType,
                            CronExpression = schedule.CronExpression
                        })
                        .ToListAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Произошла ошибка при получении расписаний {nameof(GetJobSchedules)}", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение списка шедуллеров
        /// </summary>
        /// <returns></returns>
        public async Task<List<Data.Entities.JobSchedule>> GetSсhedules()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return await context.JobSchedules.ToListAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При получении шедулеров произошла ошибка в BrokerRepository {nameof(GetSсhedules)}", ex);
                throw;
            }
        }

        /// <summary>
        /// Обновление/добавление джоба
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task UpdateJob(Job job)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var existingJob = context.Jobs.FirstOrDefault(x => x.Id == job.Id);
                    if (existingJob == null)
                        context.Jobs.Add(job);
                    else
                    {
                        existingJob.JobScheduleId = job.JobScheduleId;
                        existingJob.StartDate = job.StartDate;
                        existingJob.Status = job.Status;
                        existingJob.EndDate = job.EndDate;
                        context.Jobs.Update(existingJob);
                    }
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При добавлении джоба произошла ошибка в BrokerRepository {nameof(UpdateJob)}", ex, job.Id);
                throw;
            }
        }

        /// <summary>
        /// Добавление нового отчета
        /// </summary>
        /// <param name="report"></param>
        /// <returns></returns>
        public async Task AddReport(ReportHistory report)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    context.ReportHistory.Add(report);
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При добавлении файла отчета произошла ошибка в BrokerRepository {nameof(AddReport)}", ex);
                throw;
            }
        }

        /// <summary>
        /// Обновить джоб по расчету
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task UpdateLostSalesAnalisysJob(LostSalesAnalysisJob job)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var existingJob = context.LostSalesAnalysisJobs.FirstOrDefault(j => j.JobId == job.JobId);
                    if (existingJob == null)
                        context.LostSalesAnalysisJobs.Add(job);
                    else
                    {
                        existingJob.Status = job.Status;
                        existingJob.Created = job.Created;
                        existingJob.FilledJobResults = job.FilledJobResults;
                        existingJob.FilledTasks = job.FilledTasks;
                        existingJob.JobPreparedParams = job.JobPreparedParams;
                        existingJob.JobResultsProceed = job.JobResultsProceed;
                        existingJob.MovedToHistory = job.MovedToHistory;
                        context.LostSalesAnalysisJobs.Update(existingJob);

                        var parentJob = context.Jobs.FirstOrDefault(j => j.Id == job.JobId);
                        if (parentJob != null)
                        {
                            parentJob.Status = job.Status;
                            if (job.MovedToHistory != null)
                                parentJob.EndDate = DateTime.Now;
                            context.Jobs.Update(parentJob);
                        }
                    }

                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при обновлении LostSalesAnalysisJobs  {nameof(UpdateLostSalesAnalisysJob)}", ex, job.JobId);
                throw;
            }
        }

        /// <summary>
        /// Получить дату анализа периода
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task<DateTime> GetAnilizeDate(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var db = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return await db.CreateQuery<DateTime>("SELECT [dbo].GetAnalizeDate(@JobId)", new { JobId = jobId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при получении даты анализа в {nameof(GetAnilizeDate)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Подготовить параметры
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task PrepareParams(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.LostSalesAnalysisJobPrepareParams", new { JobId = jobId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при подготовке параметров {nameof(PrepareParams)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Откат части расчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="stage"></param>
        /// <returns></returns>
        public async Task RollbackCalculate(long jobId, byte stage)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.RollbackPartJob", new { JobId = jobId, Stage = stage });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при удалении параметров {nameof(RollbackCalculate)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Заполнить задания на расчет
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task FillTasks(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.LostSalesAnalysisTasksFill", new { JobId = jobId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при заполнении заданий {nameof(FillTasks)}", ex, jobId);
                throw;
            }
        }


        /// <summary>
        /// Разделить батчи на пачки с заданным размером
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task SplitBatches(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.LostSalesAnalysisSplitBatches", new { JobId = jobId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при разделении батчей на пачки {nameof(FillTasks)}", ex, jobId);
                throw;
            }
        }


        /// <summary>
        /// Получить джоб по идентификатору
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<LostSalesAnalysisJob> GetLostSalesAnalysisJobs(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    return await context.LostSalesAnalysisJobs.Where(i => i.JobId == jobId).FirstOrDefaultAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при получения джоба {nameof(GetLostSalesAnalysisJobs)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Переместить расчет в историю
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task MoveToHistory(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.LostSalesAnalysisMoveToHistory", new { JobId = jobId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при перемещении расчета в историю {nameof(MoveToHistory)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Перенести сигналы
        /// </summary>
        /// <param name="job"></param>
        /// <returns></returns>
        public async Task JobResultsProceed(long jobId, long? subJobId = null, long? batchId = null, long? subBatchId = null)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    await context.ExecuteProcedureAsync("dbo.JobResultProcceed", new { JobId = jobId, SubJobId = subJobId, BatchId = batchId, SubBatchId = subBatchId });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при переносе сигналов для расчета в {nameof(JobResultsProceed)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Получение подробной информации о расчете
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<CalculationInfo> GetCalculateInfo(long id)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = from jobs in context.Jobs
                                join jobsSchedules in context.JobSchedules on jobs.JobScheduleId equals jobsSchedules.Id
                                join calcTypes in context.CalcTypes on jobsSchedules.CalcTypeId equals calcTypes.Id
                                where jobs.Id == id
                                select new CalculationInfo() { Id = jobs.Id, CalculationStart = jobs.StartDate, Status = jobs.Status, TimeZone = calcTypes.TimezoneId };

                    return await query.FirstOrDefaultAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при получении информации о расчете в {nameof(GetCalculateInfo)}", ex, id);
                throw;
            }
        }

        public async Task<Notification> GetNotification(string notificationType)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return await context.Notifications.FirstOrDefaultAsync(x => x.Type == notificationType);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при получении типа рассылки {nameof(GetNotification)}", ex);
                throw;
            }
        }

        /// <summary>
        /// Получить джоб с заданиями на расчет
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<List<LostSalesAnalysisTaskViewModel>> GetLostSalesAnalysisJobTasks(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return await //_mapper.ProjectTo<LostSalesAnalysisTaskViewModel>(
                            context.LostSalesAnalysisTasks
                            .Include(x => x.LostSalesAnalysisBatch)
                            .Include(x => x.Location)
                            .Include(x => x.LostSalesAnalysisSubJob.LostSalesAnalysisSchema.LostSalesAnalisysSchemaParams)
                            .Where(i => i.LostSalesAnalysisJobId == jobId)
                            .Select(x =>
                                new LostSalesAnalysisTaskViewModel
                                {
                                    Id = x.Id,
                                    LostSalesAnalysisJobId = x.LostSalesAnalysisJobId,
                                    LostSalesAnalysisSubBatchId = x.LostSalesAnalysisSubBatchId,
                                    CalcType = (Common.Forecasting.CalcType)x.LostSalesAnalysisBatch.BatchTypeId,
                                    AlgType = (Common.Forecasting.Tasks.AlgType)Byte.Parse(
                                            x.LostSalesAnalysisSubJob
                                            .LostSalesAnalysisSchema
                                            .LostSalesAnalisysSchemaParams
                                            .Where(p => p.Key == "AlgType")
                                            .FirstOrDefault()
                                            .Value
                                        ),
                                    LocationId = x.LocationId,
                                    ProductId = x.ProductId,
                                    StartDateTime = x.StartDateTime,
                                    EndDateTime = x.EndDateTime,
                                    LengthHours = x.LengthHours,
                                    ThresholdLengthWorkingHours = x.ThresholdLengthWorkingHours,
                                    Created = x.Created,
                                    Price = x.Price,
                                    LengthWorkingHours = x.LengthWorkingHours,
                                    OpenTime = x.Location.OpenTime ?? new TimeSpan(),
                                    CloseTime = x.Location.CloseTime ?? new TimeSpan(),
                                    PromoAlgType = x.PromoAlgType,
                                    IsKvi = x.IsKvi
                                }//)
                        ).ToListAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetLostSalesAnalysisJobs)}. Ошибка при получения джоба с заданиями на расчет", ex, jobId);
                throw;
            }
        }


        /// <summary>
        /// Получение параметра по названию
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        public async Task<string> GetParam(string paramName)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = await context.AnalysisParams
                                .Where(p => p.Name == paramName)
                                .Select(p => p.Value)
                                .FirstOrDefaultAsync();

                    return query;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetParam)}. Ошибка при получении параметра {paramName}", ex);
                throw;
            }
        }

        /// <summary>
        /// Проверка необходимости перемещения в историю
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<bool> NeedMoveToHistory(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = await context.Jobs
                                    .Where(x => x.Id == jobId)
                                    .Join(context.JobSchedules.Include(js => js.CalcType),
                                            j => j.JobScheduleId,
                                            js => js.Id,
                                            (j, js) => js.CalcType.MoveToHistory
                                          )
                                    .FirstOrDefaultAsync();

                    return query;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(NeedMoveToHistory)}. Ошибка при проверке необходимости перемещения в историю", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Получить список отсутствующих сигналов
        /// </summary>
        /// <returns></returns>
        public async Task<List<UncalculatedSignal>> GetEmptySignals()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var signals = context.SignalsCheck.ToList();

                    return signals.GroupBy(x => x.Description).Select(x => new UncalculatedSignal()
                    {
                        Description = x.Key,
                        Recepients = x.Select(x => x.Email).ToList()
                    }).ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetEmptySignals)}. Ошибка при получении информации об отсутствующих сигналах", ex);
                throw;
            }
        }

        /// <summary>
        /// Получить список адресов для отправки сообщения об ошибке
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetRecepients(string type)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.Notifications
                        .Where(x => x.Type == type)
                        .Select(x => x.Recipients)
                        .FirstOrDefault()
                        ?.Split(';')
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetEmptySignals)}. Ошибка при получении списка адресов для рассылки", ex);
                throw;
            }
        }
    }

}
