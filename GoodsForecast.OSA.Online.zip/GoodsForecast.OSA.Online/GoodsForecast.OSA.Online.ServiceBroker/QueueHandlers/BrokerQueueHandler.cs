﻿using AutoMapper;
using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Messaging;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using GoodsForecast.OSA.Online.Common.Messaging.Messages.ForecastMessages;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Extensions;
using GoodsForecast.OSA.Online.ServiceBroker.Repositories;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.ServiceBroker.QueueHandlers
{
    /// <summary>
    /// Обработчик очередей для Broker
    /// </summary>
    public class BrokerQueueHandler : IQueueMessageHandler
    {
        /// <summary>
        /// Количество попыток перезапуска расчета по пачке
        /// </summary>
        private const int MaxRestartCount = 5;
        /// <summary>
        /// Количество попыток переотправки сообщения
        /// </summary>
        private const int MaxReSendCount = 5;

        private readonly IBus _bus;
        private readonly OsaLogger<BrokerQueueHandler> _logger;
        private readonly IBrokerRepository _repository;
        private List<IDisposable> _busConnections;
        private Dictionary<long, List<CalculatorToBrokerMessage>> Jobs;
        private readonly IMapper _mapper;        

        public BrokerQueueHandler(
            IBus bus, 
            OsaLogger<BrokerQueueHandler> logger, 
            IBrokerRepository repository,
            IMapper mapper)
        {
            _bus = bus;
            _logger = logger;
            _busConnections = new List<IDisposable>();
            Jobs = new Dictionary<long, List<CalculatorToBrokerMessage>>();
            _repository = repository;
            _mapper = mapper;
        }

        public async Task Register()
        {
            _busConnections.Add(await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.BrokerToBroker), Handle));
            _busConnections.Add(await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.CalculatorToBroker), Handle));
            _busConnections.Add(await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.ReporterToBroker), Handle));
        }

        public async Task Handle(IQueueMessage message)
        {
            switch (message)
            {
                case StartForecastMessage sfMessage:
                    await ProcessStartForecastMessage(sfMessage);
                    break;
                case PrepareParamsMessage ppMessage:
                    await ProcessPrepareParamsMessage(ppMessage);
                    break;
                case FillTasksMessage ftMessage:
                    await ProcessFillTasksMessage(ftMessage);
                    break;
                case SplitTasksMessage stMessage:
                    await ProcessSplitTasksMessage(stMessage);
                    break;
                case CalcForecastMessage cfMessage:
                    await ProcessCalcForecastMessage(cfMessage);
                    break;
                case CalculatorToBrokerMessage cbMessage:
                    await ProcessCalculatorToBrokerMessage(cbMessage);
                    break;
                case ReporterToBrokerMessage rbMessage:
                    await ProcessReporterToBrokerMessage(rbMessage);
                    break;
                default:
                    throw new ArgumentOutOfRangeException($"Тип сообщения {message.GetType()} не найден");
            }
        }

        /// <summary>
        /// Создание джоба
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessStartForecastMessage(StartForecastMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Получено сообщение о создании задания на расчет по расписанию JobScheduleId = {message.JobScheduleId}");

            Job job = null;
            try
            {
                if (!message.JobScheduleId.HasValue)
                    throw new Exception("Невозможно запустить расчет, т.к. не задано расписание!");

                job = await CreateJob(message.JobScheduleId.Value);
                var lostSalesAnalysisJob = await CreateLostSalesAnalysisJob(job.Id);

                await SendMessage(new PrepareParamsMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = job.Id,
                    RestartCount = message.RestartCount
                }, 0);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessStartForecastMessage)}. Произошла ошибка во время создания задания на расчет", ex, job?.Id);

                var resendMessage = new StartForecastMessage
                {
                    JobId = job?.Id,
                    JobScheduleId = message.JobScheduleId,
                    RestartCount = message.RestartCount + 1
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во время создания задания на расчет\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка создания расчета"
                };

                await RestartOnException(job?.Id, message.RestartCount, null, false, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessStartForecastMessage)}. Не удалось перезапустить создание задания на расчет");
                
            }
        }

        /// <summary>
        /// Подготовка параметров
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessPrepareParamsMessage(PrepareParamsMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Получено сообщение о подготовке параметров для джоба JobId = {message.JobId}", message.JobId);
            try
            {
                if (!message.JobId.HasValue)
                    throw new Exception("Невозможно подготовить параметры, т.к. не создано задание на расчет!");

                Stopwatch sw = new Stopwatch();
                sw.Start();

                await _repository.PrepareParams(message.JobId.Value);

                sw.Stop();

                await SendMessage(new FillTasksMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                }, 0);

                _logger.LogInformation(Environment.MachineName, $"Параметры для джоба подготовлены. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", message.JobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessPrepareParamsMessage)}. Произошла ошибка во время подготовки параметров", ex, message.JobId);

                var resendMessage = new PrepareParamsMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во время подготовки параметров для JobId = {message.JobId}\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка подготовки параметров"
                };

                await RestartOnException(message.JobId, message.RestartCount, Stages.PrepareParams, true, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessPrepareParamsMessage)}. Не удалось перезапустить подготовку параметров");
                
            }
        }

        /// <summary>
        /// Создание тасков
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessFillTasksMessage(FillTasksMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Получено сообщение о создании тасков для джоба JobId = {message.JobId}", message.JobId);

            try
            {
                if (!message.JobId.HasValue)
                    throw new Exception("Невозможно создать таски, т.к. не создано задание на расчет!");

                Stopwatch sw = new Stopwatch();
                sw.Start();

                await _repository.FillTasks(message.JobId.Value);

                sw.Stop();

                await SendMessage(new SplitTasksMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                }, 0);

                _logger.LogInformation(Environment.MachineName, $"Задания для джоба сформированы. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", message.JobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessFillTasksMessage)}. Произошла ошибка во время создания тасков", ex, message.JobId);

                var resendMessage = new FillTasksMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во время создания тасков для JobId = {message.JobId}\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка создания тасков"
                };

                await RestartOnException(message.JobId, message.RestartCount, Stages.FillTasks, true, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessFillTasksMessage)}. Не удалось перезапустить создание тасков");
            }
        }

        /// <summary>
        /// Разделение тасков на пачки
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessSplitTasksMessage(SplitTasksMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Получено сообщение о резделении тасков на пачки для джоба JobId = {message.JobId}", message.JobId);

            try
            {
                if (!message.JobId.HasValue)
                    throw new Exception("Невозможно разбить таски на пачки, т.к. не создано задание на расчет!");

                Stopwatch sw = new Stopwatch();
                sw.Start();

                await _repository.SplitBatches(message.JobId.Value);

                sw.Stop();

                await SendMessage(new CalcForecastMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                }, 0);

                _logger.LogInformation(Environment.MachineName, $"Таски разбиты на пачки. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", message.JobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessSplitTasksMessage)}. Произошла ошибка во время разделения тасков на пачки", ex, message.JobId);

                var resendMessage = new SplitTasksMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    RestartCount = message.RestartCount
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во время разделения тасков на пачки для JobId = {message.JobId}\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка разделения на пачки"
                };

                await RestartOnException(message.JobId, message.RestartCount, Stages.SplitTasks, true, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessSplitTasksMessage)}. Не удалось перезапустить разделение тасков на пачки");
            }
        }

        /// <summary>
        /// Запуск расчета
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessCalcForecastMessage(CalcForecastMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Получено сообщение о старте расчета для джоба JobId = {message.JobId}, " +
                $"SubJobId = {message.SubJobId}, BatchId = {message.BatchId}, SubBatchId = {message.SubBatchId}", message.JobId);

            try
            {
                if (!message.JobId.HasValue)
                    throw new Exception("Невозможно запустить расчет, т.к. не создано задание на расчет!");

                Stopwatch sw = new Stopwatch();
                sw.Start();

                List<SuspectForecastBatch> promoSuspectForecastBatchs = new List<SuspectForecastBatch>();
                List<SuspectForecastBatch> kviSuspectForecastBatchs = new List<SuspectForecastBatch>();
                List<SuspectForecastBatch> suspectForecastBatchs = new List<SuspectForecastBatch>();
                int allCount = 0;

                var job = await _repository.GetLostSalesAnalysisJobs(message.JobId.Value);

                var tasks = await _repository.GetLostSalesAnalysisJobTasks(job.JobId);

                if (message.SubJobId.HasValue)
                    tasks = tasks.Where(t => t.LostSalesAnalysisSubJobId == message.SubJobId.Value).ToList();

                if (message.BatchId.HasValue)
                    tasks = tasks.Where(t => t.LostSalesAnalysisBatchId == message.BatchId.Value).ToList();

                if (message.SubBatchId.HasValue)
                    tasks = tasks.Where(t => t.LostSalesAnalysisSubBatchId == message.SubBatchId.Value).ToList();

                var promoTasks = tasks.Where(i => i.CalcType == Common.Forecasting.CalcType.Promo).ToList();

                var kviTasks = tasks.Where(i => i.CalcType == Common.Forecasting.CalcType.Kvi).ToList();

                var locationProductTasks = tasks.Where(i => i.CalcType == Common.Forecasting.CalcType.LocationProduct).ToList();

                var subBatches = promoTasks.GroupBy(t => t.LostSalesAnalysisSubBatchId).ToDictionary(k => k.Key, v => v.ToList());
                allCount += subBatches.Count;

                foreach (var subBatch in subBatches)
                {
                    var algType = subBatch.Value.FirstOrDefault()?.AlgType ?? Common.Forecasting.Tasks.AlgType.ByCluster;

                    var promoSuspects = subBatch.Value.ToSuspectBatch(_mapper);
                    promoSuspectForecastBatchs.AddRange(WrapBatches(job.JobId, job.AnalizeDatetime, tasks, promoSuspects, subBatch.Key.Value, true, algType));
                }

                subBatches = kviTasks.GroupBy(t => t.LostSalesAnalysisSubBatchId).ToDictionary(k => k.Key, v => v.ToList());
                allCount += subBatches.Count;

                foreach (var subBatch in subBatches)
                {
                    var algType = subBatch.Value.FirstOrDefault()?.AlgType ?? Common.Forecasting.Tasks.AlgType.ByCluster;

                    var kviSuspects = subBatch.Value.ToSuspectBatch(_mapper);
                    kviSuspectForecastBatchs.AddRange(WrapBatches(job.JobId, job.AnalizeDatetime, tasks, kviSuspects, subBatch.Key.Value, true, algType));
                }

                subBatches = locationProductTasks.GroupBy(t => t.LostSalesAnalysisSubBatchId).ToDictionary(k => k.Key, v => v.ToList());
                allCount += subBatches.Count;

                foreach (var subBatch in subBatches)
                {
                    var algType = subBatch.Value.FirstOrDefault()?.AlgType ?? Common.Forecasting.Tasks.AlgType.ByCluster;

                    var locationProductSuspects = subBatch.Value.ToSuspectBatch(_mapper);
                    suspectForecastBatchs.AddRange(WrapBatches(job.JobId, job.AnalizeDatetime, tasks, locationProductSuspects, subBatch.Key.Value, false, algType));
                }


                var usePromoAlg = await _repository.GetParam("UsePromoAlg");

                foreach (var batch in promoSuspectForecastBatchs)
                {
                    if (usePromoAlg == "1")
                    {
                        var batchItems = batch.Items.Select(
                            i =>
                                new PromoSuspectForecastBatchItem()
                                {
                                    ProductId = i.ProductId,
                                    LocationId = i.LocationId,
                                    Schedule = i.Schedule,
                                    Id = i.Suspects.FirstOrDefault().Id,
                                    EndDate = i.Suspects.FirstOrDefault().EndDate,
                                    IsKvi = i.Suspects.FirstOrDefault().IsKvi,
                                    Length = i.Suspects.FirstOrDefault().Length,
                                    PromoAlgType = i.Suspects.FirstOrDefault().PromoAlgType,
                                    Threshold = i.Suspects.FirstOrDefault().Threshold,
                                    StartDate = i.Suspects.FirstOrDefault().StartDate
                                });

                        var batchByNeedType = new PromoSuspectForecastBatch()
                        {
                            JobId = batch.JobId,
                            SubJobId = batch.SubJobId,
                            BatchId = batch.BatchId,
                            SubBatchId = batch.SubBatchId,
                            AllCount = allCount,
                            Schedule = batch.Schedule,
                            LocationId = batch.LocationId,
                            AlgType = batch.AlgType,
                            HistoryStartDate = batch.HistoryStartDate,
                            HistoryEndDate = batch.HistoryEndDate,
                            Items = batchItems.ToList(),
                            RestartCount = message.RestartCount
                        };

                        await SendMessage(nameof(QueueName.BrokerToCalculator), batchByNeedType, 0);
                    }
                    else
                    {
                        batch.RestartCount = message.RestartCount;
                        batch.AllCount = allCount;
                        await SendMessage(nameof(QueueName.BrokerToCalculator), batch, 0);
                    }
                }

                foreach (var batch in kviSuspectForecastBatchs)
                {
                    batch.RestartCount = message.RestartCount;
                    batch.AllCount = allCount;
                    await SendMessage(nameof(QueueName.BrokerToCalculator), batch, 0);
                }

                foreach (var batch in suspectForecastBatchs)
                {
                    batch.RestartCount = message.RestartCount;
                    batch.AllCount = allCount;
                    await SendMessage(nameof(QueueName.BrokerToCalculator), batch, 0);
                }

                sw.Stop();
                _logger.LogInformation(Environment.MachineName, $"Задания для джоба отправлены на расчет. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", job.JobId);

            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessCalcForecastMessage)}. Произошла ошибка во время отправки на расчет", ex, message.JobId);

                var resendMessage = new CalcForecastMessage
                {
                    JobScheduleId = message.JobScheduleId,
                    JobId = message.JobId,
                    SubJobId = message.SubJobId,
                    BatchId = message.BatchId,
                    SubBatchId = message.SubBatchId,
                    RestartCount = message.RestartCount
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во время отправки на расчет для JobId = {message.JobId}\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка при отправке на расчет"
                };

                await RestartOnException(message.JobId, message.RestartCount, Stages.CalcForecast, true, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessCalcForecastMessage)}. Не удалось перезапустить отправку на расчет");
            }
        }       

        /// <summary>
        /// Получение результатов расчета и отправка сигналов в ПБД
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessCalculatorToBrokerMessage(CalculatorToBrokerMessage message)
        {
            try
            {
                _logger.LogInformation(Environment.MachineName, $"Получено сообщение о завершении части расчета для джоба JobId = {message.JobId}, " +
                    $"SubJobId = {message.SubJobId}, BatchId = {message.BatchId}, SubBatchId = {message.SubBatchId}", message.JobId);

                if (message.IsError)
                {
                    SendMessageToMessenger(message);

                    if (message.RestartCount < MaxRestartCount)
                    {
                        await SendMessage(new CalcForecastMessage
                        {
                            JobId = message.JobId,
                            SubJobId = message.SubJobId,
                            BatchId = message.BatchId,
                            SubBatchId = message.SubBatchId,
                            RestartCount = message.RestartCount + 1
                        }, 0);
                        return;
                    }
                }

                if (Jobs.ContainsKey(message.JobId))
                {
                    if(Jobs[message.JobId].Where(x => x.SubBatchId == message.SubBatchId).Count() == 0)
                        Jobs[message.JobId].Add(message);
                }
                else
                    Jobs.Add(message.JobId, new List<CalculatorToBrokerMessage>() { message });

                if (Jobs[message.JobId].Count >= message.AllCount && Jobs[message.JobId].TrueForAll(x => x.AllCount == message.AllCount))
                {
                    if (Jobs[message.JobId].TrueForAll(x => !x.IsError))
                    {
                        _logger.LogInformation(Environment.MachineName, $"Все расчеты по заданию получены", message.JobId);

                        Stopwatch sw = new Stopwatch();
                        sw.Start();
                        if (message.AllCount == 1)
                            await _repository.JobResultsProceed(message.JobId, message.SubJobId, message.BatchId, message.SubBatchId);
                        else
                            await _repository.JobResultsProceed(message.JobId);

                        _logger.LogInformation(Environment.MachineName, $"Сигналы по заданию перенесены в ПБД. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", message.JobId);
                        sw.Restart();

                        var needMoveToHistory = await _repository.NeedMoveToHistory(message.JobId);

                        if (needMoveToHistory)
                        {
                            await _repository.MoveToHistory(message.JobId);
                            _logger.LogInformation(Environment.MachineName, $"Информация по расчету перенесена в историю. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", message.JobId);
                        }

                        sw.Stop();
                        _logger.LogInformation(Environment.MachineName, $"Расчет по заданию завершен", message.JobId);

                        //Отправляем сообщение на рассылку
                        SendMessageToMessenger(message);
                    }
                    else
                    {
                        _logger.LogInformation(Environment.MachineName, $"Расчет по заданию для пачки {message.SubBatchId} и магазина {message.LocationId} завершен с ошибкой", message.JobId);
                    }
                    Jobs.Remove(message.JobId);
                }

            }
            catch (Exception ex)
            {
                var resendMessage = new CalculatorToBrokerMessage
                {
                    JobId = message.JobId,
                    SubJobId = message.SubJobId,
                    BatchId = message.BatchId,
                    SubBatchId = message.SubBatchId,
                    LocationId = message.LocationId,
                    AllCount = message.AllCount,
                    RestartCount = message.RestartCount
                };
                var errorMessage = new BrokerToMessengerMessage
                {
                    Body = $"Произошла ошибка во переноса сигналов на расчет для JobId = {message.JobId}\nТекст ошибки: {ex}",
                    Priority = System.Net.Mail.MailPriority.High,
                    Subject = "Ошибка при переносе сигналов"
                };

                await RestartOnException(message.JobId, message.RestartCount, Stages.SendSignals, true, resendMessage, errorMessage, ex,
                        $"{nameof(ProcessCalculatorToBrokerMessage)}. Не удалось перезапустить перенос сигналов");
            }
        }

        private async Task ProcessReporterToBrokerMessage(ReporterToBrokerMessage message)
        {
            try
            {
                _logger.LogInformation(Environment.MachineName, $"Файл {message.Subject}. Сообщение  было получено из очереди {nameof(QueueName.ReporterToBroker)}", message.JobId);

                //Добавляем/обновляем файлы отчета
                foreach (var report in message.Attachments)
                {
                    await _repository.AddReport(new ReportHistory() { JobId = message.JobId, FileData = report.Value, FileName = report.Key, Recepients = message.Recepients });
                    _logger.LogInformation(Environment.MachineName, $"Файл {report.Key} был успешно добавлен в БД", message.JobId);
                }

                await SendMessage(nameof(QueueName.BrokerToMessenger),
                           new BrokerToMessengerMessage
                           {
                               Body = message.Body,
                               Subject = message.Subject,
                               Recipients = message.Recepients.Split(";"),
                               JobId = message.JobId,
                               Attachments = message.Attachments
                           }, 0);

                _logger.LogInformation(Environment.MachineName, $"Файлы были успешно отправлены в очередь {nameof(QueueName.BrokerToMessenger)}.", message.JobId);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При отправке файла произошла ошибка в {nameof(BrokerQueueHandler)}", ex, message.JobId);
            }
        }

        public async void SendMessageToMessenger(CalculatorToBrokerMessage message)
        {
            try
            {
                //Получаем инфу по расчету для заполнения текста сообщения
                var calculationInfo = await _repository.GetCalculateInfo(message.JobId);

                //Тип рассылки
                var notification = await _repository.GetNotification(nameof(CalculatorToBrokerMessage));

                //Если произошла ошибка во время расчета
                if (message.IsError)
                {
                    await SendMessage(nameof(QueueName.BrokerToMessenger),
                            new BrokerToMessengerMessage
                            {
                                Body = $"Произошла ошибка во время расчета JobId = {message.JobId}, " +
                                $"Пачка {message.SubBatchId}, " +
                                $"Магазин {message.LocationId}, " +
                                $"Время начала расчета {calculationInfo.CalculationStart} " +
                                $"Статус отчета: {calculationInfo.Status} " +
                                $"Часовой пояс: {calculationInfo.TimeZone} " +
                                $"\nТекст ошибки: {message.ErrorMessage}",
                                Priority = System.Net.Mail.MailPriority.High,
                                Subject = "Ошибка расчёта",
                                JobId = message.JobId,
                                Recipients = notification.Recipients.Split(";")
                            }, 0);
                }
                else
                {
                    await SendMessage(nameof(QueueName.BrokerToMessenger),
                            new BrokerToMessengerMessage
                            {
                                Body = $"Задание на расчет JobId = {message.JobId} завершено успешно. " +
                                $"Дата начала расчета {calculationInfo.CalculationStart}. " +
                                $"Статус отчета: {calculationInfo.Status} " +
                                $"Часовой пояс: {calculationInfo.TimeZone} ",
                                Priority = System.Net.Mail.MailPriority.Normal,
                                Subject = "Расчет завершен",
                                Recipients = notification.Recipients.Split(";")
                            }, 0);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При отправке сообщения на рассылку произошла ошибка в  {nameof(SendMessageToMessenger)}", ex, message.JobId);
                throw;
            }
        }

        /// <summary>
        /// Создание джоба
        /// </summary>
        /// <param name="jobSheduleId"></param>
        /// <returns></returns>
        private async Task<Job> CreateJob(int jobSheduleId)
        {
            try
            {
                var job = new Job
                {
                    JobScheduleId = jobSheduleId,
                    StartDate = DateTime.Now,
                    Status = 1
                };
                await _repository.UpdateJob(job);

                return job;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при создании задания по расписанию JobSheduleId = {jobSheduleId}", ex);
                throw;
            }
        }

        /// <summary>
        /// Создание джоба для расчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private async Task<LostSalesAnalysisJob> CreateLostSalesAnalysisJob(long jobId)
        {
            try
            {
                var analizeDate = await _repository.GetAnilizeDate(jobId);
                var lostSalesAnalysisJob = new LostSalesAnalysisJob
                {
                    Created = DateTime.Now,
                    AnalizeDatetime = analizeDate,
                    JobId = jobId,
                    Status = (byte)LostSalesAnalysisStatus.New
                };
                await _repository.UpdateLostSalesAnalisysJob(lostSalesAnalysisJob);

                var message = $"Задание на расчет созданo. Анализируемая дата {analizeDate}.";

                await _bus.SendReceive.SendAsync(
                    nameof(QueueName.BrokerToMessenger),
                    new BrokerToMessengerMessage
                    {
                        Body = message,
                        Priority = System.Net.Mail.MailPriority.Normal,
                        Subject = "Новый расчет"
                    });

                _logger.LogInformation(Environment.MachineName, message, jobId);

                return lostSalesAnalysisJob;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при создании джоба для расчета JobId = {jobId}", ex, jobId);
                throw;
            }
        }


        /// <summary>
        /// Формирование пачки
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="analysisDatetime"></param>
        /// <param name="tasks"></param>
        /// <param name="suspects"></param>
        /// <param name="subBatchId"></param>
        /// <param name="isAbsoluteProbability"></param>
        /// <param name="storeGroupId"></param>
        /// <param name="algType"></param>
        /// <returns></returns>
        public List<SuspectForecastBatch> WrapBatches(
           long jobId,
           DateTime analysisDatetime,
           List<LostSalesAnalysisTaskViewModel> tasks,
           Dictionary<int, Dictionary<int, IEnumerable<Suspect>>> suspects,
           long subBatchId,
           bool isAbsoluteProbability,
           Common.Forecasting.Tasks.AlgType algType
           )
        {
            var result = new List<SuspectForecastBatch>();

            var storeSсhedule = tasks.GroupBy(i => i.LocationId)
                .ToDictionary(i => i.Key, s => s.Select(j => new { j.OpenTime, j.CloseTime }).FirstOrDefault());

            foreach (var locationProductSuspect in suspects)
            {
                var locationId = locationProductSuspect.Key;
                var productSuspects = locationProductSuspect.Value;
                var productCount = productSuspects.Keys.Count;

                var schedule = new Dictionary<DayOfWeek, TimePeriod>();

                for (var id = 0; id < 7; id++)
                {
                    schedule.Add((DayOfWeek)id,
                        new TimePeriod()
                        {
                            Start = storeSсhedule[locationId].OpenTime,
                            End = storeSсhedule[locationId].CloseTime
                        });
                }


                var productIds = productSuspects.Keys;

                var batchItems = productIds.Select(productId => new SuspectForecastBatchItem()
                {
                    ProductId = productId,
                    LocationId = locationId,
                    Suspects = productSuspects[productId].ToList(),
                    Schedule = schedule
                }).ToList();

                var batch = new SuspectForecastBatch
                {
                    JobId = jobId,
                    SubJobId = tasks.FirstOrDefault()?.LostSalesAnalysisSubJobId,
                    BatchId = tasks.FirstOrDefault()?.LostSalesAnalysisBatchId,
                    SubBatchId = subBatchId,
                    LocationId = locationId,
                    AlgType = algType,
                    Items = batchItems,
                    Schedule = schedule,
                    HistoryEndDate = analysisDatetime,
                    IsAbsoluteProbability = isAbsoluteProbability
                };

                result.Add(batch);

            }

            return result;
        }

        /// <summary>
        /// Отправка сообщение в очередь с возможностью перезапуска
        /// </summary>
        /// <param name="message">Сообщение для отправки</param>
        /// <param name="sendCount">Количество попыток перезапуска</param>
        /// <returns></returns>
        private async Task SendMessage(BrokerToBrokerMessage message, int sendCount)
        {
            try
            {
                await _bus.SendReceive.SendAsync(nameof(QueueName.BrokerToBroker), message);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"SubBatchId = [{message.SubBatchId}]. Не удалось отправить сообщение.", ex, message.JobId);
                sendCount++;
                if (sendCount <= MaxReSendCount)
                {
                    await Task.Delay(10000);
                    await SendMessage(message, sendCount);
                }
                else
                    throw new Exception($"SubBatchId = [{message.SubBatchId}]. Не удалось отправить сообщение после {sendCount} попыток.");

            }
        }

        /// <summary>
        /// Отправка сообщение в очередь с возможностью перезапуска
        /// </summary>
        /// <param name="queue">Очередь для отправки</param>
        /// <param name="message">Сообщение для отправки</param>
        /// <param name="sendCount">Количество попыток перезапуска</param>
        /// <returns></returns>
        private async Task SendMessage(string queue, IQueueMessage message, int sendCount)
        {
            try
            {
                await _bus.SendReceive.SendAsync(queue, message);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Не удалось отправить сообщение в очередь {queue}.", ex);
                sendCount++;
                if (sendCount <= MaxReSendCount)
                {
                    await Task.Delay(10000);
                    await SendMessage(queue, message, sendCount);
                }
                else
                    throw new Exception($"Не удалось отправить сообщение в очередь {queue} после {sendCount} попыток.");

            }
        }

        /// <summary>
        /// Перезапуск при ошибке
        /// </summary>
        /// <param name="jobId">Джоб</param>
        /// <param name="restartCount">Количество перезапусков</param>
        /// <param name="stage">Место, с которого перезапускать</param>
        /// <param name="needRollback">Откатывать ли данные в базе</param>
        /// <param name="resendMessage">Сообщение для перезапуска</param>
        /// <param name="errorMessage">Сообщение с ошибкой в случае неудачного перезапуска</param>
        /// <param name="ex">Ошибка, которая вызвала перезапуск</param>
        /// <param name="error">Сообщение об ошибке в случае неудачи перезапуска</param>
        /// <returns></returns>
        public async Task RestartOnException(
                long? jobId,
                int restartCount, 
                Stages? stage, 
                bool needRollback, 
                IQueueMessage resendMessage,
                BrokerToMessengerMessage errorMessage,
                Exception ex,
                string error)
        {
            if (jobId.HasValue && restartCount <= MaxRestartCount)
            {
                await Task.Delay(10000);
                if(needRollback)
                    await _repository.RollbackCalculate(jobId.Value, (byte)stage);
                await _bus.SendReceive.SendAsync(nameof(QueueName.BrokerToBroker), resendMessage);
            }
            else
            {
                _logger.LogError(Environment.MachineName, error, ex, jobId);

                await _bus.SendReceive.SendAsync(nameof(QueueName.BrokerToMessenger), errorMessage);
            }
        }

        public void Dispose()
        {
            foreach (var item in _busConnections)
                item?.Dispose();

            _bus?.Dispose();
        }
    }
}
