﻿CREATE LOGIN [gfc_dba]
    WITH PASSWORD = N'cdQsoem{qpsjpeXvjyss||jnmsFT7_&#$!~<Otei^|bj@&oj', SID = 0x08B2EAD4B9C1AA43BECA25D2C3C22EE9, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

