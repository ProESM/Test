﻿ALTER ROLE [db_owner] ADD MEMBER [gfc_osa_online];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\olap_services];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\npuntus];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\dfedorov6];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\dmelkov];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\AxaptaAppl2012];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\AChistov2];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\dtarasov3];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\mmatveev2];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\SGayduk1];


GO
ALTER ROLE [db_datareader] ADD MEMBER [OKEY\rmetelskiy];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\olap_services];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\dfedorov6];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\dmelkov];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\AxaptaAppl2012];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\dtarasov3];


GO
ALTER ROLE [db_datawriter] ADD MEMBER [OKEY\mmatveev2];

