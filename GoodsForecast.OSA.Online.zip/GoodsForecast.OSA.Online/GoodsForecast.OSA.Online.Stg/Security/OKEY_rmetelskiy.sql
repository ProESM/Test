﻿CREATE USER [OKEY\rmetelskiy] FOR LOGIN [OKEY\rmetelskiy];

