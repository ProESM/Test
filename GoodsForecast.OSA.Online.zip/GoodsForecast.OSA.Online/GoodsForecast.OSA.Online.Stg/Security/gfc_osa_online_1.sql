﻿CREATE LOGIN [gfc_osa_online]
    WITH PASSWORD = N'cQd;sKTYom{qEpsjevjys9s|msFT7_&#$!~<jnxtde|bWjko', SID = 0xED986CFD3702E140A44E73A34F9F8AC0, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

