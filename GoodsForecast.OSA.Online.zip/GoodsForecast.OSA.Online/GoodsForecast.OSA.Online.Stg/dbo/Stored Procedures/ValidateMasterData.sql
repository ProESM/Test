﻿
--USE [GFC.Projects.OSA.Online.Okey]
--GO
--/****** Object:  StoredProcedure [dbo].[ValidateMasterData]    Script Date: 04.03.2021 12:24:39 ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

CREATE PROCEDURE [dbo].[ValidateMasterData] 
   @SyncId INT
AS 

--DECLARE @SyncId INT = 1
DECLARE @Created DATETIME 

SELECT @Created = GETDATE()
DECLARE @StartDate DATE

SELECT @StartDate = CAST(s.StartDate AS DATE)
FROM [GFC.Projects.OSA.Online.Okey].dbo.SynchronizationDataLog AS s
WHERE s.SyncId = @SyncId

--SELECT @Created = s.Created
--FROM dbo.StagingSyncs s
--WHERE s.SyncId  = @SyncId

DELETE b
OUTPUT @SyncId,@Created, DELETED.BrandID, DELETED.Name,1,'BrandID - содержит пустую строку'
INTO ERROR.Brands
(
   SyncId,
   SyncCreated,
   BrandId,
   Name,
   ErrorCode,
   ErrorDescription
) 
FROM dbo.brands b
WHERE LTRIM(RTRIM(b.BrandID)) = ''
   OR b.BrandId IS NULL
   
   
DELETE b
OUTPUT @SyncId,@Created, DELETED.BrandID, DELETED.Name,2,'Brand Name - содержит пустую строку'
INTO ERROR.Brands
(
   SyncId,
   SyncCreated,
   BrandId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.brands b
WHERE    b.Name IS NULL
   OR LTRIM(RTRIM(b.Name)) = '' 
 
DELETE c
OUTPUT @SyncId,@Created, DELETED.CountryId, DELETED.Name,3,'CountryId - содержит пустую строку'
INTO ERROR.Countries
(
   SyncId,
   SyncCreated,
   CountryId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.Countries AS c
WHERE    c.CountryId IS NULL
   OR LTRIM(RTRIM(c.CountryId)) = '' 
   
DELETE c
OUTPUT @SyncId,@Created, DELETED.CountryId, DELETED.Name,4,'Country Name - содержит пустую строку'
INTO ERROR.Countries
(
   SyncId,
   SyncCreated,
   CountryId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.Countries AS c
WHERE    c.Name IS NULL
   OR LTRIM(RTRIM(c.Name)) = '' 
  
 DELETE c
OUTPUT @SyncId,@Created, DELETED.ProducerId, DELETED.Name,5,'ProducerId - содержит пустую строку'
INTO ERROR.Producers
(
   SyncId,
   SyncCreated,
   ProducerId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.Producers AS c
WHERE    c.ProducerID IS NULL
   OR LTRIM(RTRIM(c.ProducerID)) = '' 
   
DELETE c
OUTPUT @SyncId,@Created, DELETED.ProducerId, DELETED.Name,6,'Producer Name - содержит пустую строку'
INTO ERROR.Producers
(
   SyncId,
   SyncCreated,
   ProducerId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.Producers AS c
WHERE    c.Name IS NULL
   OR LTRIM(RTRIM(c.Name)) = '' 
  

DELETE c
OUTPUT @SyncId,@Created, DELETED.ProductTypeId, DELETED.Name,7,'ProductTypeID - содержит пустую строку'
INTO ERROR.ProductTypes
(
   SyncId,
   SyncCreated,
   ProductTypeId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.ProductTypes AS c
WHERE    c.ProductTypeId IS NULL
   OR LTRIM(RTRIM(c.ProductTypeId)) = ''  
 
 
 DELETE c
OUTPUT @SyncId,@Created, DELETED.ProductTypeId, DELETED.Name,8,'Product Name - содержит пустую строку'
INTO ERROR.ProductTypes
(
   SyncId,
   SyncCreated,
   ProductTypeId,
   Name,
   ErrorCode,
   ErrorDescription
)
FROM dbo.ProductTypes AS c
WHERE    c.Name IS NULL
   OR LTRIM(RTRIM(c.Name)) = ''  


 DELETE p
 OUTPUT @SyncId,@Created, DELETED.ProductGroupId, DELETED.Name,9,'ProductGroupId - содержит пустую строку'
 INTO ERROR.ProductGroups
(
   SyncId,
   SyncCreated,
   ProductGroupId,
   Name,
   ErrorCode,
   ErrorDescription
)
 FROM dbo.ProductGroups p
 WHERE   p.ProductGroupId IS NULL
   OR LTRIM(RTRIM(p.ProductGroupId)) = ''   
    
 
 DELETE p
 OUTPUT @SyncId,@Created, DELETED.ProductGroupId, DELETED.ParentId, DELETED.Name,10,'ProductGroup Name - содержит пустую строку'
 INTO ERROR.ProductGroups
(
  SyncId,
   SyncCreated,
   ProductGroupId,
   ParentId,
   Name,
   ErrorCode,
   ErrorDescription
)
 FROM dbo.ProductGroups p
 WHERE   p.Name IS NULL
   OR LTRIM(RTRIM(p.Name)) = '' 
   
 DELETE p
 OUTPUT @SyncId,@Created, DELETED.ProductGroupId,DELETED.ParentId, DELETED.Name,11,'Поле ParentId не ссылается на ProductGroupId таблицы ProductGroups'
 INTO ERROR.ProductGroups
(
   SyncId,
   SyncCreated,
   ProductGroupId,
   ParentId,
   Name,
   ErrorCode,
   ErrorDescription
) 
 FROM dbo.ProductGroups p
 WHERE  NOT EXISTS 
 (
    SELECT 1
    FROM dbo.ProductGroups AS pg
    WHERE pg.ProductGroupId = p.ParentId       
 )
 AND p.ParentId IS NOT NULL 
 

  DELETE p
 OUTPUT @SyncId,@Created, DELETED.MeasureUnitId, DELETED.Name,12,'Поле MeasureUnitId - содержит пустую строку'
 INTO ERROR.MeasureUnits
(
   SyncId,
   SyncCreated,
   MeasureUnitId,
   Name,
   ErrorCode,
   ErrorDescription
) 
 FROM dbo.MeasureUnits p
 WHERE  LTRIM(RTRIM(p.MeasureUnitId)) = ''
 
 DELETE p
 OUTPUT @SyncId,@Created, DELETED.MeasureUnitId, DELETED.Name,13,'Поле Measure Name - содержит пустую строку'
 INTO ERROR.MeasureUnits
(
   SyncId,
   SyncCreated,
   MeasureUnitId,
   Name,
   ErrorCode,
   ErrorDescription
) 
 FROM dbo.MeasureUnits p
 WHERE  LTRIM(RTRIM(p.Name)) = ''
   OR p.Name IS NULL
   
 --DELETE p
 --OUTPUT @SyncId,
 --      @Created,
 --      DELETED.ProductId,
 --      DELETED.Name,
 --      DELETED.Barcode,
 --      DELETED.ProductTypeId,
 --      DELETED.ProductGroupId,
 --      DELETED.BrandId,
 --      DELETED.CountryId,
 --      DELETED.ProducerId,
 --      DELETED.MeasureUnitId,
 --      14,'Поле ProductId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.ProductId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,14 AS [ErrorCode]
           ,N'Поле ProductId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[ProductId])) = ''
   
-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       15,'Поле Name - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.Name)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,15 AS [ErrorCode]
           ,N'Поле Name - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[Name])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       16,'Поле Barcode - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.Barcode)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,16 AS [ErrorCode]
           ,N'Поле Barcode - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[Barcode])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       17,'Поле ProductTypeId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.ProductTypeId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,17 AS [ErrorCode]
           ,N'Поле ProductTypeId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[ProductTypeId])) = ''
 
-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       19,'Поле ProductGroupId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.ProductGroupId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,19 AS [ErrorCode]
           ,N'Поле ProductGroupId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[ProductGroupId])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       20,'Поле BrandId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.BrandId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,20 AS [ErrorCode]
           ,N'Поле BrandId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[BrandId])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       21,'Поле CountryId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.CountryId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,21 AS [ErrorCode]
           ,N'Поле CountryId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[CountryId])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       22,'Поле ProducerId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.ProducerId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,22 AS [ErrorCode]
           ,N'Поле ProducerId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[ProducerId])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       23,'Поле MeasureUnitId - содержит пустую строку'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)  
--FROM dbo.Products p
--WHERE  LTRIM(RTRIM(p.MeasureUnitId)) = ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,23 AS [ErrorCode]
           ,N'Поле MeasureUnitId - содержит пустую строку' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE LTRIM(RTRIM(p.[MeasureUnitId])) = ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       24,'Поле ProductTypeId не ссылается на ProductTypeId таблицы ProductTypes'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.ProductTypes AS pt
--   WHERE pt.ProductTypeId = p.ProductTypeId    
--)

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,24 AS [ErrorCode]
           ,N'Поле ProductTypeId не ссылается на ProductTypeId таблицы ProductTypes' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[ProductTypes] AS pt
   WHERE pt.[ProductTypeId] = p.[ProductTypeId]    
)

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       25,'Поле ProductGroupId не ссылается  на ProductGroupId таблицы ProductGroups'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.ProductGroups AS pt
--   WHERE pt.ProductGroupId = p.ProductGroupId
--)

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,25 AS [ErrorCode]
           ,N'Поле ProductGroupId не ссылается  на ProductGroupId таблицы ProductGroups' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[ProductGroups] AS pt
   WHERE pt.[ProductGroupId] = p.[ProductGroupId]
)

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       26,'Поле BrandId не ссылается на BrandId таблицы Brands'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.Brands AS pt
--   WHERE pt.BrandId = p.BrandId
--)

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,26 AS [ErrorCode]
           ,N'Поле BrandId не ссылается на BrandId таблицы Brands' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[Brands] AS pt
   WHERE pt.[BrandId] = p.[BrandId]
)

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       27,'Поле CountryId не ссылается на CountryId таблицы Countries'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.Countries AS pt
--   WHERE pt.CountryId = p.CountryId
--)
--AND p.CountryId IS NOT NULL 
--AND LTRIM(RTRIM(p.CountryId)) <> ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,27 AS [ErrorCode]
           ,N'Поле CountryId не ссылается на CountryId таблицы Countries' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[Countries] AS pt
   WHERE pt.[CountryId] = p.[CountryId]
)
AND p.[CountryId] IS NOT NULL 
AND LTRIM(RTRIM(p.[CountryId])) <> ''


-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       28,'Поле ProducerId не ссылается на ProducerId таблицы Producers'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.Producers AS pt
--   WHERE pt.ProducerId = p.ProducerId
--)
--AND p.ProducerId IS NOT NULL 
--AND LTRIM(RTRIM(p.ProducerId)) <> ''

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,28 AS [ErrorCode]
           ,N'Поле ProducerId не ссылается на ProducerId таблицы Producers' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[Producers] AS pt
   WHERE pt.[ProducerId] = p.[ProducerId]
)
AND p.[ProducerId] IS NOT NULL 
AND LTRIM(RTRIM(p.[ProducerId])) <> ''

-- DELETE p
-- OUTPUT @SyncId,
--       @Created,
--       DELETED.ProductId,
--       DELETED.Name,
--       DELETED.Barcode,
--       DELETED.ProductTypeId,
--       DELETED.ProductGroupId,
--       DELETED.BrandId,
--       DELETED.CountryId,
--       DELETED.ProducerId,
--       DELETED.MeasureUnitId,
--       29,'Поле MeasureUnitId не ссылается на MeasureUnitId таблицы MeasureUnits'
-- INTO ERROR.Products
--(
--   SyncId,
--   SyncCreated,
--   ProductId,
--   Name,
--   Barcode,
--   ProductTypeId,
--   ProductGroupId,
--   BrandId,
--   CountryId,
--   ProducerId,
--   MeasureUnitId,
--   ErrorCode,
--   ErrorDescription
--)   
--FROM dbo.Products p
--WHERE NOT EXISTS (
--   SELECT 1
--   FROM dbo.MeasureUnits AS pt
--   WHERE pt.MeasureUnitId = p.MeasureUnitId
--)

INSERT INTO [error].[Products]
           ([SyncId]
           ,[SyncCreated]
           ,[ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[ErrorCode]
           ,[ErrorDescription])
	 SELECT @SyncId AS [SyncId]
		   ,@Created AS [SyncCreated]
           ,p.[ProductId]
           ,p.[Name]
           ,p.[Barcode]
           ,p.[ProductTypeId]
           ,p.[ProductGroupId]
           ,p.[BrandId]
           ,p.[CountryId]
           ,p.[ProducerId]
           ,p.[MeasureUnitId]
           ,29 AS [ErrorCode]
           ,N'Поле MeasureUnitId не ссылается на MeasureUnitId таблицы MeasureUnits' AS [ErrorDescription]
FROM [dbo].[Products] AS p
WHERE NOT EXISTS (
   SELECT 1
   FROM [dbo].[MeasureUnits] AS pt
   WHERE pt.[MeasureUnitId] = p.[MeasureUnitId]
)
 
 DELETE s
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreFormatId,
       DELETED.Name, 
       30,'Поле StoreFormatId содержит пустую строку'
 INTO ERROR.StoreFormats
(
   SyncId,
   SyncCreated,
   StoreFormatId,
   Name, 
   ErrorCode,
   ErrorDescription
)   
--SELECT s.StoreFormatId
FROM dbo.StoreFormats s
WHERE LTRIM(RTRIM(s.StoreFormatId)) = ''
  
 DELETE s
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreFormatId,
       DELETED.Name, 
       31,'Поле Name содержит пустую строку'
 INTO ERROR.StoreFormats
(
   SyncId,
   SyncCreated,
   StoreFormatId,
   Name, 
   ErrorCode,
   ErrorDescription
)     
FROM dbo.StoreFormats s
WHERE LTRIM(RTRIM(s.Name)) = ''

   
 DELETE c
 OUTPUT @SyncId,
       @Created,
       DELETED.ClusterId,
       DELETED.Name, 
       32,'Поле ClusterId содержит пустую строку'
 INTO ERROR.Clusters
(
   SyncId,
   SyncCreated,
   ClusterId,
   Name, 
   ErrorCode,
   ErrorDescription
)     
FROM dbo.Clusters AS c 
WHERE LTRIM(RTRIM(c.ClusterId)) = ''
      
   

 DELETE c
 OUTPUT @SyncId,
       @Created,
       DELETED.ClusterId,
       DELETED.Name, 
       33,'Поле Name содержит пустую строку'
 INTO ERROR.Clusters
(
   SyncId,
   SyncCreated,
   ClusterId,
   Name, 
   ErrorCode,
   ErrorDescription
)     
FROM dbo.Clusters AS c 
WHERE LTRIM(RTRIM(c.Name)) = ''
      
 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.RegionId,
       DELETED.ParentId,
       DELETED.Name, 
       34,'Поле RegionId содержит пустую строку'
 INTO ERROR.Regions
(
   SyncId,
   SyncCreated,
   RegionId,
   ParentId,
   Name, 
   ErrorCode,
   ErrorDescription
)     
FROM dbo.Regions AS r 
WHERE LTRIM(RTRIM(r.RegionId)) = ''


 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.RegionId,
       DELETED.ParentId,
       DELETED.Name, 
       35,'Поле RegionId содержит пустую строку'
 INTO ERROR.Regions
(
   SyncId,
   SyncCreated,
   RegionId,
   ParentId,
   Name, 
   ErrorCode,
   ErrorDescription
)     
FROM dbo.Regions AS r 
WHERE LTRIM(RTRIM(r.RegionId)) = ''


 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       36,'Поле StoreId содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.StoreId)) = ''



 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       37,'Поле Name содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.Name)) = ''
  

 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       38,'Поле ShortName содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.ShortName)) = '' 


 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       39,'Поле ShortName содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.ShortName)) = '' 


 DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       40,'Поле ShortName содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.ShortName)) = '' 

DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       40,'Поле StoreFormatId содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.StoreFormatId)) = '' 


DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       41,'Поле ClusterId содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.ClusterId)) = '' 


DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       42,'Поле RegionId содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.RegionId)) = '' 


DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       43,'Поле OpenDate содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.OpenDate)) = '' 
   AND r.OpenDate  IS NOT NULL 
   
DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       44,'Поле Area содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.Area)) = '' 
   
   
    
DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       45,'Поле CloseTime содержит пустую строку'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE LTRIM(RTRIM(r.CloseTime)) = '' 
  
DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       46,'Поле ClusterId не ссылается на ClusterId таблицы Clusters'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE NOT EXISTS ( 
   SELECT 1 
   FROM dbo.Clusters AS sf
   WHERE sf.ClusterId = r.ClusterId
)


     
DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       47,'Поле ClusterId ссылается на StoreFormatId таблицы StoreFormats'
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE NOT EXISTS ( 
   SELECT 1 
   FROM dbo.StoreFormats AS sf
   WHERE sf.StoreFormatId = r.StoreFormatId
)

     
DELETE r
 OUTPUT @SyncId,
       @Created,
       DELETED.StoreId,
       DELETED.Name,
       DELETED.ShortName,
       DELETED.StoreFormatId,
       DELETED.ClusterId,
       DELETED.RegionId,
       DELETED.OpenDate,
       DELETED.Area,
       DELETED.OpenTime,
       DELETED.CloseTime,
       DELETED.Timezone,
       48,'Поле RegionId не ссылается на RegionId таблицы Region '
 INTO ERROR.Stores
(
   SyncId,
   SyncCreated,
   StoreId,
   Name,
   ShortName,
   StoreFormatId,
   ClusterId,
   RegionId,
   OpenDate,
   Area,
   OpenTime,
   CloseTime,
   Timezone,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.Stores r
WHERE NOT EXISTS ( 
   SELECT 1 
   FROM dbo.Regions AS sf
   WHERE sf.RegionId = r.RegionId
)
   	
--14.	Поле RegionId ссылается на RegionId таблицы Region 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
		DELETED.Date,
		DELETED.Price,
       49,'Поле StoreId - содержит пустое значение '
 INTO ERROR.ProductMatrix
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   Date,
   Price,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.ProductMatrix r 
WHERE r.date >= @StartDate AND
 LTRIM(RTRIM(r.StoreId)) = ''

 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
		DELETED.Date,
		DELETED.Price,
       50,'Поле ProductId - содержит пустое значение '
 INTO ERROR.ProductMatrix
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   Date,
   Price,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.ProductMatrix r
WHERE r.date >= @StartDate AND
 LTRIM(RTRIM(r.ProductId)) = ''
 
 DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
		DELETED.Date,
		DELETED.Price,
       51,'Поле StoreId не ссылается на StoreId таблицы Stores'
 INTO ERROR.ProductMatrix
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   Date,
   Price,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.ProductMatrix r
WHERE r.date >= @StartDate AND
 NOT EXISTS ( SELECT 1 
              FROM dbo.Stores AS s
              WHERE s.StoreId = r.StoreId
 )
 
  DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
		DELETED.Date,
		DELETED.Price,
       52,'Поле ProductId не ссылается на ProductId таблицы Products'
 INTO ERROR.ProductMatrix
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   Date,
   Price,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.ProductMatrix r
WHERE r.date >= @StartDate AND
 NOT EXISTS ( SELECT 1 
              FROM dbo.Stores AS s
              WHERE s.StoreId = r.StoreId
 )
 	
           
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.PromoTypeId,
        DELETED.NAME,
        53,'Поле ProductId - содержит пустое значение '
 INTO ERROR.PromoTypes
(
   SyncId,
   SyncCreated,
   PromoTypeId,
   NAME,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.PromoTypes AS   r
WHERE 
 LTRIM(RTRIM(r.PromoTypeId)) = ''


DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.PromoTypeId,
        DELETED.NAME,
        54,'Поле Product Name - содержит пустое значение '
 INTO ERROR.PromoTypes
(
   SyncId,
   SyncCreated,
   PromoTypeId,
   NAME,
   ErrorCode,
   ErrorDescription
)   
FROM dbo.PromoTypes AS   r
WHERE 
 LTRIM(RTRIM(r.Name)) = ''
 
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId,
	   DELETED.ProductId,
	   DELETED.PromoId,
	   DELETED.Name,
	   DELETED.PromoTypeId,
	   DELETED.StartDate,
	   DELETED.EndDate,
	   DELETED.AdditionalPlacementQuantity, 
       55,'Поле StoreId - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE 
 LTRIM(RTRIM(r.StoreId)) = ''
 

DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	   DELETED.ProductId,
	   DELETED.PromoId,
	   DELETED.Name,
	   DELETED.PromoTypeId,
	   DELETED.StartDate,
	   DELETED.EndDate,
	   DELETED.AdditionalPlacementQuantity, 
       56,'Поле ProductId - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE 
 LTRIM(RTRIM(r.ProductId)) = ''
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	   DELETED.ProductId,
	   DELETED.PromoId,
	   DELETED.Name,
	   DELETED.PromoTypeId,
	   DELETED.StartDate,
	   DELETED.EndDate,
	   DELETED.AdditionalPlacementQuantity, 
       57,'Поле PromoId  - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE 
 LTRIM(RTRIM(r.PromoId )) = ''

 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	  DELETED.ProductId,
	  DELETED.PromoId,
	  DELETED.Name,
	  DELETED.PromoTypeId,
	  DELETED.StartDate,
	  DELETED.EndDate,
	  DELETED.AdditionalPlacementQuantity, 
       58,'Поле Name  - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE 
 LTRIM(RTRIM(r.Name )) = ''
 
 DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	   DELETED.ProductId,
	   DELETED.PromoId,
	   DELETED.Name,
	   DELETED.PromoTypeId,
	   DELETED.StartDate,
	   DELETED.EndDate,
	   DELETED.AdditionalPlacementQuantity, 
       59,'Поле PromoTypeId  - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE 
 LTRIM(RTRIM(r.PromoTypeId )) = ''
 
 
 DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId,
	   DELETED.ProductId,
	   DELETED.PromoId,
	   DELETED.Name,
	   DELETED.PromoTypeId,
	   DELETED.StartDate,
	   DELETED.EndDate,
	   DELETED.AdditionalPlacementQuantity, 
       60,'Поле AdditionalPlacementQuantity  - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   PromoId,
   Name,
   PromoTypeId,
   StartDate,
   EndDate,
   AdditionalPlacementQuantity, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.Promotions r
WHERE r.AdditionalPlacementQuantity  IS  NULL



 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
       61,'Поле StoreId - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.KviProducts r
WHERE 
 LTRIM(RTRIM(r.StoreId)) = ''
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
       62,'Поле ProductId - содержит пустое значение '
 INTO ERROR.Promotions
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.KviProducts r
WHERE 
 LTRIM(RTRIM(r.ProductId)) = ''
 
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
       64,' Поле StoreId не ссылается на StoreId таблицы Stores'
 INTO ERROR.KviProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.KviProducts r
WHERE 
 NOT EXISTS ( SELECT 1 FROM dbo.Stores AS s 
              WHERE s.StoreId = r.StoreId
 )
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
       65,' Поле ProductId не ссылается на ProductId таблицы Products'
 INTO ERROR.KviProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.KviProducts r
WHERE 
 NOT EXISTS ( SELECT 1 
              FROM dbo.Products AS s 
              WHERE s.ProductId = r.ProductId
 )
 
 
 --------------------------------------------------
  
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
        DELETED.ABCCategory,
       66,'Поле StoreId - содержит пустое значение '
 INTO ERROR.AbcProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ABCCategory, 
   ErrorCode,
   ErrorDescription
)    
--SELECT r.ABCCategory
FROM dbo. AbcProducts AS  r
WHERE 
 LTRIM(RTRIM(r.StoreId)) = ''
 
 
   
DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId,
	   DELETED.ProductId,
       DELETED.ABCCategory,
       67,'Поле ProductId - содержит пустое значение '
 INTO ERROR.AbcProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ABCCategory, 
   ErrorCode,
   ErrorDescription
)    
--SELECT r.ABCCategory
FROM dbo. AbcProducts AS  r
WHERE 
 LTRIM(RTRIM(r.ProductId)) = ''
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
        DELETED.ABCCategory, 
       68,' Поле StoreId не ссылается на StoreId таблицы Stores'
 INTO ERROR.AbcProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId, 
   ABCCategory, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.AbcProducts r
WHERE 
 NOT EXISTS ( SELECT 1 FROM dbo.Stores AS s 
              WHERE s.StoreId = r.StoreId
 )
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
        DELETED.StoreId,
	    DELETED.ProductId,
        DELETED.ABCCategory, 
       69,' Поле ProductId не ссылается на ProductId таблицы Products'
 INTO ERROR.AbcProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ABCCategory,  
   ErrorCode,
   ErrorDescription
)    
FROM dbo.AbcProducts r
WHERE 
 NOT EXISTS ( SELECT 1 
              FROM dbo.Products AS s 
              WHERE s.ProductId = r.ProductId
 )
 
 
 
DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId,
	   DELETED.ProductId,
       DELETED.ABCCategory, 
       70,'Поле ABCCategory заполняется одним из следующих значений: «A», «B» или «C»'
 INTO ERROR.AbcProducts
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ABCCategory,  
   ErrorCode,
   ErrorDescription
)    
FROM dbo.AbcProducts r
WHERE  r.ABCCategory NOT IN ('A','B','C')
 
