﻿CREATE TABLE [dbo].[Brands] (
    [BrandId] NVARCHAR (32)  NOT NULL,
    [Name]    NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_Brands] PRIMARY KEY CLUSTERED ([BrandId] ASC)
);

