﻿CREATE TABLE [dbo].[StagingSyncs] (
    [SyncId]        INT      NOT NULL,
    [StagingTypeId] INT      NOT NULL,
    [Created]       DATETIME NOT NULL,
    CONSTRAINT [PK_StagingSyncs] PRIMARY KEY CLUSTERED ([SyncId] ASC),
    CONSTRAINT [FK_StagingSyncs_StagingTypes] FOREIGN KEY ([StagingTypeId]) REFERENCES [dbo].[StagingTypes] ([Id])
);

