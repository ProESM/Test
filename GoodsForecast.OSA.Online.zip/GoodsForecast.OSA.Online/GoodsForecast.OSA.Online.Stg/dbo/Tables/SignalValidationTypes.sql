﻿CREATE TABLE [dbo].[SignalValidationTypes] (
    [SignalValidationTypeId] INT            NOT NULL,
    [Name]                   NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_SignalValidationTypes] PRIMARY KEY CLUSTERED ([SignalValidationTypeId] ASC)
);

