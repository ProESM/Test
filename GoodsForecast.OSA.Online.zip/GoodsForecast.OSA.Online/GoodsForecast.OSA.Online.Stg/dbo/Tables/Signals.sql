﻿CREATE TABLE [dbo].[Signals] (
    [SignalId]               BIGINT        IDENTITY (1, 1) NOT NULL,
    [ParentId]               BIGINT        NULL,
    [StoreId]                NVARCHAR (32) NOT NULL,
    [ProductId]              NVARCHAR (32) NOT NULL,
    [SignalDateTime]         DATETIME      NOT NULL,
    [ABCCategory]            VARCHAR (1)   NULL,
    [IsKVI]                  BIT           NOT NULL,
    [IsPromo]                BIT           NOT NULL,
    [IsRepeated]             BIT           NOT NULL,
    [LostSalesStartDateTime] DATETIME      NOT NULL,
    [LostSalesQuantity]      REAL          NOT NULL,
    [LostSalesMoney]         REAL          NOT NULL,
    CONSTRAINT [PK_Signals] PRIMARY KEY CLUSTERED ([SignalId] ASC)
);


GO
ALTER TABLE [dbo].[Signals] ENABLE CHANGE_TRACKING WITH (TRACK_COLUMNS_UPDATED = ON);

