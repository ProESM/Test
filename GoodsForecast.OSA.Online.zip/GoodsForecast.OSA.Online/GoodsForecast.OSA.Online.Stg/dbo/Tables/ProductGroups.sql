﻿CREATE TABLE [dbo].[ProductGroups] (
    [ProductGroupId] NVARCHAR (32)  NOT NULL,
    [ParentId]       NVARCHAR (32)  NULL,
    [Name]           NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_ProductGroups] PRIMARY KEY CLUSTERED ([ProductGroupId] ASC)
);

