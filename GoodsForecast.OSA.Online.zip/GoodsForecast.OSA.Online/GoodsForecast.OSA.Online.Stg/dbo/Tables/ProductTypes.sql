﻿CREATE TABLE [dbo].[ProductTypes] (
    [ProductTypeId] NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_ProductTypes] PRIMARY KEY CLUSTERED ([ProductTypeId] ASC)
);

