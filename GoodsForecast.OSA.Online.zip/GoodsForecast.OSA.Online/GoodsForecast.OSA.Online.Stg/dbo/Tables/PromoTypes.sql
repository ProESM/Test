﻿CREATE TABLE [dbo].[PromoTypes] (
    [PromoTypeId] NVARCHAR (32)  NOT NULL,
    [Name]        NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_PromoTypes] PRIMARY KEY CLUSTERED ([PromoTypeId] ASC)
);

