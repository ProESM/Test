﻿CREATE TABLE [dbo].[KviProducts] (
    [StoreId]   NVARCHAR (32) NOT NULL,
    [ProductId] NVARCHAR (32) NOT NULL,
    CONSTRAINT [PK_KviProducts] PRIMARY KEY CLUSTERED ([StoreId] ASC, [ProductId] ASC)
);

