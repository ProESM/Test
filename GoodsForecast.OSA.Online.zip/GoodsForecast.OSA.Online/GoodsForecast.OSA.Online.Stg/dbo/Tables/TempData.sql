﻿CREATE TABLE [dbo].[TempData] (
    [StoreExternalId] NVARCHAR (50) NULL,
    [ØÊ èç âûãðóçêè]  NVARCHAR (50) NULL
);

