﻿CREATE TABLE [dbo].[ProductMatrix] (
    [StoreId]   NVARCHAR (32) NOT NULL,
    [ProductId] NVARCHAR (32) NOT NULL,
    [Date]      DATE          NOT NULL,
    [Price]     REAL          NOT NULL
);

