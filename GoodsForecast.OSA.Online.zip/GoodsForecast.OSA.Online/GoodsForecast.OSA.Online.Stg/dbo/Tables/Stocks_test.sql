﻿CREATE TABLE [dbo].[Stocks_test] (
    [StoreId]       NVARCHAR (32) NOT NULL,
    [ProductId]     NVARCHAR (32) NOT NULL,
    [Datetime]      DATETIME      NOT NULL,
    [StockQuantity] REAL          NOT NULL,
    [Created]       DATETIME      DEFAULT (getutcdate()) NOT NULL
);

