﻿CREATE TABLE [dbo].[AbcProducts] (
    [StoreId]     NVARCHAR (32) NOT NULL,
    [ProductId]   NVARCHAR (32) NOT NULL,
    [ABCCategory] VARCHAR (1)   NOT NULL,
    CONSTRAINT [PK_AbcProducts] PRIMARY KEY CLUSTERED ([StoreId] ASC, [ProductId] ASC, [ABCCategory] ASC)
);

