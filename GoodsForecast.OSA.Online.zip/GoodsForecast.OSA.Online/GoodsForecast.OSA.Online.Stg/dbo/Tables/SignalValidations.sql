﻿CREATE TABLE [dbo].[SignalValidations] (
    [SignalId]               BIGINT        NOT NULL,
    [ValidationDateTime]     DATETIME      NOT NULL,
    [IsCorrect]              BIT           NOT NULL,
    [SignalValidationTypeId] INT           NOT NULL,
    [ValidationDescription]  NVARCHAR (80) NULL,
    [AuditorName]            NVARCHAR (80) NULL,
    CONSTRAINT [PK_SignalValidations] PRIMARY KEY CLUSTERED ([SignalId] ASC)
);

