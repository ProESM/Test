﻿CREATE TABLE [dbo].[StagingSyncJournal] (
    [SyncId]          INT      NOT NULL,
    [StagingStatusId] INT      NOT NULL,
    [Created]         DATETIME NOT NULL,
    CONSTRAINT [FK_StagingSyncJournal_StagingStatuses] FOREIGN KEY ([StagingStatusId]) REFERENCES [dbo].[StagingStatuses] ([Id]),
    CONSTRAINT [FK_StagingSyncJournal_StagingSyncs] FOREIGN KEY ([SyncId]) REFERENCES [dbo].[StagingSyncs] ([SyncId])
);

