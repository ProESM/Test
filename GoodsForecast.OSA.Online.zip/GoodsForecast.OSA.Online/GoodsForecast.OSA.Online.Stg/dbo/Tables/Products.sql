﻿CREATE TABLE [dbo].[Products] (
    [ProductId]      NVARCHAR (32)  NOT NULL,
    [Name]           NVARCHAR (256) NOT NULL,
    [Barcode]        NVARCHAR (80)  NOT NULL,
    [ProductTypeId]  NVARCHAR (32)  NOT NULL,
    [ProductGroupId] NVARCHAR (32)  NOT NULL,
    [BrandId]        NVARCHAR (32)  NOT NULL,
    [CountryId]      NVARCHAR (32)  NULL,
    [ProducerId]     NVARCHAR (32)  NULL,
    [MeasureUnitId]  NVARCHAR (32)  NOT NULL,
    [CrystalId]      NVARCHAR (32)  NULL,
    CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED ([ProductId] ASC)
);


GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Products_AI]
   ON  [dbo].[Products]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[TmpProducts]
           ([ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,[Created]
		   ,[SystemUserName]
		   ,[ActionType])
     SELECT [ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,GETDATE()
		   ,SYSTEM_USER
		   ,N'INSERT'
	FROM INSERTED
END

GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Products_AD]
   ON  [dbo].[Products]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[TmpProducts]
           ([ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,[Created]
		   ,[SystemUserName]
		   ,[ActionType])
     SELECT [ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,GETDATE()
		   ,SYSTEM_USER
		   ,N'DELETE'
	FROM DELETED
END

GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Products_AU]
   ON  [dbo].[Products]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[TmpProducts]
           ([ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,[Created]
		   ,[SystemUserName]
		   ,[ActionType])
     SELECT [ProductId]
           ,[Name]
           ,[Barcode]
           ,[ProductTypeId]
           ,[ProductGroupId]
           ,[BrandId]
           ,[CountryId]
           ,[ProducerId]
           ,[MeasureUnitId]
           ,[CrystalId]
		   ,GETDATE()
		   ,SYSTEM_USER
		   ,N'UPDATE'
	FROM INSERTED
END
