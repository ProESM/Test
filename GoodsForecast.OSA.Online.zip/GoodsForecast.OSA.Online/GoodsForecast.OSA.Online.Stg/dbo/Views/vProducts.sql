﻿CREATE VIEW dbo.vProducts
AS
SELECT       pr.ProductId, pr.Name, pr.Barcode, pr.ProductTypeId, pr.ProductGroupId, pr.BrandId, pr.CountryId, prd.ProducerId, pr.MeasureUnitId, pr.CrystalId
FROM            dbo.Products AS pr WITH (nolock) INNER JOIN
                         dbo.ProductTypes AS pt WITH (nolock) ON pt.ProductTypeId = pr.ProductTypeId INNER JOIN
                         dbo.ProductGroups AS pg WITH (nolock) ON pg.ProductGroupId = pr.ProductGroupId INNER JOIN
                         dbo.MeasureUnits AS mu WITH (nolock) ON mu.MeasureUnitId = pr.MeasureUnitId LEFT OUTER JOIN
                         dbo.Brands AS b WITH (nolock) ON b.BrandId = pr.BrandId LEFT OUTER JOIN
                         dbo.Countries AS c WITH (nolock) ON c.CountryId = pr.CountryId LEFT OUTER JOIN
                         dbo.Producers AS prd WITH (nolock) ON prd.ProducerId = pr.ProducerId
WHERE        (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NULL) AND (pr.CountryId IS NULL) AND (pr.ProducerId IS NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NOT NULL) AND (pr.CountryId IS NULL) AND (pr.ProducerId IS NULL) AND (b.BrandId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NULL) AND (pr.CountryId IS NOT NULL) AND (pr.ProducerId IS NULL) AND (c.CountryId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NOT NULL) AND (pr.CountryId IS NOT NULL) AND (pr.ProducerId IS NULL) AND (b.BrandId IS NOT NULL) AND (c.CountryId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NULL) AND (pr.CountryId IS NULL) AND (pr.ProducerId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NOT NULL) AND (pr.CountryId IS NULL) AND (pr.ProducerId IS NOT NULL) AND (b.BrandId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NULL) AND (pr.CountryId IS NOT NULL) AND (pr.ProducerId IS NOT NULL) AND (c.CountryId IS NOT NULL) OR
                         (pr.Name IS NOT NULL) AND (pr.Barcode IS NOT NULL) AND (pr.BrandId IS NOT NULL) AND (pr.CountryId IS NOT NULL) AND (pr.ProducerId IS NOT NULL) AND (b.BrandId IS NOT NULL) AND (c.CountryId IS NOT NULL)

GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane1', @value = N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[40] 4[20] 2[20] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = 0
         Left = 0
      End
      Begin Tables = 
         Begin Table = "pr"
            Begin Extent = 
               Top = 6
               Left = 38
               Bottom = 136
               Right = 212
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "pt"
            Begin Extent = 
               Top = 6
               Left = 250
               Bottom = 102
               Right = 420
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "pg"
            Begin Extent = 
               Top = 102
               Left = 250
               Bottom = 215
               Right = 424
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "mu"
            Begin Extent = 
               Top = 138
               Left = 38
               Bottom = 234
               Right = 208
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "b"
            Begin Extent = 
               Top = 216
               Left = 246
               Bottom = 312
               Right = 416
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "c"
            Begin Extent = 
               Top = 234
               Left = 38
               Bottom = 330
               Right = 208
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "prd"
            Begin Extent = 
               Top = 312
               Left = 246
               Bottom = 408
               Right = 416
            End
            DisplayFlags = 280
            TopColumn = 0
        ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vProducts';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPane2', @value = N' End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 16
         Column = 1440
         Alias = 900
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
         Or = 1350
         Or = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vProducts';


GO
EXECUTE sp_addextendedproperty @name = N'MS_DiagramPaneCount', @value = 2, @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'VIEW', @level1name = N'vProducts';

