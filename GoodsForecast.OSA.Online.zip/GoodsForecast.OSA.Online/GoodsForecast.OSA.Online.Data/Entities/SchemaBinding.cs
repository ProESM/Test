﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Привязка схем
    /// </summary>
    [Table("SchemaBindings")]
    public class SchemaBinding
    {
        [Key]
        public long Id { get; set; }

        [ForeignKey("StoreGroups")]
        public int? StoreGroupId { get; set; }
        public StoreGroup StoreGroup { get; set; }

        [ForeignKey("Locations")]
        public int? StoreId { get; set; }
        public Location Location { get; set; }

        public byte SchemeId { get; set; }
        [ForeignKey("SchemeId")]
        public LostSalesAnalysisSchema LostSalesAnalysisSchema { get; set; }

        public bool IsActive { get; set; }
        public DateTime Created { get; set; }
    }
}
