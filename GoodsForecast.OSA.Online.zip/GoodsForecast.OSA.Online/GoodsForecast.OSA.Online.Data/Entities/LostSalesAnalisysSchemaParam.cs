﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Параметры схемы расчета
    /// </summary>
    [Table("LostSalesAnalisysSchemaParams")]
    public class LostSalesAnalisysSchemaParam
    {
        public byte Id { get; set; }
        public byte SchemaId { get; set; }
        [ForeignKey("SchemaId")]
        public LostSalesAnalysisSchema LostSalesAnalysisSchema { get; set; }
        public string Key { get; set; }
        public string Description { get; set; }
        public string Value { get; set; }
    }
}
