﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь пользователей и операционных групп
    /// </summary>
    [Table("ConsolidatedReportUserOperationGroups", Schema = "rep")]
    public class ConsolidatedReportUserOperationGroup
    {
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }

        public int OperationGroupId { get; set; }
        [ForeignKey("OperationGroupId")]
        public OperationGroup OperationGroup { get; set; }
    }
}
