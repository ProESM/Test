﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Тип батча
    /// </summary>
    [Table("BatchTypes")]
    public class BatchType
    {
        [Key]
        public byte Id { get; set; }
        public string Name { get; set; }

        public ICollection<LostSalesAnalysisBatch> LostSalesAnalysisBatches { get; set; }
    }
}
