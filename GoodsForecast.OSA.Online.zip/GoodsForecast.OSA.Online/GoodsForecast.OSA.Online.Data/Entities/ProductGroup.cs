﻿using Microsoft.SqlServer.Types;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("ProductGroups")]
    public class ProductGroup
    {
        [Key]
        public int Id { get; set; }
        public string ExternalId { get; set; }
        public string ExternalParentId { get; set; }
        public int Level { get; set; }
        public string Name { get; set; }

        [ForeignKey("Id")]
        public int? ParentId { get; set; }
        public ProductGroup ParentProductGroup { get; set; }

        public bool IsActive { get; set; }

        [NotMapped]
        public SqlHierarchyId HId { get; set; }

        public ICollection<ProductGroup> ProductGroups { get; set; }
        public ICollection<Product> Products { get; set; }
    }
}
