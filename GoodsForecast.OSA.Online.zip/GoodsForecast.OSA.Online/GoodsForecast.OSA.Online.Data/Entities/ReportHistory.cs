﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("ReportHistory", Schema = "rep")]
    public class ReportHistory
    {
        [Key]
        public long Id { get; set; }
        [ForeignKey("Jobs")]
        public long JobId { get; set; }
        public byte[] FileData { get; set; }
        public string FileName { get; set; }
        public string Recepients { get; set; }

        public Job Job { get; set; }
    }
}
