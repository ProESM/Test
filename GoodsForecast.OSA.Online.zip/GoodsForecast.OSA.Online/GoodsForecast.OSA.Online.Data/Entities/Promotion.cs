﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("Promotions")]
    public class Promotion
    {
        [Key]
        public int Id { get; set; }
        public string ExternalId { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        [ForeignKey("PromotionTypes")]
        public int PromotionTypeId { get; set; }
        public PromotionType PromotionType { get; set; }

        public bool IsActive { get; set; }

        public ICollection<PromotionMatrix> PromotionMatrix { get; set; }
    }
}
