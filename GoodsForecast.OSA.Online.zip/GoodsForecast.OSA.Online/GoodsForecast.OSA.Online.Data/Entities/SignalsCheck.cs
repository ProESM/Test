﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    public class SignalsCheck
    {
        public string Description { get; set; }
        public string Email { get; set; }
    }
}
