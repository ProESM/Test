﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Cтатусы расчета
    /// </summary>
    [Table("AnalysisStatuses")]
    public class AnalysisStatus
    {
        [Key]
        public byte Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }

        public ICollection<LostSalesAnalysisJob> LostSalesAnalysisJobs { get; set; }
    }
}
