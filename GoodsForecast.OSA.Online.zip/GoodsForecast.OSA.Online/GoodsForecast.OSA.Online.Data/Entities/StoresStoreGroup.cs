﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь магазинов с группами
    /// </summary>
    [Table("StoresStoreGroups")]
    public class StoresStoreGroup
    {
        [ForeignKey("StoreGroups")]
        public int StoreGroupId { get; set; }
        public StoreGroup StoreGroup { get; set; }

        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }
    }
}
