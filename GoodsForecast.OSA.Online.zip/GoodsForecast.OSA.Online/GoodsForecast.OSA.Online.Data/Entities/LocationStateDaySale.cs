﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Продажи по дням
    /// </summary>
    [Table("LocationStateDaySales")]
    public class LocationStateDaySale
    {
        /// <summary>
        /// Магазин
        /// </summary>
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        /// <summary>
        /// Дата продажи
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public float Quantity { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public float PriceSum { get; set; }
    }
}
