﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Типы рассылок
    /// </summary>
    [Table("Notifications", Schema = "mng")]
    public class Notification
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Тип рассылки
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Получатели
        /// </summary>
        public string Recipients { get; set; }
    }
}

