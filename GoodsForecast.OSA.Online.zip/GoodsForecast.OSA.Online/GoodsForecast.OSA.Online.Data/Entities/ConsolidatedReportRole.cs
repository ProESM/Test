﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь типов отчетов и ролей
    /// </summary>
    [Table("ConsolidatedReportRoles", Schema = "rep")]
    public class ConsolidatedReportRole
    {
        /// <summary>
        /// Тип отчета
        /// </summary>
        public byte ConsolidatedReportTypeId { get; set; }
        [ForeignKey("ConsolidatedReportTypeId")]
        public ConsolidatedReportType ConsolidatedReportType { get; set; }

        /// <summary>
        /// Роль
        /// </summary>
        public int RoleId { get; set; }
        [ForeignKey("RoleId")]
        public Role Role { get; set; }
    }
}
