﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    public class SignalsFeedbackReport
    {
        /// <summary>
        /// Дата и время
        /// </summary>
        public DateTime SignalDateTime { get; set; }

        /// <summary>
        /// Час сигнала
        /// </summary>
        public byte SignalHour { get; set; }

        /// <summary>
        /// С запозданием?
        /// </summary>
        public byte IsLate { get; set; }

        /// <summary>
        /// Ид сигнала
        /// </summary>
        public long SignalId { get; set; }

        /// <summary>
        /// Ид магазина
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Код магазина
        /// </summary>
        public string StoreCode { get; set; }

        /// <summary>
        /// Название магазина
        /// </summary>
        public string StoreName { get; set; }

        /// <summary>
        /// Магазин в ОЭ
        /// </summary>
        public byte IsInPilot { get; set; }

        /// <summary>
        /// Ид товара
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Код товара
        /// </summary>
        public string ProductExternalId { get; set; }

        /// <summary>
        /// Наименование товара
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Обратная связь
        /// </summary>
        public byte CheckResult { get; set; }

        /// <summary>
        /// Проверяющий
        /// </summary>
        public string AuditorName { get; set; }

        /// <summary>
        /// Дата проверки
        /// </summary>
        public DateTime ValidationDateTime { get; set; }

        /// <summary>
        /// Описание
        /// </summary>
        public string Description { get; set; }
    }
}
