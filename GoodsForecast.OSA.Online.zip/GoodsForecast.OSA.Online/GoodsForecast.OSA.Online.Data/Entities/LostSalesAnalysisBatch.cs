﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Батчи
    /// </summary>
    [Table("LostSalesAnalysisBatches")]
    public class LostSalesAnalysisBatch
    {
        [Key]
        public long Id { get; set; }

        [ForeignKey("LostSalesAnalysisJobs")]
        public long LostSalesAnalysisJobId { get; set; }
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }

        [ForeignKey("LostSalesAnalysisSubJobs")]
        public long LostSalesAnalysisSubJobId { get; set; }
        public LostSalesAnalysisSubJob LostSalesAnalysisSubJob { get; set; }

        [ForeignKey("BatchTypes")]
        public byte BatchTypeId { get; set; }
        public BatchType BatchType { get; set; }

        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }

        public ICollection<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatches { get; set; }
    }
}
