﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Тип алгоритма
    /// </summary>
    [Table("AlgTypes")]
    public class AlgType
    {
        [Key]
        public byte Id { get; set; }
        public string Name { get; set; }
    }
}
