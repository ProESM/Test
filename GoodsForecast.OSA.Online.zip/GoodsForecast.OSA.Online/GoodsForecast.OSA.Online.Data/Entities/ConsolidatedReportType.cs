﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Типы сводных отчетов
    /// </summary>
    [Table("ConsolidatedReportTypes", Schema = "rep")]
    public class ConsolidatedReportType
    {
        [Key]
        public byte Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public ICollection<ReportType> ReportTypes { get; set; }
        public ICollection<ConsolidatedReportRole> ConsolidatedReportRoles { get; set; }
    }
}
