﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь пользователей и магазинов
    /// </summary>
    [Table("ConsolidatedReportUserStores", Schema = "rep")]
    public class ConsolidatedReportUserStore
    {
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }

        public int StoreId { get; set; }
        [ForeignKey("StoreId")]
        public Location Location { get; set; }
    }
}
