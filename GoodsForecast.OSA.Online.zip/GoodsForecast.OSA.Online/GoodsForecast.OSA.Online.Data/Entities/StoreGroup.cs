﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Группы магазинов для расчета по 2 алгоритму
    /// </summary>
    [Table("StoreGroups")]
    public class StoreGroup
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public ICollection<StoresStoreGroup> StoresStoreGroups { get; set; }
        public ICollection<SchemaBinding> SchemaBindings { get; set; }
        public ICollection<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }
    }
}
