﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("ProductMatrix")]
    public class ProductMatrix
    {
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        public DateTime Date { get; set; }
        public bool IsKvi { get; set; }
        public bool IsPromo { get; set; }
        public float Price { get; set; }
        public string AbcCategory { get; set; }
    }
}
