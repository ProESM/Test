﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Тип отчета
    /// </summary>
    [Table("ReportTypes", Schema = "mng")]
    public class ReportType
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Тип файла (excel, csv..)
        /// </summary>
        public byte ExtensionType { get; set; }

        /// <summary>
        /// Описание отчета
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Тема письма с отчетом
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// Тело письма с отчетом
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// Тип отчета
        /// </summary>
        public string ReportName { get; set; }

        /// <summary>
        /// Период: 0 - неделя/ 1 - месяц
        /// </summary>
        public byte? PeriodType { get; set; }

        /// <summary>
        /// Способ доставки отчетов : 0 - по почте/ 1 - в сетевую папку
        /// </summary>
        public byte? ReportDeliveryType { get; set; }

        /// <summary>
        /// Сетевая папка
        /// </summary>
        public string NetFolder { get; set; }

        /// <summary>
        /// Тип сводного отчета
        /// </summary>
        public byte? ConsolidatedReportTypeId { get; set; }

        [ForeignKey("ConsolidatedReportTypeId")]
        public ConsolidatedReportType ConsolidatedReportType { get; set; }
    }
}
