﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Названия праздников (специальных периодов)
    /// </summary>
    [Table("Holidays")]
    public class Holiday
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public bool IsStrongType { get; set; }

        public ICollection<HolidayPeriod> HolidayPeriods { get; set; }
    }
}
