﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Продажи по часам
    /// </summary>
    [Table("LocationStateHourSales")]
    public class LocationStateHourSale
    {
        /// <summary>
        /// Магазин
        /// </summary>
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        /// <summary>
        /// Дата и время продажи
        /// </summary>
        public DateTime Datetime { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public float Quantity { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public float PriceSum { get; set; }
    }
}
