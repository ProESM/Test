﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("PromoPeriods")]
    public class PromoPeriod
    {
        public int LocationId { get; set; }
        public int ProductId { get; set; }
        public DateTime DtBegin { get; set; }
        public DateTime DtEnd { get; set; }
    }
}
