﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Остатки
    /// </summary>
    [Table("LocationStateStocks")]
    public class LocationStateStock
    {
        /// <summary>
        /// Магазин
        /// </summary>
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        /// <summary>
        /// Дата остатка
        /// </summary>
        public DateTime Datetime { get; set; }

        /// <summary>
        /// Количество
        /// </summary>
        public float Quantity { get; set; }
    }
}
