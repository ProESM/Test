﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь пользователей и регионов
    /// </summary>
    [Table("ConsolidatedReportUserRegions", Schema = "rep")]
    public class ConsolidatedReportUserRegion
    {
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }

        public int RegionId { get; set; }
        [ForeignKey("RegionId")]
        public StoreRegion StoreRegion { get; set; }
    }
}
