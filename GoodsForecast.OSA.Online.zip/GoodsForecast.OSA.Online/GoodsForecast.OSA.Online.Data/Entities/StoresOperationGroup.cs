﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Связь операционных групп с магазинами
    /// </summary>
    [Table("StoresOperationGroups")]
    public class StoresOperationGroup
    {
        public int OperationGroupId { get; set; }
        [ForeignKey("OperationGroupId")]
        public OperationGroup OperationGroup { get; set; }

        public int LocationId { get; set; }
        [ForeignKey("LocationId")]
        public Location Location { get; set; }
    }
}
