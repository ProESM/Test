﻿using EntityFrameworkExtras.EF6;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [UserDefinedTableType("RelatedStores")]
    public class RelatedStore
    {
        [UserDefinedTableTypeColumn(1)]
        public int LocationId { get; set; }
        [UserDefinedTableTypeColumn(2)]
        public int ProductId { get; set; }
        [UserDefinedTableTypeColumn(3)]
        public DateTime StartDateTime { get; set; }
        [UserDefinedTableTypeColumn(4)]
        public DateTime EndDateTime { get; set; }
    }
}
