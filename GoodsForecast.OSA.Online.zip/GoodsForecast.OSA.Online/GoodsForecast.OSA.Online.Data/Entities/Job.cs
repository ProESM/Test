﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("Jobs", Schema = "mng")]
    public class Job
    {
        [Key]
        public long Id { get; set; }

        [ForeignKey("JobSchedules")]
        public int JobScheduleId { get; set; }
        public JobSchedule JobSchedule { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int Status { get; set; }
        public IEnumerable<ReportHistory> ReportHistory { get; set; }
        public IEnumerable<LostSalesAnalysisJob> LostSalesAnalysisJobs { get; set; }

    }
}

