﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Магазины
    /// </summary>
    [Table("Locations")]
    public class Location
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Идентификатор магазина в ПБД
        /// </summary>
        public string ExternalId { get; set; }

        /// <summary>
        /// Название магазина
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Краткое название магазина
        /// </summary>
        public string ShortName { get; set; }

        /// <summary>
        /// Формат магазина
        /// </summary>
        [ForeignKey("StoreFormats")]
        public int? StoreFormatId { get; set; }
        public StoreFormat StoreFormat { get; set; }

        /// <summary>
        /// Кластер магазина
        /// </summary>
        [ForeignKey("StoreClusters")]
        public int? StoreClusterId { get; set; }
        public StoreCluster StoreCluster { get; set; }

        /// <summary>
        /// Регион магазина
        /// </summary>
        [ForeignKey("StoreRegions")]
        public int? StoreRegionId { get; set; }
        public StoreRegion StoreRegion { get; set; }

        /// <summary>
        /// Дата открытия магазина
        /// </summary>
        public DateTime? OpenDate { get; set; }

        /// <summary>
        /// Площадь магазина
        /// </summary>
        public float? Area { get; set; }

        /// <summary>
        /// Время открытия магазина
        /// </summary>
        public TimeSpan? OpenTime { get; set; }

        /// <summary>
        /// Время закрытия магазина
        /// </summary>
        public TimeSpan? CloseTime { get; set; }

        /// <summary>
        /// Тип - магазин или не магазин
        /// </summary>
        public string TypeKey { get; set; }

        /// <summary>
        /// Часовой пояс
        /// </summary>
        public int Timezone { get; set; }

        /// <summary>
        /// Признак активности
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Задачи на расчет по магазину
        /// </summary>
        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }

        /// <summary>
        /// Продукты в магазине
        /// </summary>
        public ICollection<Product> Products { get; set; }

        /// <summary>
        /// Продуктовая матрица
        /// </summary>
        public ICollection<ProductMatrix> ProductMatrix { get; set; }

        /// <summary>
        /// Матрица промоакций
        /// </summary>
        public ICollection<PromotionMatrix> PromotionMatrix { get; set; }


        /// <summary>
        /// Результаты расчета по перриодам в магазине
        /// </summary>
        public ICollection<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods { get; set; }

        /// <summary>
        /// Продажи по дням в магазине
        /// </summary>
        public ICollection<LocationStateDaySale> LocationStateDaySales { get; set; }

        /// <summary>
        /// Продажи по часам в магазине
        /// </summary>
        public ICollection<LocationStateHourSale> LocationStateHourSales { get; set; }

        /// <summary>
        /// Субджобы
        /// </summary>
        public ICollection<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }

        /// <summary>
        /// Привязки схем
        /// </summary>
        public ICollection<SchemaBinding> SchemaBindings { get; set; }

        /// <summary>
        /// Пачки для расчета
        /// </summary>
        public ICollection<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatchs { get; set; }

        /// <summary>
        /// Группы магазинов для расчета
        /// </summary>
        public ICollection<StoresStoreGroup> StoresStoreGroups { get; set; }

        /// <summary>
        /// Операционные группы
        /// </summary>
        public ICollection<StoresOperationGroup> StoresOperationGroups { get; set; }
        public ICollection<ConsolidatedReportUserStore> ConsolidatedReportUserStores { get; set; }

    }
}
