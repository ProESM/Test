﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Результаты расчета по часам
    /// </summary>
    [Table("LostSalesAnalysisResultHourlies")]
    public class LostSalesAnalysisResultHourly
    {
        /// <summary>
        /// Задача на расчет
        /// </summary>
        [ForeignKey("LostSalesAnalysisTasks")]
        public long LostSalesAnalysisTaskId { get; set; }
        public LostSalesAnalysisTask LostSalesAnalysisTask { get; set; }
        
        /// <summary>
        /// Задание на расчет
        /// </summary>
        public long LostSalesAnalysisJobId { get; set; }
        [ForeignKey("LostSalesAnalysisJobId")]
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>       
        public int LocationId { get; set; }
        [ForeignKey("LocationId")]
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>              
        public int ProductId { get; set; }
        [ForeignKey("ProductId")]
        public Product Product { get; set; }

        /// <summary>
        /// Начало периода
        /// </summary>
        public DateTime Datetime { get; set; }

        /// <summary>
        /// Вероятность
        /// </summary>
        public float? Probability { get; set; }

        /// <summary>
        /// Количество упущенных продаж
        /// </summary>
        public float? Quantity { get; set; }

        /// <summary>
        /// Дата и время сигнала
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Является ли сигналом
        /// </summary>
        public bool? IsPhantom { get; set; }

        /// <summary>
        /// Рассчитано в TSA
        /// </summary>
        public bool? IsCalculatedInTsa { get; set; }
    }
}
