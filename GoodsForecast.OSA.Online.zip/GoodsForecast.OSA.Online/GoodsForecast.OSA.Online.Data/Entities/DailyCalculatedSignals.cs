﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Отчёт по произведенным расчётам за день
    /// </summary>
    public class DailyCalculatedSignals
    {
        /// <summary>
        /// Ид
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Ид джоба
        /// </summary>
        public long JobId { get; set; }

        /// <summary>
        /// дата/время запуска генерации сигналов (в локальном времени магазинов)
        /// </summary>
        public DateTime LocalDateTime { get; set; }

        /// <summary>
        /// дата/время запуска генерации сигналов по Москве (время сервера)
        /// </summary>
        public DateTime MskDateTime { get; set; }

        /// <summary>
        /// формируется запись для каждого активного магазина, по которому должны быт сформированы сигналы в это время
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// количество сгенерированных сигналов. Если генерация не прошла, то тут 0
        /// </summary>
        public int SignalsCount { get; set; }

        /// <summary>
        /// последняя запись о продажах в момент расчета (по локальному времени магазина)
        /// </summary>
        public DateTime LocalSalesLastDateTime { get; set; }

        /// <summary>
        /// последняя запись об остатках в момент расчета (по локальному времени магазина)
        /// </summary>
        public DateTime LocalRestLastDateTime { get; set; }

        /// <summary>
        /// количество записей о продажах за три часа до запуска (чтобы проверить их полноту – если слишком мало, значит не все данные пришли)
        /// </summary>
        public int CountSalesItems3HoursBefore { get; set; }

        /// <summary>
        /// количество записей об остатках за три часа до запуска (чтобы проверить их полноту – если слишком мало, значит не все данные пришли)
        /// </summary>
        public int CountRestItems3HoursBefore { get; set; }

        /// <summary>
        /// количество записей в ассортиментной матрице в день формирования сигналов
        /// </summary>
        public int CountAssortMatrix { get; set; }

        /// <summary>
        /// статус последней синхронизации перед запуском
        /// </summary>
        public byte LastSynchroStatus { get; set; }
    }
}
