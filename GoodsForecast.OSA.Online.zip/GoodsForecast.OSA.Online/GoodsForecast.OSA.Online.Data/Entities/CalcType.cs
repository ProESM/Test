﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Типы заданий
    /// Сейчас есть задания на расчет и задания на генерацию отчетов
    /// </summary>
    [Table("CalcTypes", Schema = "mng")]
    public class CalcType
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Описание типа задания
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Часовой пояс (для заданий на расчет)
        /// </summary>
        public int? TimezoneId { get; set; }

        /// <summary>
        /// Является ли расчет дневным или ночным
        /// </summary>
        public bool IsDaily { get; set; }

        /// <summary>
        /// Время расчета сигнала - за час до сигнала (для заданий на расчет)
        /// </summary>
        public int? SignalHour { get; set; }

        /// <summary>
        /// Запускать ли перенос в историю
        /// </summary>
        public bool MoveToHistory { get; set; }
    }
}

