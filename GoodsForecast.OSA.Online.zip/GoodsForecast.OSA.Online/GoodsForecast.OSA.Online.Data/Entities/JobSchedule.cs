﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    [Table("JobSchedules", Schema = "mng")]
    public class JobSchedule
    {
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Название типа джоба
        /// </summary>
        public string JobType { get; set; }

        /// <summary>
        /// Расписание
        /// </summary>
        public string CronExpression { get; set; }

        /// <summary>
        /// Тип расчета (для заданий на расчет)
        /// </summary>
        [ForeignKey("CalcTypes")]
        public int? CalcTypeId { get; set; }
        public CalcType CalcType { get; set; }

        /// <summary>
        /// Тип отчета (для заданий по генерации отчета)
        /// </summary>
        [ForeignKey("ReportTypes")]
        public int? ReportTypeId { get; set; }
        public ReportType ReportType { get; set; }

        public bool IsActive { get; set; }

        public ICollection<Job> Jobs { get; set; }
    }
}
