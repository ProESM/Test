﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Товары
    /// </summary>
    [Table("Products")]
    public class Product
    {
        [Key] 
        public int Id { get; set; }

        /// <summary>
        /// Идентификатор товара в ПБД
        /// </summary>
        public string ExternalId { get; set; }

        /// <summary>
        /// Название товара
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Категория товара
        /// </summary>
        [ForeignKey("ProductGroups")]
        public int ProductGroupId { get; set; }
        public ProductGroup ProductGroup { get; set; }

        /// <summary>
        /// Признак активности товара
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Штрихкод
        /// </summary>
        public string Barcode { get; set; }

        /// <summary>
        /// Страна
        /// </summary>
        [ForeignKey("Countries")]
        public int? CountryId { get; set; }
        public Country Country { get; set; }

        /// <summary>
        /// Бренд
        /// </summary>
        [ForeignKey("Brands")]
        public int BrandId { get; set; }
        public Brand Brand { get; set; }

        /// <summary>
        /// Тип продукта
        /// </summary>
        [ForeignKey("ProductTypes")]
        public int ProductTypeId { get; set; }
        public ProductType ProductType { get; set; }

        /// <summary>
        /// Производитель
        /// </summary>
        [ForeignKey("Locations")]
        public int? ProducerId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Единица измерения
        /// </summary>
        [ForeignKey("MeasureUnits")]
        public int MeasureUnitId { get; set; }
        public MeasureUnit MeasureUnit { get; set; }

        /// <summary>
        /// Задачи на расчет
        /// </summary>
        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }

        /// <summary>
        /// Продуктовая матрица
        /// </summary>
        public ICollection<ProductMatrix> ProductMatrix { get; set; }

        /// <summary>
        /// Матрица промоакций
        /// </summary>
        public ICollection<PromotionMatrix> PromotionMatrix { get; set; }
        

        /// <summary>
        /// Результаты расчета по периодам
        /// </summary>
        public ICollection<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods { get; set; }

        /// <summary>
        /// Продажи по дням
        /// </summary>
        public ICollection<LocationStateDaySale> LocationStateDaySales { get; set; }

        /// <summary>
        /// Продажи по часам
        /// </summary>
        public ICollection<LocationStateHourSale> LocationStateHourSales { get; set; }
    }
}

