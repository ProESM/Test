﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Задание на расчет
    /// </summary>
    [Table("LostSalesAnalysisJobs")]
    public class LostSalesAnalysisJob
    {
        [Key]
        public long JobId { get; set; }
        [ForeignKey("JobId")]
        public Job Job { get; set; }

        /// <summary>
        /// Анализируемая дата
        /// </summary>
        public DateTime AnalizeDatetime { get; set; }

        /// <summary>
        /// Статус расчета
        /// </summary>
        public byte Status { get; set; }
        [ForeignKey("Status")]
        public AnalysisStatus AnalysisStatus { get; set; }

        /// <summary>
        /// Дата и время создания задания на расчет
        /// </summary>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Дата и время подготовки параметров
        /// </summary>
        public DateTime? JobPreparedParams { get; set; }

        /// <summary>
        /// Дата и время формирования задач
        /// </summary>
        public DateTime? FilledTasks { get; set; }

        /// <summary>
        /// Дата и время сохранения результатов
        /// </summary>
        public DateTime? FilledJobResults { get; set; }

        /// <summary>
        /// Дата и время переноса сигналов в ПБД
        /// </summary>
        public DateTime? JobResultsProceed { get; set; }

        /// <summary>
        /// Дата и время переноса расчета в историю
        /// </summary>
        public DateTime? MovedToHistory { get; set; }

        /// <summary>
        /// Задачи на расчет
        /// </summary>
        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }

        /// <summary>
        /// Результаты расчета по периодам
        /// </summary>
        public ICollection<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods { get; set; }

        public ICollection<LostSalesAnalysisBatch> LostSalesAnalysisBatches { get; set; }

        public ICollection<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatches { get; set; }

        public ICollection<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }
    }
}
