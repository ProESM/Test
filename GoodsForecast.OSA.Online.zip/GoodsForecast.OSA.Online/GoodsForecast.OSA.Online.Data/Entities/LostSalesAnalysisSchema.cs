﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Схема для расчета
    /// </summary>
    [Table("LostSalesAnalysisSchema")]
    public class LostSalesAnalysisSchema
    {
        [Key]
        public byte Id { get; set; }
        public string Name { get; set; }
        public string Descr { get; set; }

        public List<LostSalesAnalisysSchemaParam> LostSalesAnalisysSchemaParams { get; set; }
        public ICollection<SchemaBinding> SchemaBindings { get; set; }
        public ICollection<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }
    }
}
