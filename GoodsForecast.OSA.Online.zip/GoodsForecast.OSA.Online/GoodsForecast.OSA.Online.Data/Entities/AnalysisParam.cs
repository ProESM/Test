﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Параметры расчета
    /// </summary>
    [Table("AnalysisParams", Schema = "svc")]
    public class AnalysisParam
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string Value { get; set; }
    }
}
