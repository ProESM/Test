﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Задача на расчет для пары товар-магазин
    /// </summary>
    [Table("LostSalesAnalysisTasks")]
    public class LostSalesAnalysisTask
    {
        /// <summary>
        /// Задание на расчет
        /// </summary>
        [Key]
        public long Id { get; set; }

        [ForeignKey("LostSalesAnalysisJobs")]
        public long LostSalesAnalysisJobId { get; set; }
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }


        /// <summary>
        /// Магазин
        /// </summary>
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        /// <summary>
        /// Субджоб
        /// </summary>
        [ForeignKey("LostSalesAnalysisSubJobs")]
        public long? LostSalesAnalysisSubJobId { get; set; }
        public LostSalesAnalysisSubJob LostSalesAnalysisSubJob { get; set; }

        /// <summary>
        /// Батч
        /// </summary>
        [ForeignKey("LostSalesAnalysisBatches")]
        public long? LostSalesAnalysisBatchId { get; set; }
        public LostSalesAnalysisBatch LostSalesAnalysisBatch { get; set; }

        /// <summary>
        /// Суббатч
        /// </summary>
        [ForeignKey("LostSalesAnalysisSubBatches")]
        public long? LostSalesAnalysisSubBatchId { get; set; }
        public LostSalesAnalysisSubBatch LostSalesAnalysisSubBatch { get; set; }

        /// <summary>
        /// Начало предполагаемого периода
        /// </summary>
        public DateTime StartDateTime { get; set; }

        /// <summary>
        /// Конец предполагаемого периода
        /// </summary>
        public DateTime EndDateTime { get; set; }

        /// <summary>
        /// Продолжительность предполагаемого периода
        /// </summary>
        public short? LengthHours { get; set; }

        /// <summary>
        /// Количество пустых рабочих часов, при котором период считается пустым
        /// </summary>
        public short ThresholdLengthWorkingHours { get; set; }

        /// <summary>
        /// Дата создания задачи на расчет (время московское)
        /// </summary>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Цена товара
        /// </summary>
        public float? Price { get; set; }

        /// <summary>
        /// Продолжительность преполагаемого периода в рабочих часах
        /// </summary>
        public short? LengthWorkingHours { get; set; }


        /// <summary>
        /// Праздник или промо
        /// </summary>
        public bool IsMarking { get; set; }

        /// <summary>
        /// Категория продукта
        /// </summary>
        public string AbcCategory { get; set; }

        /// <summary>
        /// Товарооборот за последние 28 дней
        /// </summary>
        public decimal SumSales { get; set; }

        /// <summary>
        /// Тип промо алгоритма
        /// </summary>
        public bool PromoAlgType { get; set; }

        /// <summary>
        /// Является ли товар kvi товаром
        /// </summary>
        public bool IsKvi { get; set; }

        /// <summary>
        /// Флаг увеличения цены
        /// </summary>
        public bool PriceIncreased { get; set; }

        /// <summary>
        /// Результаты расчета по периодам
        /// </summary>
        public ICollection<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods{ get; set; }
    }
}
