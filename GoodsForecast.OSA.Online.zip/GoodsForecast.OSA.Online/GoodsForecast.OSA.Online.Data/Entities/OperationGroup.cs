﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Операционная группа
    /// </summary>
    [Table("OperationGroups")]
    public class OperationGroup
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public ICollection<StoresOperationGroup> StoresOperationGroups { get; set; }
        public ICollection<ConsolidatedReportUserOperationGroup> ConsolidatedReportUserOperationGroups { get; set; }
    }
}
