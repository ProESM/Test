﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Периоды праздников (специальные периоды)
    /// Это не праздники, как таковые, а вручную заданные периоды специальных дней
    /// так например, специальный период "Новый год" длится с 01.12 до 31.12
    /// </summary>
    [Table("HolidayPeriods")]
    public class HolidayPeriod
    {
        [Key]
        public int Id { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [ForeignKey("Holidays")]
        public int HolidayId { get; set; }
        public Holiday Holiday { get; set; }
        public bool IsActive { get; set; }
    }
}
