﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Результаты расчета, сгруппированные по периодам
    /// </summary>
    [Table("LostSalesAnalysisResultPeriods")]
    public class LostSalesAnalysisResultPeriod
    {
        /// <summary>
        /// Задача на расчет
        /// </summary>
        [Key]
        public long LostSalesAnalysisTaskId { get; set; }
        [ForeignKey("LostSalesAnalysisTaskId")]
        public LostSalesAnalysisTask LostSalesAnalysisTask { get; set; }

        /// <summary>
        /// Задание на расчет
        /// </summary>
        [ForeignKey("LostSalesAnalysisJobs")]
        public long LostSalesAnalysisJobId { get; set; }
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        [ForeignKey("Locations")]
        public int LocationId { get; set; }
        public Location Location { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        [ForeignKey("Products")]
        public int ProductId { get; set; }
        public Product Product { get; set; }

        /// <summary>
        /// Начало периода
        /// </summary>
        public DateTime StartDatetime { get; set; }

        /// <summary>
        /// Конец периода
        /// </summary>
        public DateTime EndDatetime { get; set; }

        /// <summary>
        /// Вероятность
        /// </summary>
        public float? Probability { get; set; }

        /// <summary>
        /// Количество часов в периоде
        /// </summary>
        public short HoursCount { get; set; }

        /// <summary>
        /// Количество упущенных продаж
        /// </summary>
        public float? Quantity { get; set; }

        /// <summary>
        /// Дата и время сигнала
        /// </summary>
        public DateTime Created { get; set; }

        /// <summary>
        /// Является ли сигналом
        /// </summary>
        public bool? IsPhantom { get; set; }
    }
}
