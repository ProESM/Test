﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Суббатчи
    /// </summary>
    [Table("LostSalesAnalysisSubBatches")]
    public class LostSalesAnalysisSubBatch
    {
        [Key]
        public long Id { get; set; }

        [ForeignKey("LostSalesAnalysisJobs")]
        public long LostSalesAnalysisJobId { get; set; }
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }

        [ForeignKey("LostSalesAnalysisSubJobs")]
        public long LostSalesAnalysisSubJobId { get; set; }
        public LostSalesAnalysisSubJob LostSalesAnalysisSubJob { get; set; }

        [ForeignKey("LostSalesAnalysisBatches")]
        public long LostSalesAnalysisBatchId { get; set; }
        public LostSalesAnalysisBatch LostSalesAnalysisBatch { get; set; }


        [ForeignKey("Locations")]
        public long LocationId { get; set; }
        public Location Location { get; set; }

        public int TaskCount { get; set; }

        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }
    }
}
