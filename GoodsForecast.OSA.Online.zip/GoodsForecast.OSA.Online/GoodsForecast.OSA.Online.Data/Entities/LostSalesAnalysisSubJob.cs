﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GoodsForecast.OSA.Online.Data.Entities
{
    /// <summary>
    /// Cуджобы
    /// </summary>
    [Table("LostSalesAnalysisSubJobs")]
    public class LostSalesAnalysisSubJob
    {
        [Key]
        public long Id { get; set; }

        [ForeignKey("LostSalesAnalysisJobs")]
        public long LostSalesAnalysisJobId { get; set; }
        public LostSalesAnalysisJob LostSalesAnalysisJob { get; set; }

        [ForeignKey("StoreGroups")]
        public int? StoreGroupId { get; set; }
        public StoreGroup StoreGroup { get; set; }
       
        public int? StoreId { get; set; }
        [ForeignKey("StoreId")]
        public Location Location { get; set; }

        public byte SchemaId { get; set; }
        [ForeignKey("SchemaId")]
        public LostSalesAnalysisSchema LostSalesAnalysisSchema { get; set; }

        public ICollection<LostSalesAnalysisBatch> LostSalesAnalysisBatches { get; set; }

        public ICollection<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatches { get; set; }
        public ICollection<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }
    }
}
