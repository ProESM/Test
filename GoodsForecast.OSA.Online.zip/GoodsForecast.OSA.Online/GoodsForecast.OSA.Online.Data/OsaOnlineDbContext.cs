﻿using Dapper;
using EFCore.BulkExtensions;
using GoodsForecast.OSA.Online.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data
{
    public class OsaOnlineDbContext : DbContext, IOsaOnlineDbContext
    {
        public OsaOnlineDbContext(DbContextOptions<OsaOnlineDbContext> options)
           : base(options)
        {

        }
        public virtual DbSet<AnalysisStatus> AnalysisStatuses { get; set; }
        public virtual DbSet<Brand> Brands { get; set; }
        public virtual DbSet<StoreCluster> StoreClusters { get; set; }
        public virtual DbSet<Country> Countries { get; set; }
        public virtual DbSet<ProductGroup> ProductGroups { get; set; }
        public virtual DbSet<Location> Locations { get; set; }
        public virtual DbSet<LocationStateHourSale> LocationStateHourSales { get; set; }
        public virtual DbSet<LocationStateStock> LocationStateStocks { get; set; }
        public virtual DbSet<LostSalesAnalysisJob> LostSalesAnalysisJobs { get; set; }
        public virtual DbSet<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }
        public virtual DbSet<MeasureUnit> MeasureUnits { get; set; }
        public virtual DbSet<Product> Products { get; set; }
        public virtual DbSet<ProductMatrix> ProductMatrix { get; set; }
        public virtual DbSet<ProductType> ProductTypes { get; set; }
        public virtual DbSet<Promotion> Promotions { get; set; }
        public virtual DbSet<PromotionMatrix> PromotionMatrix { get; set; }
        public virtual DbSet<PromotionType> PromotionTypes { get; set; }
        public virtual DbSet<StoreRegion> StoreRegions { get; set; }
        public virtual DbSet<StoreFormat> StoreFormats { get; set; }
        public virtual DbSet<Job> Jobs { get; set; }
        public virtual DbSet<CalcType> CalcTypes { get; set; }
        public virtual DbSet<JobSchedule> JobSchedules { get; set; }
        public virtual DbSet<LostSalesAnalysisSchema> LostSalesAnalysisSchema { get; set; }
        public virtual DbSet<LostSalesAnalisysSchemaParam> LostSalesAnalisysSchemaParams { get; set; }
        public virtual DbSet<Holiday> Holidays { get; set; }
        public virtual DbSet<HolidayPeriod> HolidayPeriods { get; set; }
        public virtual DbSet<LostSalesAnalysisResultHourly> LostSalesAnalysisResultHourlies { get; set; }
        public virtual DbSet<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods { get; set; }
        public virtual DbSet<LocationStateDaySale> LocationStateDaySales { get; set; }
        public virtual DbSet<ReportType> ReportTypes { get; set; }
        public virtual DbSet<ReportHistory> ReportHistory { get; set; }
        public virtual DbSet<Notification> Notifications { get; set; }
        public virtual DbSet<AlgType> AlgTypes { get; set; }
        public virtual DbSet<BatchType> BatchTypes { get; set; }
        public virtual DbSet<SchemaBinding> SchemaBindings { get; set; }
        public virtual DbSet<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }
        public virtual DbSet<LostSalesAnalysisBatch> LostSalesAnalysisBatches { get; set; }
        public virtual DbSet<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatches { get; set; }
        public virtual DbSet<AnalysisParam> AnalysisParams { get; set; }
        public virtual DbSet<StoreGroup> StoreGroups { get; set; }
        public virtual DbSet<StoresStoreGroup> StoresStoreGroups { get; set; }
        public virtual DbSet<PromoPeriod> PromoPeriods { get; set; }

        public virtual DbSet<ConsolidatedReport> ConsolidatedReport { get; set; }
        public virtual DbSet<ConsolidatedReportType> ConsolidatedReportTypes { get; set; }
        public virtual DbSet<ConsolidatedReportRole> ConsolidatedReportRoles { get; set; }
        public virtual DbSet<ConsolidatedReportUserRegion> ConsolidatedReportUserRegions { get; set; }
        public virtual DbSet<ConsolidatedReportUserOperationGroup> ConsolidatedReportUserOperationGroups { get; set; }
        public virtual DbSet<ConsolidatedReportUserStore> ConsolidatedReportUserStores { get; set; }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Role> Roles { get; set; }
        public virtual DbSet<UserRole> UserRoles { get; set; }
        public virtual DbSet<OperationGroup> OperationGroups { get; set; }
        public virtual DbSet<StoresOperationGroup> StoresOperationGroups { get; set; }
        public virtual DbSet<SignalsFeedbackReport> SignalsFeedbackReport { get; set; }
        public virtual DbSet<SignalsCheck> SignalsCheck { get; set; }

        public virtual DbSet<DailyCalculatedSignals> DailyCalculatedSignals { get; set; }

        public async Task SaveChangesAsync()
        {
            await base.SaveChangesAsync();
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProductMatrix>().HasKey(c => new { c.Date, c.LocationId, c.ProductId });
            modelBuilder.Entity<PromotionMatrix>().HasKey(c => new { c.LocationId, c.ProductId, c.PromotionId });
            modelBuilder.Entity<LostSalesAnalisysSchemaParam>().HasKey(c => new { c.Id, c.SchemaId, c.Key });
            modelBuilder.Entity<LostSalesAnalysisResultHourly>().HasNoKey();
            modelBuilder.Entity<LocationStateDaySale>().HasKey(c => new { c.LocationId, c.ProductId, c.Date });
            modelBuilder.Entity<LocationStateHourSale>().HasKey(c => new { c.LocationId, c.ProductId, c.Datetime });
            modelBuilder.Entity<LocationStateStock>().HasKey(c => new { c.LocationId, c.ProductId, c.Datetime });
            modelBuilder.Entity<StoresStoreGroup>().HasKey(c => new { c.LocationId, c.StoreGroupId });
            modelBuilder.Entity<PromoPeriod>().HasKey(c => new { c.LocationId, c.ProductId, c.DtBegin });
            modelBuilder.Entity<StoresOperationGroup>().HasKey(c => new { c.LocationId, c.OperationGroupId });
            modelBuilder.Entity<ConsolidatedReportRole>().HasKey(c => new { c.ConsolidatedReportTypeId, c.RoleId });
            modelBuilder.Entity<ConsolidatedReportUserRegion>().HasKey(c => new { c.UserId, c.RegionId });
            modelBuilder.Entity<ConsolidatedReportUserOperationGroup>().HasKey(c => new { c.UserId, c.OperationGroupId });
            modelBuilder.Entity<ConsolidatedReportUserStore>().HasKey(c => new { c.UserId, c.StoreId });
            modelBuilder.Entity<UserRole>().HasKey(c => new { c.UserId, c.RoleId });
            modelBuilder.Entity<ConsolidatedReport>(
             cr =>
             {
                 cr.HasNoKey();
                 cr.ToView("ConsolidatedReport");
             });
            modelBuilder.Entity<SignalsFeedbackReport>(
             cr =>
             {
                 cr.HasNoKey();
                 cr.ToView("SignalsFeedbackReport");
             });
            modelBuilder.Entity<SignalsCheck>(
             cr =>
             {
                 cr.HasNoKey();
                 cr.ToView("SignalsCheck");
             });
        }

        /// <summary>
        /// Выполняет хранимую процедуру и возвращает результат
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="procedureName"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public async Task<IEnumerable<T>> ExecuteProcedureAsync<T>(string procedureName, object args)
        {
            var connection = Database.GetDbConnection();
            return await connection.QueryAsync<T>(procedureName, args, commandTimeout: Database.GetCommandTimeout(), commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Выполняет хранимую процедуру асинхронно
        /// </summary>
        /// <param name="procedureName"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public async Task ExecuteProcedureAsync(string procedureName, object args)
        {
            await using var connection = Database.GetDbConnection();
            await connection.ExecuteAsync(procedureName, args, commandTimeout: Database.GetCommandTimeout(), commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Вставляет пачку данных в таблицу
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="values"></param>
        public async Task InsertAsync<T>(List<T> values) where T : class
        {
            await this.BulkInsertAsync(values, config =>
            {
                config.SetOutputIdentity = true;
                config.BulkCopyTimeout = Database.GetCommandTimeout();
            });
        }

        /// <summary>
        /// Вставляет пачку данных в таблицу
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="values"></param>
        public void Insert<T>(List<T> values) where T : class
        {
            this.BulkInsert(values, config =>
            {
                config.SqlBulkCopyOptions = Microsoft.Data.SqlClient.SqlBulkCopyOptions.TableLock;
                config.BulkCopyTimeout = Database.GetCommandTimeout();
            });
        }

        public async Task<T> CreateQuery<T>(string query, object param) where T : struct
        {
            await using var connection = Database.GetDbConnection();
            return await connection.ExecuteScalarAsync<T>(query, param);
        }
    }
}
