﻿using GoodsForecast.OSA.Online.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Data
{
    public interface IOsaOnlineDbContext
    {
        DbSet<AnalysisStatus> AnalysisStatuses { get; set; }
        DbSet<Brand> Brands { get; set; }
        DbSet<StoreCluster> StoreClusters { get; set; }
        DbSet<Country> Countries { get; set; }
        DbSet<ProductGroup> ProductGroups { get; set; }
        DbSet<Location> Locations { get; set; }
        DbSet<LocationStateHourSale> LocationStateHourSales { get; set; }
        DbSet<LocationStateStock> LocationStateStocks { get; set; }
        DbSet<LostSalesAnalysisJob> LostSalesAnalysisJobs { get; set; }
        DbSet<LostSalesAnalysisTask> LostSalesAnalysisTasks { get; set; }
        DbSet<MeasureUnit> MeasureUnits { get; set; }
        DbSet<Product> Products { get; set; }
        DbSet<ProductMatrix> ProductMatrix { get; set; }
        DbSet<ProductType> ProductTypes { get; set; }
        DbSet<Promotion> Promotions { get; set; }
        DbSet<PromotionMatrix> PromotionMatrix { get; set; }
        DbSet<PromotionType> PromotionTypes { get; set; }
        DbSet<StoreRegion> StoreRegions { get; set; }
        DbSet<StoreFormat> StoreFormats { get; set; }
        DbSet<Job> Jobs { get; set; }
        DbSet<CalcType> CalcTypes { get; set; }
        DbSet<JobSchedule> JobSchedules { get; set; }
        DbSet<ReportType> ReportTypes { get; set; }

        DbSet<LostSalesAnalysisSchema> LostSalesAnalysisSchema { get; set; }
        DbSet<LostSalesAnalisysSchemaParam> LostSalesAnalisysSchemaParams { get; set; }
        DbSet<Holiday> Holidays { get; set; }
        DbSet<HolidayPeriod> HolidayPeriods { get; set; }

        DbSet<LostSalesAnalysisResultHourly> LostSalesAnalysisResultHourlies { get; set; }
        DbSet<LostSalesAnalysisResultPeriod> LostSalesAnalysisResultPeriods { get; set; }
        DbSet<LocationStateDaySale> LocationStateDaySales { get; set; }
        DbSet<ReportHistory> ReportHistory { get; set; }
        DbSet<Notification> Notifications { get; set; }

        DbSet<AlgType> AlgTypes { get; set; }
        DbSet<BatchType> BatchTypes { get; set; }
        DbSet<SchemaBinding> SchemaBindings { get; set; }
        DbSet<LostSalesAnalysisSubJob> LostSalesAnalysisSubJobs { get; set; }
        DbSet<LostSalesAnalysisBatch> LostSalesAnalysisBatches { get; set; }
        DbSet<LostSalesAnalysisSubBatch> LostSalesAnalysisSubBatches { get; set; }
        DbSet<AnalysisParam> AnalysisParams { get; set; }
        DbSet<StoreGroup> StoreGroups { get; set; }
        DbSet<StoresStoreGroup> StoresStoreGroups { get; set; }
        DbSet<PromoPeriod> PromoPeriods { get; set; }
        DbSet<ConsolidatedReport> ConsolidatedReport { get; set; }
        DbSet<ConsolidatedReportType> ConsolidatedReportTypes { get; set; }
        DbSet<ConsolidatedReportRole> ConsolidatedReportRoles { get; set; }
        DbSet<ConsolidatedReportUserRegion> ConsolidatedReportUserRegions { get; set; }
        DbSet<ConsolidatedReportUserOperationGroup> ConsolidatedReportUserOperationGroups { get; set; }
        DbSet<ConsolidatedReportUserStore> ConsolidatedReportUserStores { get; set; }
        DbSet<User> Users { get; set; }
        DbSet<Role> Roles { get; set; }
        DbSet<UserRole> UserRoles { get; set; }
        DbSet<OperationGroup> OperationGroups { get; set; }
        DbSet<StoresOperationGroup> StoresOperationGroups { get; set; }
        DbSet<SignalsFeedbackReport> SignalsFeedbackReport { get; set; }
        DbSet<SignalsCheck> SignalsCheck { get; set; }

        DbSet<DailyCalculatedSignals> DailyCalculatedSignals { get; set; }

        Task SaveChangesAsync();

        Task<IEnumerable<T>> ExecuteProcedureAsync<T>(string procedureName, object args = null);
        Task ExecuteProcedureAsync(string procedureName, object args);
        Task<T> CreateQuery<T>(string query, object param) where T : struct;
        void Insert<T>(List<T> values) where T : class;
        Task InsertAsync<T>(List<T> values) where T : class;
    }
}
