﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Contracts.Interfaces
{
    public interface IQueueMessageHandler : IDisposable
    {
        Task Register();
        Task Handle(IQueueMessage message);
    }
}
