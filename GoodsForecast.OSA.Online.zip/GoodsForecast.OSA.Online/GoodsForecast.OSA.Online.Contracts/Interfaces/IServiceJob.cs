﻿using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Contracts.Interfaces
{
    /// <summary>
    /// Общий интерфейс для всех задач, вне зависимости от того, выполняются ли они по расписанию или нет
    /// </summary>
    public interface IServiceJob
    {
        /// <summary>
        /// Запускаем вне контекста Quartz
        /// </summary>
        /// <returns></returns>
        Task Execute();
    }
}
