﻿namespace GoodsForecast.OSA.Online.Contracts.Interfaces
{
    public interface IQueueMessage
    {
    }
}
