﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Enums
{
    public enum FileTypes
    {
        Csv,
        Xlsx
    }
}
