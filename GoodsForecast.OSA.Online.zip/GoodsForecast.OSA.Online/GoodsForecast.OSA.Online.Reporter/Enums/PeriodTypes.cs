﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Enums
{
    /// <summary>
    /// Период для отчета
    /// </summary>
    public enum PeriodTypes
    {
        Week = 0,
        Month = 1
    }
}
