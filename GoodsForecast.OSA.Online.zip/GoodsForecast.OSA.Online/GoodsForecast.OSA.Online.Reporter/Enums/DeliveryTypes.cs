﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Enums
{
    /// <summary>
    /// Способы доставки отчетов
    /// </summary>
    public enum DeliveryTypes
    {
        ByEmail = 0,
        ByFolder = 1
    }
}
