﻿using AutoMapper;
using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using GoodsForecast.OSA.Online.Common.Messaging.Messages.ReportsMessages;
using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.Reporter.Enums;
using GoodsForecast.OSA.Online.Reporter.Reports;
using GoodsForecast.OSA.Online.Reporter.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.QueueHandlers
{
    /// <summary>
    /// Обработчик очередей для Reporter
    /// </summary>
    public class ReporterQueueHandler : IQueueMessageHandler
    {
        private readonly IBus _bus;
        private readonly OsaLogger<ReporterQueueHandler> _logger;
        private IDisposable _busConnection;
        private readonly IReporterRepository _repository;
        private readonly IMapper _mapper;

        public ReporterQueueHandler(
            IBus bus,
            OsaLogger<ReporterQueueHandler> logger,
            IReporterRepository repository,
            IMapper mapper)
        {
            _bus = bus;
            _logger = logger;
            _repository = repository;
            _mapper = mapper;
        }

        public async Task Register()
        {
            _busConnection = await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.BrokerToReporter), Handle);
        }

        public async Task Handle(IQueueMessage message)
        {
            switch (message)
            {
                case BrokerToReporterMessage brMessage:
                    await ProcessMessageFromBroker(brMessage);
                    break;
                case DailySignalsReportMessage sfMessage:
                    await ProcessSignalsFeedbackMessage(sfMessage);
                    break;
                default:
                    throw new ArgumentOutOfRangeException($"Тип сообщения {message.GetType()} не найден");
            }
        }

        private async Task ProcessMessageFromBroker(BrokerToReporterMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Job {message.JobId}. Получен запрос из очереди {nameof(QueueName.BrokerToReporter)}. Начинаем формирование файла", message.JobId);
            try
            {
                //Получаем тип отчета из БД по ид джоба
                ReportType report = _repository.GetReportType(message.JobId);

                //Проверяем, нашли ли репорт в бд
                if (report == null)
                    throw new NullReferenceException($"Тип отчета для джоба {message.JobId} не найден");

                //В зависимости от типа формируем требуемый отчет
                switch (report.ReportName)
                {
                    case "ConsolidatedReport":
                        if (report.ExtensionType == (int)FileTypes.Xlsx)
                        {
                            var isWeek = report.PeriodType == (byte)PeriodTypes.Week;
                            var dateStart = isWeek ? DateTime.Now.AddDays(-7) : DateTime.Now.AddMonths(-1);
                            var excelGenerator = new GenerateExcelReport(_logger, _mapper);

                            

                            var consolidatedReport = _repository.GetConsolidatedReport(dateStart, (ReportTypes)report.ConsolidatedReportTypeId);

                            List<string> recepients = new List<string>();
                            byte[] fileBody = null;

                            switch ((ReportTypes)report.ConsolidatedReportTypeId)
                            {
                                case ReportTypes.All:
                                    {
                                        //Формируем имя файла в зависимости от типа отчета                                
                                        var fileName = $"{report.Subject} {dateStart.ToString("ddMMMyyyy")}-{DateTime.Now.ToString("ddMMMyyyy")}";

                                        //Формируем сам файл
                                        fileBody = excelGenerator.CreateConsolidatedReport(fileName, consolidatedReport, isWeek, message.JobId, ReportTypes.All, "Вся сеть");

                                        //отправляем его
                                        recepients = _repository.GetConsolidatedReportRecepients();
                                        await SendReport(report, message.JobId, fileName, fileBody, recepients);

                                    }
                                    break;
                                case ReportTypes.Region:
                                    foreach (var region in consolidatedReport.Select(x => x.ClusterId).Distinct())
                                    {
                                        //Формируем сам файл
                                        var regionReport = consolidatedReport.Where(x => x.ClusterId == region).ToList();
                                        var filterName = consolidatedReport.Where(x => x.ClusterId == region).Select(x => x.Cluster).FirstOrDefault();
                                        //Формируем имя файла в зависимости от типа отчета                                
                                        var fileName = $"{report.Subject} {dateStart.ToString("ddMMMyyyy")}-{DateTime.Now.ToString("ddMMMyyyy")} {filterName}";
                                        fileBody = excelGenerator.CreateConsolidatedReport($"{fileName} {filterName}", regionReport, isWeek, message.JobId, ReportTypes.Region, filterName);                                        

                                        //отправляем его
                                        recepients = _repository.GetReportRegionRecepients(region);
                                        await SendReport(report, message.JobId, fileName, fileBody, recepients);
                                        
                                    }
                                    break;
                                case ReportTypes.OperationGroup:
                                    foreach (var operationGroup in consolidatedReport.Select(x => x.OperationGroupId).Distinct())
                                    {
                                        //Формируем сам файл
                                        var storeReport = consolidatedReport.Where(x => x.OperationGroupId == operationGroup).ToList();
                                        var filterName = consolidatedReport.Where(x => x.OperationGroupId == operationGroup).Select(x => x.OperationGroup).FirstOrDefault();
                                        //Формируем имя файла в зависимости от типа отчета                                
                                        var fileName = $"{report.Subject} {dateStart.ToString("ddMMMyyyy")}-{DateTime.Now.ToString("ddMMMyyyy")} {filterName}";
                                        fileBody = excelGenerator.CreateConsolidatedReport(fileName, storeReport, isWeek, message.JobId, ReportTypes.OperationGroup, filterName);

                                        //отправляем его
                                        recepients = _repository.GetReportOperationGroupRecepients(operationGroup);
                                        await SendReport(report, message.JobId, fileName, fileBody, recepients);

                                    }
                                    break;
                                case ReportTypes.Store:
                                    foreach (var store in consolidatedReport.Select(x => x.StoreId).Distinct())
                                    {
                                        //Формируем сам файл
                                        var storeReport = consolidatedReport.Where(x => x.StoreId == store).ToList();
                                        var filterName = consolidatedReport.Where(x => x.StoreId == store).Select(x => x.Store).FirstOrDefault();
                                        //Формируем имя файла в зависимости от типа отчета                                
                                        var fileName = $"{report.Subject} {dateStart.ToString("ddMMMyyyy")}-{DateTime.Now.ToString("ddMMMyyyy")} {filterName}";
                                        fileBody = excelGenerator.CreateConsolidatedReport(fileName, storeReport, isWeek, message.JobId, ReportTypes.Store, filterName);

                                        //отправляем его
                                        recepients = _repository.GetReportStoreRecepients(store);
                                        await SendReport(report, message.JobId, fileName, fileBody, recepients);

                                    }
                                    break;
                            }
                            await _repository.UpdateStatusJob(message.JobId, 2); 
                            _logger.LogInformation(Environment.MachineName, $"Формирование отчета завершено.", message.JobId);
                        }
                            
                        break;
                    default:
                        throw new ArgumentOutOfRangeException($"Формирование отчета {report.ReportName} для {message.JobId} джоба не реализовано");
                }

            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При создании отчета произошла ошибка в {nameof(ReporterQueueHandler)}", ex, message.JobId);
            }
        }

        /// <summary>
        /// Генерация отчета обратной связи по сигналам
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessSignalsFeedbackMessage(DailySignalsReportMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Job {message.JobId}. Получен запрос из очереди {nameof(QueueName.BrokerToReporter)}. Начинаем формирование файла", message.JobId);

            try
            {
                //Получаем тип отчета из БД по ид джоба
                ReportType report = _repository.GetReportType(message.JobId);

                //Проверяем, нашли ли репорт в бд
                if (report == null)
                    throw new NullReferenceException($"Тип отчета для джоба {message.JobId} не найден");

                var excelGenerator = new GenerateExcelReport(_logger, _mapper);

                //Формируем имя файла в зависимости от типа отчета                                
                var fileName = $"{report.Subject} {DateTime.Now.ToString("ddMMMyyyy")}";

                //Получаем данные для отчета о правильности проверки
                var validationCorrectnessData = _repository.GetValidationCorrectnessReport().Result;

                //Получаем данные для отчета по сигналам магазинов
                var storeSignalsData = _repository.GetStoreSignalsReport().Result;

                //Получаем данные для отчета обратной связи по сигналам
                var signalsFeedbackData = _repository.GetSignalsFeedBack();                

                //Формируем сам файл
                var fileBody = excelGenerator.CreateDailySignalsReport(fileName, validationCorrectnessData, storeSignalsData, signalsFeedbackData, message.JobId);

                //Получатели
                var recepients = _repository.GetSignalsFeedbaclRecepients(nameof(DailySignalsReportMessage));

                //Отправляем отчет
                await SendReport(report, message.JobId, fileName, fileBody, recepients);

                //Получаем данные для отчета по произведенным расчетам за день
                //var calculatedSignalsData = _repository.GetCalculatedSignalsReport().Result;

                //Формируем сам файл
                //fileBody = excelGenerator.CreateCalculatedSignalsReport(fileName, calculatedSignalsData, message.JobId);

                //Отправляем отчет
                //await SendReport(report, message.JobId, fileName, fileBody, recepients);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При создании отчета обратной связи по сигналам произошла ошибка в {nameof(ProcessSignalsFeedbackMessage)}", ex, message.JobId);
            }            
        }

        /// <summary>
        /// Отправляем файл в брокер
        /// </summary>
        /// <param name="report">Тип отчета</param>
        /// <param name="jobId"></param>
        /// <param name="fileName">Имя файла</param>
        /// <param name="fileBody">Сам файл</param>
        /// <param name="recepients">Получатели</param>
        /// <returns></returns>
        private async Task SendReport(ReportType report, long jobId, string fileName, byte[] fileBody, List<string> recepients)
        {
            if (report.ReportDeliveryType == (byte)DeliveryTypes.ByEmail)
            {

                //Формируем сообщение для отправки в очередь
                var toBrokerMessage = new ReporterToBrokerMessage()
                {
                    JobId = jobId,
                    ExtensionType = report.ExtensionType,
                    Subject = fileName,
                    Body = report.Body,
                    Recepients = String.Join(';', recepients),
                    Attachments = new Dictionary<string, byte[]> { { $"{fileName}.xlsx", fileBody } }
                };

                await _bus.SendReceive.SendAsync(nameof(QueueName.ReporterToBroker), toBrokerMessage);

                _logger.LogInformation(Environment.MachineName, $"Файл {fileName} был успешно отправлен в очередь {nameof(QueueName.ReporterToBroker)}.", jobId);
            }
            else if (report.ReportDeliveryType == (byte)DeliveryTypes.ByFolder && !String.IsNullOrEmpty(report.NetFolder))
            {
                if (!Directory.Exists(report.NetFolder))
                    throw new DirectoryNotFoundException($"Не удается найти директорию {report.NetFolder} для джоба {jobId}.");

                File.WriteAllBytes(Path.Combine(report.NetFolder, $"{fileName}.xlsx"), fileBody);

                _logger.LogInformation(Environment.MachineName, $"Файл {fileName}.xlsx был успешно сохранен в {report.NetFolder}.", jobId);
            }
        }

        public void Dispose()
        {
            _busConnection?.Dispose();
            _bus?.Dispose();
        }
    }
}
