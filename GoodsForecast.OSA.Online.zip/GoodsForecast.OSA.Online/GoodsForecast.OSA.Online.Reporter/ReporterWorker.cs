using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter
{
    public class ReporterWorker : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly OsaLogger<ReporterWorker> _logger;
        private readonly IEnumerable<IQueueMessageHandler> _handlers;

        public ReporterWorker(
            IServiceProvider services,
            OsaLogger<ReporterWorker> logger,
            IEnumerable<IQueueMessageHandler> handlers)
        {
            _services = services;
            _logger = logger;
            _handlers = handlers;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Reporter запущен");

            try
            {
                using var scope = _services.CreateScope();
                foreach (var handler in _handlers)
                {
                    await handler.Register();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, "Ошибка в ReporterWorker", ex);
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Reporter завершает работу");
            await Task.CompletedTask;
        }
    }
}
