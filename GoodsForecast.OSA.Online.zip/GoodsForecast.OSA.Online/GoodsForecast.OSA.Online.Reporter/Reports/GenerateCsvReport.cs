﻿using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.Reporter.Interdaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace GoodsForecast.OSA.Online.Reporter.Reports
{
    public class GenerateCsvReport : IGenerateReport
    {
        private readonly OsaLogger _logger;

        public GenerateCsvReport(OsaLogger logger)
        {
            _logger = logger;
        }

        public byte[] Create(string subject, long jobId)
        {
            try
            {
                return File.ReadAllBytes(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Templates\Template.csv"));
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При формировании csv файла произошла ошибка в {nameof(Create)} JobId {jobId}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Сформировать сводный отчет в Excel
        /// </summary>
        /// <param name="info"></param>
        /// <param name="checkedRows"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>

        public byte[] CreateConsolidatedReport(string filename, List<ConsolidatedReport> filteredReport, bool isWeek, long jobId, ReportTypes reportType, string filterName = null)
        {
            throw new NotImplementedException();
        }
    }
}
