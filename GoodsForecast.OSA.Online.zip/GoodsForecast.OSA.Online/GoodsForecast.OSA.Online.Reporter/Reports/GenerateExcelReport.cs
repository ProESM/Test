﻿using AutoMapper;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.Reporter.Export;
using GoodsForecast.OSA.Online.Reporter.Interdaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;

namespace GoodsForecast.OSA.Online.Reporter.Reports
{
    public class GenerateExcelReport : IGenerateReport
    {
        private readonly OsaLogger _logger;
        private readonly IMapper _mapper;

        /// <summary>
        /// Максимальный процент, на который отличается корректность в магазине
        /// </summary>
        private readonly int MaxCorrectCoef = 10;

        /// <summary>
        /// Колонки консолидированного отчета
        /// </summary>
        private readonly Dictionary<string, string> ConsolidatedColumns = new Dictionary<string, string>()
        {
            { "Date", "Дата" },
            { "WeekDay", "День недели" },
            { "WeekNumber", "Неделя" },
            { "SignalTime", "Время генерации сигнала внутри дня" },
            { "Month", "Месяц" },
            { "Category", "Товарная категория" },
            { "SubCategory", "Товарная подкатегория" },
            { "Group", "Товарная группа" },
            { "SubGroup", "Товарная подгруппа" },
            { "Artikul", "Артикул товара" },
            { "ProductName", "Наименование товара" },
            { "IsNewItem", "Признак новинки" },
            { "Store", "Магазин" },
            { "Cluster", "Кластер" },
            { "Region", "Регион" },
            { "SignalId", "Номер сигнала" },
            { "SignalParentId", "Номер родительского сигнала" },
            { "IsCorrect", "Корректность сигнала" },
            { "SignalValidationTypeId", "Обратная связь" },
            { "ValidationDescription", "Комментарий к обратной связи" },
            { "ValidationDateTime", "Дата и время обратной связи" },
            { "AuditorName", "ФИО сотрудника" },
            { "LostSalesQuantity", "Объем упущенных продаж, шт" },
            { "LostSalesMoney", "Объем упущенных продаж, руб" },
            { "AddSalesQuantity", "Объем доп.продаж после обработки сигнала, шт" },
            { "AddSalesMoney", "Объем доп.продаж после обработки сигнала, руб" }
        };

        /// <summary>
        /// Общие колонки агрегированных отчетов
        /// </summary>
        private readonly Dictionary<string, string> AggregatedColumns = new Dictionary<string, string>()
        {
            { "SignalCount", "Количество сигналов" },
            { "CorrectSignalCount", "Количество корректных сигналов" },
            { "SumLossSalesMoney", "Объем упущенных продаж руб" },
            { "SumAddSalesMoney", "Объем дополнительных продаж руб" }
        };

        /// <summary>
        /// Колонки для отчета обратной связи по сигналам
        /// </summary>
        private readonly Dictionary<string, string> SignalsFeedbackColumns = new Dictionary<string, string>()
        {
            { "SignalDateTime", "Дата и время" },
            { "SignalHour", "Час сигнала" },
            { "IsLate", "С запозданием?" },
            { "SignalId", "Ид сигнала" },
            { "LocationId", "Ид магазина" },
            { "StoreCode", "Код магазина" },
            { "StoreName", "Название магазина" },
            { "IsInPilot", "Магазин в ОЭ" },
            { "ProductId", "Ид товара" },
            { "ProductExternalId", "Код товара" },
            { "ProductName", "Наименование товара" },
            { "CheckResult", "Обратная связь" },
            { "AuditorName", "Проверяющий" },
            { "ValidationDateTime", "Дата проверки" },
            { "Description", "Описание" },
            { "HasPhoto", "Есть фото?" },
            { "PhotoName", "Имя файла с фото" }
        };

        /// <summary>
        /// Колонки для отчета по сигналам магазинов
        /// </summary>
        private readonly Dictionary<string, string> StoreSignalsColumns = new Dictionary<string, string>()
        {
            { "Date", "Дата" },
            { "StoreCode", "Код магазина" },
            { "StoreName", "Название магазина" },
            { "IsInPilot", "Магазин в ОЭ" },
            { "ReportsCount", "Кол-во отчетов" },
            { "SignalsCount", "Кол-во сигналов" },
            { "IsLate", "С запозданием?" },
            { "SignalsWithFeedbackCount", "Кол-во сигналов с ОС" },
            { "SignalsWithoutFeedbackCount", "Кол-во сигналов без ОС" },
            { "ShopAccuracy", "Q" },
            { "SignalsWithFeedbackAccuracy", "Q по сигналам с ОС" }
        };

        /// <summary>
        /// Колонки для отчета по произведенным расчетам за день
        /// </summary>
        private readonly Dictionary<string, string> CalculatedSignalsColumns = new Dictionary<string, string>()
        {
            { "LocalDateTime", "дата/время запуска генерации сигналов" },
            { "MskDateTime", "дата/время запуска генерации сигналов по Москве" },
            { "LocationId", "Ид магазина" },
            { "SignalsCount", "Количество сигналов" },
            { "LocalSalesLastDateTime", "последняя запись о продажах в момент расчета" },
            { "LocalRestLastDateTime", "последняя запись об остатках в момент расчета" },
            { "CountSalesItems3HoursBefore", "количество записей о продажах за три часа до запуска" },
            { "CountRestItems3HoursBefore", "количество записей об остатках за три часа до запуска" },
            { "CountAssortMatrix", "количество записей в ассортиментной матрице в день формирования сигналов" },
            { "LastSynchroStatus", "статус последней синхронизации перед запуском" }
        };

        /// <summary>
        /// Колонки для отчета о правильности проверки
        /// </summary>
        private readonly Dictionary<string, string> ValidationCorrectnessColumns = new Dictionary<string, string>()
        {
            { "LocationId", "Ид Магазина" },
            { "ExternalId", "ExternalId" },
            { "ShortName", "Код магазина" },
            { "ShopName", "Название магазина" },
            { "IsInPilot", "Магазин в ОЭ" },
            { "DateTime", "Дата" },
            { "SignalsCount", "Кол-во сигналов" },
            { "SignalsIntimeCount", "Кол-во сигналов вовремя" },
            { "SignalsWithAnyValidation", "Кол-во сигналов без проверки" },
            { "HumanValidedSignalsCount", "Кол-во сигналов проверенных человеком" },
            { "HumanValidatedIntimeCount", "Кол-во сигналов проверенных человеком вовремя" },
            { "HumanValidatedCorrectSignalsCount", "Кол-во корректных сигналов проверенных человеком вовремя" },
            { "TotalCorrectSignalsCount", "Итоговое кол-во корректных сигналов" },
            { "TotalCorrectIntimeSignalsCount", "Итоговое кол-во корректных сигналов вовремя" },
            { "HumanValidatedPart", "Доля проверенных человеком" },
            { "HumanValidatedIntimePart", "Доля проверенных человеком вовремя" },
            { "HumanValidatedPrecision", "Точность проверки человеком" },
            { "LostSales", "Упущенные продажи" },
            { "HumanValidatedLostSales", "Упущенные продажи проверенные человеком" },
            { "HumanValidatedCorrectLostSales", "Корректные упущенные продажи проверенные человеком" },
            { "TotalCorrectLostSales", "Итоговое кол-во корректных упущенных продаж" },
            { "TotalCorrectIntimeLostSales", "Итоговое кол-во корректных упущенных продаж вовремя" },
            { "HumanValidatedCorrectness", "Корректные данные подтвержденные человеком" },
            { "TotalCorrectness", "Итоговая корректность" },
            { "TotalCorrectnessIntime", "Итоговая корректность вовремя" },
            { "HasLateSignals", "Наличие запоздавших сигналов" },
            { "StrangeHumanValidation", "Некорректность человеческой проверки" },
            { "LowHumalValidation", "Некачественная человеческая проверка" },
            { "FullHumanValidation", "Качественная человеческая проверка" },
            { "AuditorsCount", "Кол-во проверяющих" }
        };

        public GenerateExcelReport(OsaLogger logger, IMapper mapper)
        {
            _logger = logger;
            _mapper = mapper;
        }

        public byte[] Create(string subject, long jobId)
        {
            try
            {
                return File.ReadAllBytes(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Templates\Template.xlsx"));
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При формировании excell файла произошла ошибка в {nameof(Create)} JobId {jobId}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Софрмировать отчет обратной связи по сигналам
        /// </summary>
        /// <param name="filename">Имя файла</param>
        /// <param name="reportData">Данные для отчета</param>
        /// <param name="jobId">Ид джоба</param>
        /// <returns></returns>
        public byte[] CreateDailySignalsReport
            (
                string filename,
                List<ValidationCorrectnessReport> validationCorrectnessData,
                List<StoreSignalsReport> storeSignalsData, 
                List<SignalsFeedbackReport> signalsFeedbackData, 
                long jobId
            )
        {
            try
            {
                var reports = new List<ExcelData>();

                reports.Add(GetSignalsFeedbackExcelData(signalsFeedbackData));

                reports.Add(GetStoreSignalsExcelData(storeSignalsData));

                reports.Add(GetValidationCorrectnessExcelData(validationCorrectnessData));

                //Экспорт данных в Excel
                var excel = ExcelExport.Export(filename, reports);
                _logger.LogInformation(Environment.MachineName, $"Файл {filename} был успешно сформирован.", jobId);

                return excel;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При формировании файла отчета обратной связи по сигналам произошла ошибка в {nameof(CreateDailySignalsReport)} JobId {jobId}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Формирование отчета по произведенным расчетам за день
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="calculatedSignalsData"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public byte[] CreateCalculatedSignalsReport
            (
                string filename,
                List<DailyCalculatedSignals> calculatedSignalsData,
                long jobId
            )
        {
            try
            {
                var report = new List<ExcelData>();

                report.Add(GetCalculatedSignalsExcelData(calculatedSignalsData));

                //Экспорт данных в Excel
                var excel = ExcelExport.Export(filename, report);
                _logger.LogInformation(Environment.MachineName, $"Файл {filename} был успешно сформирован.", jobId);

                return excel;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При формировании файла отчета по произведенным расчетам за день произошла ошибка в {nameof(CreateDailySignalsReport)} JobId {jobId}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Сформировать сводный отчет в Excel
        /// </summary>
        /// <param name="filename">Имя файла</param>
        /// <param name="filteredReport">Данные для отчета</param>
        /// <param name="isWeek">Сформировать отчет по неделе или по месяцу</param>
        /// <param name="jobId"></param>
        /// <param name="reportType">Тип отчета</param>
        /// <param name="filterName">Наименование сущности, по которой фильтруем(для первой строки в Excel)</param>
        /// <returns></returns>
        public byte[] CreateConsolidatedReport(string filename, List<ConsolidatedReport> filteredReport, bool isWeek, long jobId, ReportTypes reportType, string filterName)
        {
            try
            {
                string aggListName = "";
                string aggStoreListName = "";
                string aggCategoryListName = "";
                var reports = new List<ExcelData>();

                if (reportType == ReportTypes.All)
                {
                    reports.Add(GetAllReportExcelData(filteredReport));
                }

                (aggListName, aggStoreListName, aggCategoryListName) = GetSheetNames(reportType, jobId);

                if (isWeek)
                {
                    reports.Add(GetWeekReportExcelData(filteredReport, aggListName, filterName));
                    if (reportType != ReportTypes.Store) reports.Add(GetWeekStoreReportExcelData(filteredReport, aggStoreListName, filterName));
                    reports.Add(GetWeekCategoryReportExcelData(filteredReport, aggCategoryListName, filterName, reportType != ReportTypes.Store));
                }
                else
                {
                    reports.Add(GetMonthReportExcelData(filteredReport, aggListName, filterName));
                    if (reportType != ReportTypes.Store) reports.Add(GetMonthStoreReportExcelData(filteredReport, aggStoreListName, filterName));
                    reports.Add(GetMonthCategoryReportExcelData(filteredReport, aggCategoryListName, filterName, reportType != ReportTypes.Store));
                };

                //Экспорт данных в Excel
                var excel = ExcelExport.Export(filename, reports);
                _logger.LogInformation(Environment.MachineName, $"Файл {filename} был успешно сформирован.", jobId);

                return excel;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При формировании сводного отчета файла произошла ошибка в {nameof(CreateConsolidatedReport)} JobId {jobId}", ex, jobId);
                throw;
            }
        }


        /// <summary>
        /// Получить название листа
        /// </summary>
        /// <param name="reportType"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private (string, string, string) GetSheetNames(ReportTypes reportType, long jobId)
        {
            switch (reportType)
            {
                case ReportTypes.All:
                    {
                        return ("вся сеть-все товары", "все магазины-все товары", "все магазины-категория");
                    }
                case ReportTypes.Region:
                    {
                        return ("регион-все товары", "магазины-все товары", "магазины-категория");
                    }
                case ReportTypes.OperationGroup:
                    {
                        return ("опергруппа-все товары", "магазины-все товары", "магазины-категория");
                    }
                case ReportTypes.Store:
                    {
                        return ("магазин-все товары", "", "магазин-категория");
                    }
                default:
                    throw new ArgumentOutOfRangeException($"Формирование консолидированного отчета с типом {reportType} для {jobId} джоба не реализовано");
            }
        }

        /// <summary>
        /// Получить магазины, по которым показатели корректности отчаются больше чем на 10 процентов
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <returns></returns>
        private List<string> GetNeedCheckedStores(List<ConsolidatedReport> filteredReport)
        {
            var correctByAllKoef = (double)filteredReport.Where(x => x.IsCorrect == "Да").Count() / filteredReport.Count();
            return filteredReport
                            .GroupBy(l => l.Store)
                            .Select(x => new
                            {
                                x.Key,
                                NeedCheck = Math.Abs(correctByAllKoef - (double)x.Where(c => c.IsCorrect == "Да").Count() / x.Count()) / correctByAllKoef * 100 > MaxCorrectCoef ? true : false
                            })
                            .Where(x => x.NeedCheck)
                            .Select(x => x.Key)
                            .ToList();
        }

        /// <summary>
        /// Получить сигналы, по которым не прошли проверки
        /// </summary>
        /// <param name="reportData"></param>
        /// <returns></returns>
        private List<long> GetNeedCheckedSignals(List<FilteredSignalsFeedbackReport> reportData)
        {
            return reportData.Where(x => x.CheckResult == 0)
                .Select(x => x.SignalId)
                .ToList();
        }

        /// <summary>
        /// Сформировать данные для листа со сводным отчетом
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <returns></returns>
        private ExcelData GetAllReportExcelData(List<ConsolidatedReport> filteredReport)
        {
            var allReportData = _mapper.Map<List<FilteredConsolidatedReport>>(filteredReport).OrderBy(x => x.SignalId).ToList();
            var needCheckStores = GetNeedCheckedStores(filteredReport);

            return new ExcelData()
            {
                SheetNumber = 0,
                SheetData = ConvertToDataTable<FilteredConsolidatedReport>.ToDataTable(allReportData, "Консолидированный отчет", ConsolidatedColumns),
                MarkedRowNumbers = filteredReport
                                    .OrderBy(x => x.SignalId)
                                    .Select((r, idx) => new { Index = idx + 2, r.Store })
                                    .Where(x => needCheckStores.Contains(x.Store))
                                    .Select(x => (long)x.Index)
                                    .ToList()
            };
        }

        /// <summary>
        /// Сформировать данные для отчета обратной связи по сигналам
        /// </summary>
        /// <param name="reportData"></param>
        /// <returns></returns>
        private ExcelData GetSignalsFeedbackExcelData(List<SignalsFeedbackReport> reportData)
        {
            var allReportData = _mapper.Map<List<FilteredSignalsFeedbackReport>>(reportData).OrderBy(x => x.StoreName).ToList();
            var needCheckSignals = GetNeedCheckedSignals(allReportData);

            return new ExcelData()
            {
                SheetNumber = 0,
                SheetData = ConvertToDataTable<FilteredSignalsFeedbackReport>.ToDataTable(allReportData, "Signals Feedback", SignalsFeedbackColumns),
                MarkedRowNumbers = allReportData
                                    .OrderBy(x => x.StoreName)
                                    .Select((r, idx) => new { Index = idx + 2, r.SignalId })
                                    .Where(x => needCheckSignals.Contains(x.SignalId))
                                    .Select(x => (long)x.Index)
                                    .ToList()
            };
        }

        /// <summary>
        /// Сформировать данные для отчета по сигналам магазинов
        /// </summary>
        /// <param name="reportData"></param>
        /// <returns></returns>
        private ExcelData GetStoreSignalsExcelData(List<StoreSignalsReport> reportData)
        {
            return new ExcelData()
            {
                SheetNumber = 0,
                SheetData = ConvertToDataTable<StoreSignalsReport>.ToDataTable(reportData, "Stores Signals", StoreSignalsColumns),
                MarkedRowNumbers = new List<long>()
            };
        }

        /// <summary>
        /// Сформировать данные для отчета о правильности проверки
        /// </summary>
        /// <param name="reportData"></param>
        /// <returns></returns>
        private ExcelData GetValidationCorrectnessExcelData(List<ValidationCorrectnessReport> reportData)
        {
            return new ExcelData()
            {
                SheetNumber = 0,
                SheetData = ConvertToDataTable<ValidationCorrectnessReport>.ToDataTable(reportData, "Validation Correctness", ValidationCorrectnessColumns),
                MarkedRowNumbers = new List<long>()
            };
        }

        private ExcelData GetCalculatedSignalsExcelData(List<DailyCalculatedSignals> reportData)
        {
            return new ExcelData()
            {
                SheetNumber = 0,
                SheetData = ConvertToDataTable<DailyCalculatedSignals>.ToDataTable(reportData, "Calcualted Signals", CalculatedSignalsColumns),
                MarkedRowNumbers = new List<long>()
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по неделе
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetWeekReportExcelData(List<ConsolidatedReport> filteredReport, string aggListName, string filterName)
        {
            var weekColumns = new Dictionary<string, string>()
                    {
                        { "WeekNumber", "Неделя"},
                        { "WeekDay", "День недели"}
                    };
            foreach (var aggCol in AggregatedColumns)
                weekColumns.Add(aggCol.Key, aggCol.Value);

            var weekReportData = filteredReport.GroupBy(x => x.WeekNumber)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekDay)
                        .ToDictionary(key => key.Key, val => new WeekAggregationReport
                        {
                            WeekNumber = v.Key,
                            WeekDay = val.Key,
                            SignalCount = val.Count(),
                            CorrectSignalCount = val.Where(s => s.IsCorrect == "Да").Count(),
                            SumLossSalesMoney = val.Sum(s => s.LostSalesMoney),
                            SumAddSalesMoney = val.Sum(s => s.AddSalesMoney)
                        }
                        )
                    )
                    .SelectMany(r => r.Value.Select(wr => wr.Value))
                    .ToList();

            return new ExcelData()
            {
                SheetNumber = 1,
                SheetData = ConvertToDataTable<WeekAggregationReport>.ToDataTable(weekReportData, $"{aggListName} неделя", weekColumns),
                MarkedRowNumbers = new List<long>(),
                FirstRow = filterName
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по неделе и магазину
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetWeekStoreReportExcelData(List<ConsolidatedReport> filteredReport, string aggListName, string filterName)
        {
            var weekColumns = new Dictionary<string, string>()
                    {
                        { "WeekNumber", "Неделя"},
                        { "WeekDay", "День недели"},
                        { "Store", "Магазин"}
                    };
            foreach (var aggCol in AggregatedColumns)
                weekColumns.Add(aggCol.Key, aggCol.Value);

            var weekReportData = filteredReport.GroupBy(x => x.WeekNumber)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekDay)
                        .ToDictionary(key => key.Key, val => val.GroupBy(s => s.Store)
                            .ToDictionary(sk => sk.Key, sv => new WeekAggregationReport
                            {
                                WeekNumber = v.Key,
                                WeekDay = val.Key,
                                Store = sv.Key,
                                SignalCount = sv.Count(),
                                CorrectSignalCount = sv.Where(s => s.IsCorrect == "Да").Count(),
                                SumLossSalesMoney = sv.Sum(s => s.LostSalesMoney),
                                SumAddSalesMoney = sv.Sum(s => s.AddSalesMoney)
                            }
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.Select(s => s.Value)))
                    .ToList();


            var needCheckStores = GetNeedCheckedStores(filteredReport);

            var markedRows = filteredReport.GroupBy(x => x.WeekNumber)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekDay)
                        .ToDictionary(key => key.Key, val => val.GroupBy(s => s.Store)
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.Select(s => s.Key)))
                    .Select((x, idx) => new { Store = x, Index = idx + 3 })
                    .Where(x => needCheckStores.Contains(x.Store))
                    .Select(i => (long)i.Index)
                    .ToList();

            return new ExcelData()
            {
                SheetNumber = 2,
                SheetData = ConvertToDataTable<WeekAggregationReport>.ToDataTable(weekReportData, $"{aggListName} неделя", weekColumns),
                MarkedRowNumbers = markedRows,
                FirstRow = filterName
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по неделе по категории
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggCategoryListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetWeekCategoryReportExcelData(List<ConsolidatedReport> filteredReport, string aggCategoryListName, string filterName, bool needCheck)
        {
            var weekCategoryColumns = new Dictionary<string, string>()
                    {
                        { "WeekNumber", "Неделя"},
                        { "WeekDay", "День недели"},
                        { "Store", "Магазин"},
                        { "Category", "Товарная категория"}
                    };
            foreach (var aggCol in AggregatedColumns)
                weekCategoryColumns.Add(aggCol.Key, aggCol.Value);

            var needCheckStores = GetNeedCheckedStores(filteredReport);

            var weekCategoryReportData = filteredReport.GroupBy(x => x.WeekNumber)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekDay)
                        .ToDictionary(sk => sk.Key, sv => sv.GroupBy(s => s.Store)
                            .ToDictionary(ck => ck.Key, cv => cv.GroupBy(z => z.Category)
                                .ToDictionary(key => key.Key, val => new CategoryWeekAggregationReport
                                {
                                    WeekNumber = v.Key,
                                    WeekDay = sv.Key,
                                    Store = cv.Key,
                                    Category = val.Key,
                                    SignalCount = val.Count(),
                                    CorrectSignalCount = val.Where(s => s.IsCorrect == "Да").Count(),
                                    SumLossSalesMoney = val.Sum(s => s.LostSalesMoney),
                                    SumAddSalesMoney = val.Sum(s => s.AddSalesMoney)
                                }
                                )
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.SelectMany(c => c.Value.Select(s => s.Value))))
                    .ToList();

            var markedRows = filteredReport.GroupBy(x => x.WeekNumber)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekDay)
                        .ToDictionary(sk => sk.Key, sv => sv.GroupBy(s => s.Store)
                            .ToDictionary(ck => ck.Key, cv => cv.GroupBy(z => z.Category)
                                .ToDictionary(key => key.Key, val => new { Store = cv.Key })
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.SelectMany(c => c.Value.Select(s => s.Value))))
                    .Select((x, idx) => new { x.Store, Index = idx + 3 })
                    .Where(x => needCheckStores.Contains(x.Store))
                    .Select(i => (long)i.Index)
                    .ToList();

            return new ExcelData()
            {
                SheetNumber = 3,
                SheetData = ConvertToDataTable<CategoryWeekAggregationReport>.ToDataTable(weekCategoryReportData, $"{aggCategoryListName} неделя", weekCategoryColumns),
                MarkedRowNumbers = needCheck ? markedRows : new List<long>(),
                FirstRow = filterName
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по месяцу
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetMonthReportExcelData(List<ConsolidatedReport> filteredReport, string aggListName, string filterName)
        {
            var monthColumns = new Dictionary<string, string>()
                    {
                        {"Month", "Месяц"},
                        { "WeekNumber", "Неделя"}
                    };
            foreach (var aggCol in AggregatedColumns)
                monthColumns.Add(aggCol.Key, aggCol.Value);

            var monthReportData = filteredReport.GroupBy(x => x.Month)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekNumber)
                        .ToDictionary(key => key.Key, val => new MonthAggregationReport
                        {
                            Month = v.Key,
                            WeekNumber = val.Key,
                            SignalCount = val.Count(),
                            CorrectSignalCount = val.Where(s => s.IsCorrect == "Да").Count(),
                            SumLossSalesMoney = val.Sum(s => s.LostSalesMoney),
                            SumAddSalesMoney = val.Sum(s => s.AddSalesMoney)
                        }
                        )
                    )
                    .SelectMany(r => r.Value.Select(wr => wr.Value))
                    .ToList();
            return new ExcelData()
            {
                SheetNumber = 1,
                SheetData = ConvertToDataTable<MonthAggregationReport>.ToDataTable(monthReportData, $"{aggListName} месяц", monthColumns),
                MarkedRowNumbers = new List<long>(),
                FirstRow = filterName
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по месяцу и магазину
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetMonthStoreReportExcelData(List<ConsolidatedReport> filteredReport, string aggListName, string filterName)
        {
            var monthColumns = new Dictionary<string, string>()
                    {
                        { "Month", "Месяц"},
                        { "WeekNumber", "Неделя"},
                        { "Store", "Магазин"}
                    };
            foreach (var aggCol in AggregatedColumns)
                monthColumns.Add(aggCol.Key, aggCol.Value);

            var needCheckStores = GetNeedCheckedStores(filteredReport);

            var weekReportData = filteredReport.GroupBy(x => x.Month)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekNumber)
                        .ToDictionary(key => key.Key, val => val.GroupBy(s => s.Store)
                            .ToDictionary(sk => sk.Key, sv => new MonthAggregationReport
                            {
                                Month = v.Key,
                                WeekNumber = val.Key,
                                Store = sv.Key,
                                SignalCount = sv.Count(),
                                CorrectSignalCount = sv.Where(s => s.IsCorrect == "Да").Count(),
                                SumLossSalesMoney = sv.Sum(s => s.LostSalesMoney),
                                SumAddSalesMoney = sv.Sum(s => s.AddSalesMoney)
                            }
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.Select(s => s.Value)))
                    .ToList();

            var markedRows = filteredReport.GroupBy(x => x.Month)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekNumber)
                        .ToDictionary(key => key.Key, val => val.GroupBy(s => s.Store)
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.Select(s => s.Key)))
                    .Select((x, idx) => new { Store = x, Index = idx + 3 })
                    .Where(x => needCheckStores.Contains(x.Store))
                    .Select(i => (long)i.Index)
                    .ToList();

            return new ExcelData()
            {
                SheetNumber = 2,
                SheetData = ConvertToDataTable<MonthAggregationReport>.ToDataTable(weekReportData, $"{aggListName} месяц", monthColumns),
                MarkedRowNumbers = markedRows,
                FirstRow = filterName
            };
        }

        /// <summary>
        /// Сформировать данные для листа с отчетом по месяцу по категории
        /// </summary>
        /// <param name="filteredReport"></param>
        /// <param name="aggCategoryListName"></param>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private ExcelData GetMonthCategoryReportExcelData(List<ConsolidatedReport> filteredReport, string aggCategoryListName, string filterName, bool needCheck)
        {
            var monthCategoryColumns = new Dictionary<string, string>()
                    {
                        {"Month", "Месяц"},
                        { "WeekNumber", "Неделя"},
                        { "Store", "Магазин"},
                        { "Category", "Товарная категория"}
                    };
            foreach (var aggCol in AggregatedColumns)
                monthCategoryColumns.Add(aggCol.Key, aggCol.Value);

            var needCheckStores = GetNeedCheckedStores(filteredReport);

            var monthCategoryReportData = filteredReport.GroupBy(x => x.Month)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekNumber)
                    .ToDictionary(sk => sk.Key, sv => sv.GroupBy(s => s.Store)
                            .ToDictionary(ck => ck.Key, cv => cv.GroupBy(z => z.Category)
                                .ToDictionary(key => key.Key, val => new CategoryMonthAggregationReport
                                {
                                    Month = v.Key,
                                    WeekNumber = sv.Key,
                                    Store = cv.Key,
                                    Category = val.Key,
                                    SignalCount = val.Count(),
                                    CorrectSignalCount = val.Where(s => s.IsCorrect == "Да").Count(),
                                    SumLossSalesMoney = val.Sum(s => s.LostSalesMoney),
                                    SumAddSalesMoney = val.Sum(s => s.AddSalesMoney)
                                }
                                )
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.SelectMany(c => c.Value.Select(s => s.Value))))
                    .ToList();

            var markedRows = filteredReport.GroupBy(x => x.Month)
                    .ToDictionary(k => k.Key, v => v.GroupBy(y => y.WeekNumber)
                        .ToDictionary(sk => sk.Key, sv => sv.GroupBy(s => s.Store)
                            .ToDictionary(ck => ck.Key, cv => cv.GroupBy(z => z.Category)
                                .ToDictionary(key => key.Key, val => new { Store = cv.Key })
                            )
                        )
                    )
                    .SelectMany(r => r.Value.SelectMany(wr => wr.Value.SelectMany(c => c.Value.Select(s => s.Value))))
                    .Select((x, idx) => new { x.Store, Index = idx + 3 })
                    .Where(x => needCheckStores.Contains(x.Store))
                    .Select(i => (long)i.Index)
                    .ToList();

            return new ExcelData()
            {
                SheetNumber = 3,
                SheetData = ConvertToDataTable<CategoryMonthAggregationReport>.ToDataTable(monthCategoryReportData, $"{aggCategoryListName} месяц", monthCategoryColumns),
                MarkedRowNumbers = needCheck ? markedRows : new List<long>(),
                FirstRow = filterName
            };
        }
    }
}
