﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using GoodsForecast.OSA.Online.Reporter.Export.Enums;

namespace GoodsForecast.OSA.Online.Reporter.Export
{
    /// <summary>
    /// Для экспорта в Excel
    /// </summary>
    public static class ExcelExport
    {

        /// <summary>
        /// Сгенерировать Excel документ на основе входных данных
        /// </summary>
        public static byte[] Export(string filename, List<ExcelData> datas)
        {
            //Создаём временный Excel файл
            string tempFilename = Path.Join(Path.GetTempPath(), $"{filename}.xlsx");

            try
            {               
                CreateExcelDocument(tempFilename, datas);

                return File.ReadAllBytes(tempFilename);
            }
            finally
            {
                //Удаляем временный файл
                File.Delete(tempFilename);
            }
        }

        /// <summary>
        /// Создать Excel документ
        /// </summary>
        /// <param name="fullFilename">Полный путь к файлу</param>
        /// <param name="ds">Набор таблиц данных</param>
        private static void CreateExcelDocument(string fullFilename, List<ExcelData> datas)
        {
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Create(fullFilename, SpreadsheetDocumentType.Workbook))
            {
                //Добавляем корневой элемент для основной части документа
                WorkbookPart workbookPart = spreadsheetDocument.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                //Добавляем стили
                WorkbookStylesPart workbookStylesPart = spreadsheetDocument.WorkbookPart.AddNewPart<WorkbookStylesPart>("rIdStyles");
                workbookStylesPart.Stylesheet = GenerateStyleSheet();

                //Добавляем листы с данными в Workbook
                Sheets sheets = spreadsheetDocument.WorkbookPart.Workbook.AppendChild(new Sheets());
                CreateExcelDocumentSheets(spreadsheetDocument, datas);

                //Завершаем работу
                spreadsheetDocument.WorkbookPart.Workbook.Save();
                spreadsheetDocument.Close();
            }
        }

        /// <summary>
        /// Создать Worksheet для каждого DataTable в DataSet
        /// </summary>
        private static void CreateExcelDocumentSheets(SpreadsheetDocument spreadsheetDocument, List<ExcelData> datas)
        {
            uint worksheetNumber = 0;

            foreach (var data in datas.OrderBy(x => x.SheetNumber))
            {
                DataTable dt = data.SheetData;

                worksheetNumber++;

                string worksheetName = dt.TableName;

                //Создаём Worksheet и добавляем его в коллекцию Sheets в Workbook
                WorksheetPart worksheetPart = spreadsheetDocument.WorkbookPart.AddNewPart<WorksheetPart>();

                Sheet sheet = new Sheet()
                {
                    Id = spreadsheetDocument.WorkbookPart.GetIdOfPart(worksheetPart),
                    SheetId = worksheetNumber,
                    Name = worksheetName
                };

                //Записываем данные
                WriteToExcelWorksheet(worksheetPart, dt, data.MarkedRowNumbers, data.FirstRow);

                spreadsheetDocument.WorkbookPart.Workbook.Sheets.Append(sheet);
            }
        }

        /// <summary>
        /// Записать данные в файл
        /// </summary>
        private static void WriteToExcelWorksheet(WorksheetPart worksheetPart, DataTable dt, List<long> markedRowNumbers, string filterName)
        {
            OpenXmlWriter writer = OpenXmlWriter.Create(worksheetPart);

            writer.WriteStartElement(new Worksheet());

            WriteToExcelSheetData(dt, writer, markedRowNumbers, filterName);

            writer.WriteEndElement();
            writer.Dispose();
        }

        /// <summary>
        /// Записать данные на лист
        /// </summary>
        private static void WriteToExcelSheetData(DataTable dt, OpenXmlWriter writer, List<long> markedRowNumbers, string filterName)
        {
            writer.WriteStartElement(new SheetData());

            uint rowIdx = 1;
            int numberOfColumns = dt.Columns.Count;
            string[] excelColumnNames = new string[numberOfColumns];
            Enums.CustomStyles[] columnTypes = new Enums.CustomStyles[numberOfColumns];

            if (!String.IsNullOrEmpty(filterName))
            {
                writer.WriteStartElement(new Row { RowIndex = rowIdx });
                AppendTextCell("A1", filterName, writer, false);
                writer.WriteEndElement();

                rowIdx++;
            }

            //Определяем Excel столбцы
            for (int n = 0; n < numberOfColumns; n++)
                excelColumnNames[n] = GetExcelColumnName(n);

            //Записать строку заголовка
            WriteHeaderLine(rowIdx, numberOfColumns, excelColumnNames, columnTypes, dt, writer);

            //Записать данные из DataTable
            WriteDataTableData(ref rowIdx, numberOfColumns, excelColumnNames, columnTypes, dt, writer, markedRowNumbers);

            writer.WriteEndElement();
        }

        /// <summary>
        /// Записать строку заголовка
        /// </summary>
        private static void WriteHeaderLine(in uint rowIdx, in int numberOfColumns, string[] excelColumnNames, Enums.CustomStyles[] columnTypes, DataTable dt, OpenXmlWriter writer)
        {
            writer.WriteStartElement(new Row { RowIndex = rowIdx });

            for (int colIdx = 0; colIdx < numberOfColumns; colIdx++)
            {
                DataColumn col = dt.Columns[colIdx];

                AppendHeaderCell(excelColumnNames[colIdx] + rowIdx, col.ColumnName, writer);

                //Определяем типы данных в столбцах
                if (col.DataType.FullName.StartsWith("System.Int"))
                    columnTypes[colIdx] = Enums.CustomStyles.IntegerNumber;
                else if ((col.DataType.FullName == "System.Decimal") || (col.DataType.FullName == "System.Double") || (col.DataType.FullName == "System.Single"))
                    columnTypes[colIdx] = Enums.CustomStyles.RealNumber;
                else if (col.DataType.FullName == "System.DateTime")
                    columnTypes[colIdx] = Enums.CustomStyles.Date;
                else
                    columnTypes[colIdx] = Enums.CustomStyles.Text;
            }

            writer.WriteEndElement();
        }

        /// <summary>
        /// Записать данные из DataTable
        /// </summary>
        private static void WriteDataTableData(
            ref uint rowIdx, 
            in int numberOfColumns, 
            string[] excelColumnNames, 
            Enums.CustomStyles[] columnTypes, 
            DataTable dt, 
            OpenXmlWriter writer, 
            List<long> markedRowNumbers
            )
        {
            CultureInfo ci = new CultureInfo("en-US");

            foreach (DataRow dr in dt.Rows)
            {
                rowIdx++;

                var isFill = markedRowNumbers.Contains((int)rowIdx);

                writer.WriteStartElement(new Row { RowIndex = rowIdx });

                for (int colIdx = 0; colIdx < numberOfColumns; colIdx++)
                {
                    string cellValue = ReplaceHexadecimalSymbols(dr.ItemArray[colIdx].ToString());
                    string cellReference = excelColumnNames[colIdx] + rowIdx.ToString();

                    //Записываем данные в подходящую ячейку
                    if ((columnTypes[colIdx] == Enums.CustomStyles.IntegerNumber) ||
                        (columnTypes[colIdx] == Enums.CustomStyles.RealNumber))
                    {
                        bool isIncludeDecimalPlaces = columnTypes[colIdx] == Enums.CustomStyles.RealNumber;

                        //Если не получается распарсить, тогда ничего не записываем
                        if (double.TryParse(cellValue, out double cellFloatValue))
                        {
                            cellValue = cellFloatValue.ToString(ci);
                            AppendNumericCell(cellReference, cellValue, isIncludeDecimalPlaces, writer, isFill);
                        }
                        else
                            AppendTextCell(cellReference, cellValue, writer, isFill);
                    }
                    else if (columnTypes[colIdx] == Enums.CustomStyles.Date)
                    {
                        //Дата сохраняется в Excel как число, которое форматируется с помощью стиля

                        if (DateTime.TryParse(cellValue, out DateTime dateValue))
                            AppendDateCell(cellReference, dateValue, writer, isFill);
                        else
                            AppendTextCell(cellReference, cellValue, writer, isFill);
                    }
                    else
                        //Текстовые данные просто записываем в ячейку
                        AppendTextCell(cellReference, cellValue, writer, isFill);
                }

                writer.WriteEndElement();
            }
        }

        /// <summary>
        /// Преобразовать индекс столбца в ссылку на Excel столбец
        /// </summary>
        /// <example>
        /// GetExcelColumnName(0) => "A"
        /// GetExcelColumnName(1) => "B"
        /// GetExcelColumnName(25) => "Z"
        /// GetExcelColumnName(701) => "ZZ"
        /// GetExcelColumnName(702) => "AAA"
        /// </example>
        /// <param name="columnIndex"></param>
        /// <returns>A, B, C... Z, AA, AB, AC... AZ...</returns>
        public static string GetExcelColumnName(int columnIndex)
        {
            int firstInt = columnIndex / 676;
            int secondInt = (columnIndex % 676) / 26;
            int thirdInt = columnIndex % 26;

            if (secondInt == 0)
            {
                secondInt = 26;
                firstInt--;
            }

            char firstChar = (char)('A' + firstInt - 1);
            char secondChar = (char)('A' + secondInt - 1);
            char thirdChar = (char)('A' + thirdInt);

            if (columnIndex < 26)
                return thirdChar.ToString();

            if (columnIndex < 702)
                return $"{secondChar}{thirdChar}";

            return $"{firstChar}{secondChar}{thirdChar}";
        }

        /// <summary>
        /// Удалить недопустимые символы
        /// </summary>
        private static string ReplaceHexadecimalSymbols(string txt)
        {
            string r = "[\x00-\x08\x0B\x0C\x0E-\x1F]";
            return Regex.Replace(txt, r, "", RegexOptions.Compiled);
        }

        /// <summary>
        /// Записать заголовок
        /// </summary>
        private static void AppendHeaderCell(string cellReference, string cellStringValue, OpenXmlWriter writer)
        {
            writer.WriteElement(new Cell()
            {
                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                StyleIndex = (uint)CustomStyles.Header,
                DataType = CellValues.String
            });
        }

        /// <summary>
        /// Записать ячейку с текстом
        /// </summary>
        private static void AppendTextCell(string cellReference, string cellStringValue, OpenXmlWriter writer, bool isFill)
        {
            //с заливкой или без заливки
            uint cellStyle = !isFill ? (uint)CustomStyles.Text : (uint)CustomStyles.FillText;

            writer.WriteElement(new Cell()
            {
                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                StyleIndex = cellStyle,
                DataType = CellValues.String
            });
        }

        /// <summary>
        /// Записать ячейку с числом
        /// </summary>
        private static void AppendNumericCell(string cellReference, string cellStringValue, bool isIncludeDecimalPlaces, OpenXmlWriter writer, bool isFill)
        {
            //Определяем количество знаков после запятой и нужно ли заливать ячейку
            uint cellStyle = (uint)(!isIncludeDecimalPlaces 
                ? (!isFill ? (uint)CustomStyles.IntegerNumber : (uint)CustomStyles.FillIntegerNumber) 
                : (!isFill ? (uint)CustomStyles.RealNumber : (uint)CustomStyles.FillRealNumber));

            writer.WriteElement(new Cell
            {
                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                StyleIndex = cellStyle,
                DataType = CellValues.Number
            });
        }

        /// <summary>
        /// Записать ячейку с датой
        /// </summary>
        private static void AppendDateCell(string cellReference, DateTime dateTimeValue, OpenXmlWriter writer, bool isFill)
        {
            //Определяем формат даты и нужно ли заливать ячейку
            bool isBlankTime = dateTimeValue.Date == dateTimeValue;

            uint cellStyle = (!isBlankTime
                ? (!isFill ? (uint)CustomStyles.DateTime : (uint)CustomStyles.FillDateTime)
                : (!isFill ? (uint)CustomStyles.Date : (uint)CustomStyles.FillDate));

            string cellStringValue = dateTimeValue.ToOADate().ToString(CultureInfo.InvariantCulture);

            writer.WriteElement(new Cell
            {
                CellValue = new CellValue(cellStringValue),
                CellReference = cellReference,
                StyleIndex = cellStyle,
                DataType = CellValues.Number    //специально используется не CellValues.Date
            });
        }

        private static Stylesheet GenerateStyleSheet()
        {
            uint iExcelIndex = 164;

            return new Stylesheet(
                new NumberingFormats(
                    new NumberingFormat()
                    {
                        NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++),
                        FormatCode = StringValue.FromString("dd/MMM/yyyy hh:mm:ss")
                    },
                    new NumberingFormat()
                    {
                        NumberFormatId = UInt32Value.FromUInt32(iExcelIndex++),
                        FormatCode = StringValue.FromString("dd/MMM/yyyy")
                    }
                ),
                new Fonts(
                    //0 - стандартный шрифт
                    //1 - жирный шрифт
                    new Font(
                        new FontSize() { Val = 10 },
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" }),
                    new Font(
                        new FontSize() { Val = 10 },
                        new Bold(),
                        new Color() { Rgb = new HexBinaryValue() { Value = "000000" } },
                        new FontName() { Val = "Calibri" })
                ),
                new Fills(
                    //0 - стандартная заливка (без заливки)
                    //1 - серые точки
                    //2 - светло-желтая заливка
                    new Fill(
                        new PatternFill() { PatternType = PatternValues.None }
                        ),
                    new Fill(
                        new PatternFill() { PatternType = PatternValues.Gray125 }
                        ),
                    new Fill(
                        new PatternFill()
                        {
                            PatternType = PatternValues.Solid,
                            ForegroundColor = new ForegroundColor() { Rgb = "FFFF66" },
                            BackgroundColor = new BackgroundColor() { Indexed = 64 }
                        }
                        )
                ),
                new Borders(
                    //0 - стандартная граница
                    new Border(
                        new LeftBorder(),
                        new RightBorder(),
                        new TopBorder(),
                        new BottomBorder(),
                        new DiagonalBorder())
                ),
                new CellFormats(
                    new CellFormat() { FontId = 0, FillId = 0, BorderId = 0},                  //Стиль # 0 - стандартная ячейка
                    new CellFormat() { NumberFormatId = 164, FillId = 0 },                      //Стиль # 1 - формат даты: dd/MMM/yyyy hh:mm:ss
                    new CellFormat() { NumberFormatId = 165, FillId = 0 },                      //Стиль # 2 - формат даты: dd/MMM/yyyy
                    new CellFormat() { NumberFormatId = 3, FillId = 0 },                        //Стиль # 3 - числовой формат: #,## (0)
                    new CellFormat() { NumberFormatId = 4, FillId = 0 },                        //Стиль # 4 - числовой формат: #,## (0,00)
                    new CellFormat() { FontId = 1, FillId = 0, BorderId = 0 },                  //Стиль # 5 - заголовок
                    new CellFormat() { FontId = 0, FillId = 2, BorderId = 0 },      //Стиль # 6 - стандартная ячейка с заливкой
                    new CellFormat() { NumberFormatId = 164, FillId = 2 },          //Стиль # 7 - формат даты: dd/MMM/yyyy hh:mm:ss с заливкой
                    new CellFormat() { NumberFormatId = 165, FillId = 2 },          //Стиль # 8 - формат даты: dd/MMM/yyyy с заливкой
                    new CellFormat() { NumberFormatId = 3, FillId = 2 },            //Стиль # 9 - числовой формат: #,## (0) с заливкой
                    new CellFormat() { NumberFormatId = 4, FillId = 2 }             //Стиль # 10 - числовой формат: #,## (0,00) с заливкой
                )
            );
        }


    }
}
