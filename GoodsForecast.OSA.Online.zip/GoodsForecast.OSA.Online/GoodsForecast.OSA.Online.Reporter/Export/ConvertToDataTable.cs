﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Export
{
    public class ConvertToDataTable<T>
    {
        /// <summary>
        /// Преобразовать список в DataTable
        /// </summary>
        /// <param name="list">Преобразуемый список</param>
        /// <param name="tablename">Имя таблицы</param>
        /// <param name="cols">
        /// Где:
        /// ключ - название поля в типе <typeparamref name="T"/>, которое нужно добавить в DataTable (как столбец)
        /// значение - желаемое название этого поля в DataTable
        /// </param>
        public static DataTable ToDataTable(List<T> list, string tablename, Dictionary<string, string> cols)
        {
            DataTable dt = new DataTable(tablename);

            CreateDataTableColumns(dt, cols);
            FillInDataTable(dt, list, cols);

            return dt;
        }

        /// <summary>
        /// Создать колонки в DataTable на основе указанных полей
        /// </summary>
        private static void CreateDataTableColumns(DataTable dt, Dictionary<string, string> cols)
        {
            foreach (PropertyInfo info in typeof(T).GetProperties())
            {
                if (cols.ContainsKey(info.Name))
                    dt.Columns.Add(cols[info.Name], GetNullableType(info.PropertyType));
            }
        }

        /// <summary>
        /// Заполнить DataTable данными из списка
        /// </summary>
        private static void FillInDataTable(DataTable dt, List<T> list, Dictionary<string, string> cols)
        {
            foreach (T obj in list)
            {
                DataRow row = dt.NewRow();

                foreach (PropertyInfo info in typeof(T).GetProperties())
                {
                    if (cols.ContainsKey(info.Name))
                    {
                        if (!IsNullableType(info.PropertyType))
                            row[cols[info.Name]] = info.GetValue(obj);
                        else
                            row[cols[info.Name]] = info.GetValue(obj) ?? DBNull.Value;
                    }
                }

                dt.Rows.Add(row);
            }
        }

        /// <summary>
        /// Вернуть Nullable-тип
        /// </summary>
        /// <returns>
        /// Если <paramref name="type"/> является Nullable - вернуть <paramref name="type"/>, допускающий NULL;
        /// иначе вернуть <paramref name="type"/>
        /// </returns>
        private static Type GetNullableType(Type type)
        {
            return type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof(Nullable<>)) ? Nullable.GetUnderlyingType(type) : type;
        }

        /// <summary>
        /// Проверка поля на Nullable-тип
        /// </summary>
        private static bool IsNullableType(Type type)
        {
            return type == typeof(string) || type.IsArray || (type.IsGenericType && type.GetGenericTypeDefinition().Equals(typeof(Nullable<>)));
        }
    }
}
