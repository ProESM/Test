﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Export.Enums
{
    public enum CustomStyles
    {
        Text,
        DateTime,
        Date,
        IntegerNumber,
        RealNumber,
        Header,
        FillText,
        FillDateTime,
        FillDate,
        FillIntegerNumber,
        FillRealNumber
    }
}
