﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Export
{
    /// <summary>
    /// Содержание листа Excel
    /// </summary>
    public class ExcelData
    {
        /// <summary>
        /// Номер листа
        /// </summary>
        public int SheetNumber { get; set; }

        /// <summary>
        /// Наполнение листа
        /// </summary>
        public DataTable SheetData { get; set; }

        /// <summary>
        /// Строка перед заголовком
        /// </summary>
        public string FirstRow { get; set; }

        /// <summary>
        /// Номера помеченных строк
        /// </summary>
        public List<long> MarkedRowNumbers { get; set; }
    }
}
