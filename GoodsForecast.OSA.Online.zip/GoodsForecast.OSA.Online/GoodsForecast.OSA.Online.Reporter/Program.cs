using AutoMapper;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Jobs;
using GoodsForecast.OSA.Online.Common.Mapping;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data;
using GoodsForecast.OSA.Online.Reporter.QueueHandlers;
using GoodsForecast.OSA.Online.Reporter.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Extensions.Logging;
using NLog.Web;
using System;
using System.Linq;

namespace GoodsForecast.OSA.Online.Reporter
{
    public class Program
    {
        private static IServiceCollection _svc;

        public static void Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();

            // если вызвать как консоль с аргументами, можно что-то выполнить сразу
            switch (args)
            {
                case Array { Length: 2 } when args[0] == "--test":
                    Run<TestServiceJob>(args[1]);
                    break;
                default:
                    host.Run();
                    break;
            }
        }

        private static async void Run<T>(string arg)
        {
            await using var sp = _svc.BuildServiceProvider();
            var job = sp.GetServices<IServiceJob>().FirstOrDefault(s => s is T);
            if (job != null)
                await job.Execute();
            Console.ReadKey(); // Надо как-то почитать в консоли, что там вообще
        }

        private static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseWindowsService()
#if TEST
                .UseEnvironment("Testing")
#elif DEBUG
                .UseEnvironment("Development")
#else
                .UseEnvironment("Production")
#endif
                .ConfigureLogging(logging => logging.AddConsole())
                .ConfigureServices((ctx, services) => _svc = Register(ctx, services))
                .UseNLog();

        private static IServiceCollection Register(HostBuilderContext context, IServiceCollection services)
        {
            context.Configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .AddJsonFile($"appsettings.{context.HostingEnvironment.EnvironmentName}.json")
                .Build();

            services.AddDbContext<IOsaOnlineDbContext, OsaOnlineDbContext>(options =>
            {
                var connectionString = context.Configuration.GetValue<string>("ConnectionStrings:OsaConnectionString");
                int timeout;
                if (int.TryParse(context.Configuration.GetValue<string>("Database:CommandTimeout"), out timeout)) { }
                else
                    timeout = 300;
                options.UseSqlServer(connectionString, conf => conf.CommandTimeout(timeout));
            });

            var mapperConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });
            IMapper mapper = mapperConfig.CreateMapper();
            services.AddSingleton(mapper);

            Console.WriteLine(context.HostingEnvironment.EnvironmentName);
            services.RegisterEasyNetQ(context.Configuration.GetConnectionString("RabbitConnectionString"));
            services.AddTransient<IReporterRepository, ReporterRepository>();
            services.AddScoped<IOsaOnlineDbContext, OsaOnlineDbContext>();

            return services
                .AddOptions()
                .AddLogging(logging =>
                {
                    logging.ClearProviders();
                    logging.AddNLog();
                    logging.AddConfiguration(context.Configuration.GetSection("Logging"));
                    LogManager.Configuration =
                        new NLogLoggingConfiguration(context.Configuration.GetSection("NLog"));
                })
                .AddTransient<IQueueMessageHandler, ReporterQueueHandler>()
                .AddSingleton(typeof(OsaLogger<>))
                .AddHostedService<ReporterWorker>();
        }
    }
}
