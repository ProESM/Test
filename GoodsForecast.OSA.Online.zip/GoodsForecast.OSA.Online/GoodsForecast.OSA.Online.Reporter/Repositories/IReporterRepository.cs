﻿using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Repositories
{
    public interface IReporterRepository
    {
        /// <summary>
        /// Получить тип отчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        ReportType GetReportType(long jobId);

        /// <summary>
        /// Получить консолидированный отчет
        /// </summary>
        /// <returns></returns>
        List<ConsolidatedReport> GetConsolidatedReport(DateTime dateFrom, ReportTypes reportType);

        /// <summary>
        /// Получить получателей консолидированного отчета
        /// </summary>
        /// <returns></returns>
        List<string> GetConsolidatedReportRecepients();

        /// <summary>
        /// Получить получателей консолидированного отчета по регионам
        /// </summary>
        /// <returns></returns>
        List<string> GetReportRegionRecepients(int regionId);

        /// <summary>
        /// Получить получателей консолидированного отчета по магазинам
        /// </summary>
        /// <returns></returns>
        List<string> GetReportStoreRecepients(int storeId);

        /// <summary>
        /// Получить получателей консолидированного отчета по оперативной группе
        /// </summary>
        /// <returns></returns>
        List<string> GetReportOperationGroupRecepients(int operationGroupId);

        /// <summary>
        /// Обновление статуса джоба
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        Task UpdateStatusJob(long jobId, int status);

        /// <summary>
        /// Получить получателей отчета обратной связи по сигналам
        /// </summary>
        /// <returns></returns>
        List<string> GetSignalsFeedbaclRecepients(string type);

        /// <summary>
        /// Получить обратную связь по сигналам
        /// </summary>
        /// <returns></returns>
        List<SignalsFeedbackReport> GetSignalsFeedBack();

        /// <summary>
        /// Получить отчет по сигналам магазинов
        /// </summary>
        /// <returns></returns>
        Task<List<StoreSignalsReport>> GetStoreSignalsReport();

        /// <summary>
        /// Получить отчет о правильности проверки
        /// </summary>
        /// <returns></returns>
        Task<List<ValidationCorrectnessReport>> GetValidationCorrectnessReport();

        /// <summary>
        /// Получить отчет по произведенным расчетам за день
        /// </summary>
        /// <returns></returns>
        Task<List<DailyCalculatedSignals>> GetCalculatedSignalsReport();
    }
}
