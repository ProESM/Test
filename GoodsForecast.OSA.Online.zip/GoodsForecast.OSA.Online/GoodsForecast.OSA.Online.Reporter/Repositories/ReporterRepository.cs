﻿using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Data;
using GoodsForecast.OSA.Online.Data.Entities;
using GoodsForecast.OSA.Online.ServiceBroker.Jobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Repositories
{
    public class ReporterRepository : IReporterRepository
    {
        private readonly ILogger<GenerateReportJob> _logger;
        IServiceScopeFactory _serviceScopeFactory;

        public ReporterRepository(ILogger<GenerateReportJob> logger,
                             IServiceScopeFactory serviceScopeFactory)
        {
            _logger = logger;
            _serviceScopeFactory = serviceScopeFactory;
        }

        /// <summary>
        /// Получить тип отчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public ReportType GetReportType(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = from reportTypes in context.ReportTypes
                                join jobSchedules in context.JobSchedules on reportTypes.Id equals jobSchedules.ReportTypeId
                                join jobs in context.Jobs on jobSchedules.Id equals jobs.JobScheduleId
                                where jobs.Id == jobId
                                select reportTypes;

                    return query.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении типа отчета произошла ошибка в JobRepository {nameof(GetReportType)}", ex.ToString(), jobId);
                throw;
            }
        }


        /// <summary>
        /// Получить консолидированный отчет
        /// </summary>
        /// <returns></returns>
        public List<ConsolidatedReport> GetConsolidatedReport(DateTime dateFrom, ReportTypes reportType)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.ConsolidatedReport
                        .Where(x => x.Date >= dateFrom
                            && (reportType == ReportTypes.All
                                || reportType == ReportTypes.Region && context.ConsolidatedReportUserRegions.Select(r => r.RegionId).Contains(x.ClusterId)
                                || reportType == ReportTypes.OperationGroup && context.ConsolidatedReportUserOperationGroups.Select(r => r.OperationGroupId).Contains(x.OperationGroupId)
                                || reportType == ReportTypes.Store && context.ConsolidatedReportUserStores.Select(r => r.StoreId).Contains(x.StoreId)))
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении консолидированного отчета произошла ошибка в JobRepository {nameof(GetConsolidatedReport)}", ex.ToString());
                throw;
            }
        }


        /// <summary>
        /// Получить получателей консолидированного отчета по регионам
        /// </summary>
        /// <returns></returns>
        public List<string> GetReportRegionRecepients(int regionId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.ConsolidatedReportUserRegions
                            .Where(x => x.RegionId == regionId)
                            .Include(x => x.User)
                            .SelectMany(x => x.User.UserRoles)
                            .Join(context.ConsolidatedReportRoles.Where(cr => cr.ConsolidatedReportTypeId == (byte)ReportTypes.Region),
                                u => u.RoleId,
                                cr => cr.RoleId,
                                (u, cr) => u.User.Email
                            )
                            .Distinct()
                            .ToList();

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении получателей консолидированного отчета произошла ошибка в JobRepository {nameof(GetReportRegionRecepients)}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Получить получателей консолидированного отчета
        /// </summary>
        /// <returns></returns>
        public List<string> GetConsolidatedReportRecepients()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.ConsolidatedReportRoles
                            .Where(cr => cr.ConsolidatedReportTypeId == (byte)ReportTypes.All)
                            .Include(x => x.Role)
                            .SelectMany(x => x.Role.UserRoles)
                            .Select(u => u.User.Email)
                            .Distinct()
                            .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении получателей консолидированного отчета произошла ошибка в JobRepository {nameof(GetConsolidatedReportRecepients)}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Получить получателей консолидированного отчета по магазинам
        /// </summary>
        /// <returns></returns>
        public List<string> GetReportStoreRecepients(int storeId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.ConsolidatedReportUserStores
                            .Where(x => x.StoreId == storeId)
                            .Include(x => x.User)
                            .SelectMany(x => x.User.UserRoles)
                            .Join(context.ConsolidatedReportRoles.Where(cr => cr.ConsolidatedReportTypeId == (byte)ReportTypes.Store),
                                u => u.RoleId,
                                cr => cr.RoleId,
                                (u, cr) => u.User.Email
                            )
                            .Distinct()
                            .ToList();

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении получателей консолидированного отчета произошла ошибка в JobRepository {nameof(GetReportStoreRecepients)}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Получить получателей консолидированного отчета по оперативной группе
        /// </summary>
        /// <returns></returns>
        public List<string> GetReportOperationGroupRecepients(int operationGroupId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.ConsolidatedReportUserOperationGroups
                            .Where(x => x.OperationGroupId == operationGroupId)
                            .Include(x => x.User)
                            .SelectMany(x => x.User.UserRoles)
                            .Join(context.ConsolidatedReportRoles.Where(cr => cr.ConsolidatedReportTypeId == (byte)ReportTypes.OperationGroup),
                                u => u.RoleId,
                                cr => cr.RoleId,
                                (u, cr) => u.User.Email
                            )
                            .Distinct()
                            .ToList();

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении получателей консолидированного отчета произошла ошибка в JobRepository {nameof(GetReportOperationGroupRecepients)}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Обновление статуса джоба
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task UpdateStatusJob(long jobId, int status)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var existingJob = context.Jobs.FirstOrDefault(x => x.Id == jobId);
                    if (existingJob != null)
                    {
                        existingJob.Status = status;
                        existingJob.EndDate = DateTime.Now;
                        context.Jobs.Update(existingJob);
                    }
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"При обновлении джоба произошла ошибка в ReporterRepository {nameof(UpdateStatusJob)}", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Получить получателей отчета обратной связи по сигналам
        /// </summary>
        /// <returns></returns>
        public List<string> GetSignalsFeedbaclRecepients(string type)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var recepients = context.Notifications
                        .Where(x => x.Type == type)
                        .Select(x => x.Recipients)
                        .FirstOrDefault();

                    return recepients.Split(';')
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"При получении получателей консолидированного отчета произошла ошибка в JobRepository {nameof(GetConsolidatedReportRecepients)}", ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// Получить отчет обратной связи по сигналам
        /// </summary>
        /// <returns></returns>
        public List<SignalsFeedbackReport> GetSignalsFeedBack()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.SignalsFeedbackReport
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetSignalsFeedBack)}. Ошибка при получении информации об обратной связи по сигналам", ex);
                throw;
            }
        }

        /// <summary>
        /// Получить отчет по сигналам магазинов
        /// </summary>
        /// <returns></returns>
        public async Task<List<StoreSignalsReport>> GetStoreSignalsReport()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var result = await context.ExecuteProcedureAsync<StoreSignalsReport>("dbo.GetStoreSignalsReport", null);

                    return (List<StoreSignalsReport>)result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetStoreSignalsReport)}. Ошибка при получении отчета по сигналам магазинов", ex);
                throw;
            }
        }

        /// <summary>
        /// Получить отчет о правильности проверки
        /// </summary>
        /// <returns></returns>
        public async Task<List<ValidationCorrectnessReport>> GetValidationCorrectnessReport()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var result = await context.ExecuteProcedureAsync<ValidationCorrectnessReport>("dbo.GetValidationCorrectnessReport", null);

                    return (List<ValidationCorrectnessReport>)result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ValidationCorrectnessReport)}. Ошибка при получении отчета о правильности проверки", ex);
                throw;
            }
        }

        /// <summary>
        /// Получить отчет по произведенным расчетам за день
        /// </summary>
        /// <returns></returns>
        public async Task<List<DailyCalculatedSignals>> GetCalculatedSignalsReport()
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    return context.DailyCalculatedSignals
                        .Where(x => x.MskDateTime.Date == DateTime.Today.AddDays(-1).Date)
                        .ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ValidationCorrectnessReport)}. Ошибка при получении отчета по произведенным расчетам за день", ex);
                throw;
            }
        }
    }
}
