﻿using GoodsForecast.OSA.Online.Common.Reports;
using GoodsForecast.OSA.Online.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Reporter.Interdaces
{
    public interface IGenerateReport
    {
        byte[] Create(string subject, long jobId);

        /// <summary>
        /// Сформировать сводный отчет в Excel
        /// </summary>
        /// <param name="info"></param>
        /// <param name="checkedRows"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public byte[] CreateConsolidatedReport(string filename, List<ConsolidatedReport> filteredReport, bool isWeek, long jobId, ReportTypes reportType, string filterName = null);
    }
}
