﻿CREATE TABLE [metadata].[ValidationParams] (
    [Key]   NVARCHAR (32) NOT NULL,
    [Value] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_ValidationParams] PRIMARY KEY CLUSTERED ([Key] ASC)
);

