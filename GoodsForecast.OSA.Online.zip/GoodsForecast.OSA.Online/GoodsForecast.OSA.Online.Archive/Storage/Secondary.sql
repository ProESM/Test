﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILEGROUP [Secondary];

