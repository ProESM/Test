﻿CREATE TABLE [archive_main].[LostSalesAnalysisResultHourlies] (
    [LostSalesAnalysisTaskId] BIGINT        NOT NULL,
    [Datetime]                SMALLDATETIME NOT NULL,
    [LostSalesAnalysisJobId]  BIGINT        NOT NULL,
    [LocationId]              INT           NOT NULL,
    [ProductId]               INT           NOT NULL,
    [Probability]             REAL          NULL,
    [Quantity]                REAL          NULL,
    [Created]                 DATETIME      NOT NULL,
    [IsPhantom]               BIT           NULL,
    [IsCalculatedInTsa]       BIT           NULL
);

