﻿CREATE TABLE [archive].[Producers] (
    [SyncId]      INT            NOT NULL,
    [SyncCreated] DATETIME       NOT NULL,
    [ProducerId]  NVARCHAR (32)  NOT NULL,
    [Name]        NVARCHAR (256) NOT NULL
);

