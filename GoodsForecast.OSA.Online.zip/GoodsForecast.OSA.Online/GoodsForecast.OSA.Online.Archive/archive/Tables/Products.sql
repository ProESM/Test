﻿CREATE TABLE [archive].[Products] (
    [SyncId]         INT            NOT NULL,
    [SyncCreated]    DATETIME       NOT NULL,
    [ProductId]      NVARCHAR (32)  NOT NULL,
    [Name]           NVARCHAR (256) NOT NULL,
    [Barcode]        NVARCHAR (80)  NOT NULL,
    [ProductTypeId]  NVARCHAR (32)  NOT NULL,
    [ProductGroupId] NVARCHAR (32)  NOT NULL,
    [BrandId]        NVARCHAR (32)  NOT NULL,
    [CountryId]      NVARCHAR (32)  NULL,
    [ProducerId]     NVARCHAR (32)  NULL,
    [MeasureUnitId]  NVARCHAR (32)  NOT NULL
);

