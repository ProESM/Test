﻿CREATE TABLE [archive].[Stores] (
    [SyncId]        INT            NOT NULL,
    [SyncCreated]   DATETIME       NOT NULL,
    [StoreId]       NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL,
    [ShortName]     NVARCHAR (32)  NULL,
    [StoreFormatId] NVARCHAR (32)  NOT NULL,
    [ClusterId]     NVARCHAR (32)  NOT NULL,
    [RegionId]      NVARCHAR (32)  NOT NULL,
    [OpenDate]      DATE           NULL,
    [Area]          REAL           NOT NULL,
    [OpenTime]      TIME (7)       NOT NULL,
    [CloseTime]     TIME (7)       NOT NULL,
    [Timezone]      INT            NOT NULL
);

