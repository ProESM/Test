﻿CREATE TABLE [archive].[Promotions] (
    [SyncId]                      INT            NOT NULL,
    [SyncCreated]                 DATETIME       NOT NULL,
    [StoreId]                     NVARCHAR (32)  NOT NULL,
    [ProductId]                   NVARCHAR (32)  NOT NULL,
    [PromoId]                     NVARCHAR (32)  NOT NULL,
    [Name]                        NVARCHAR (256) NOT NULL,
    [PromoTypeId]                 NVARCHAR (32)  NOT NULL,
    [StartDate]                   DATE           NOT NULL,
    [EndDate]                     DATE           NOT NULL,
    [AdditionalPlacementQuantity] INT            NULL
);

