﻿CREATE TABLE [archive].[MeasureUnits] (
    [SyncId]        INT            NOT NULL,
    [SyncCreated]   DATETIME       NOT NULL,
    [MeasureUnitId] NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL
);

