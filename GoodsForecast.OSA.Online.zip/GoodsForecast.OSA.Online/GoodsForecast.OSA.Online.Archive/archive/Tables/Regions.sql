﻿CREATE TABLE [archive].[Regions] (
    [SyncId]      INT            NOT NULL,
    [SyncCreated] DATETIME       NOT NULL,
    [RegionId]    NVARCHAR (32)  NOT NULL,
    [ParentId]    NVARCHAR (32)  NULL,
    [Name]        NVARCHAR (256) NOT NULL
);

