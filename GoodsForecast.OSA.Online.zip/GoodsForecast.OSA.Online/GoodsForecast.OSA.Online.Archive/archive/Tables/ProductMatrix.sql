﻿CREATE TABLE [archive].[ProductMatrix] (
    [SyncId]      INT         NOT NULL,
    [SyncCreated] DATETIME    NOT NULL,
    [LocationId]  INT         NOT NULL,
    [ProductId]   INT         NOT NULL,
    [Date]        DATE        NOT NULL,
    [IsKvi]       BIT         NOT NULL,
    [IsPromo]     BIT         NOT NULL,
    [Price]       REAL        NOT NULL,
    [AbcCategory] VARCHAR (1) NULL
);

