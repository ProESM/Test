﻿CREATE TABLE [archive].[Countries] (
    [SyncId]      INT            NOT NULL,
    [SyncCreated] DATETIME       NOT NULL,
    [CountryId]   NVARCHAR (32)  NOT NULL,
    [Name]        NVARCHAR (256) NOT NULL
);

