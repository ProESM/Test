﻿CREATE TABLE [archive].[Clusters] (
    [SyncId]      INT            NOT NULL,
    [SyncCreated] DATETIME       NOT NULL,
    [ClusterId]   NVARCHAR (32)  NOT NULL,
    [Name]        NVARCHAR (256) NOT NULL
);

