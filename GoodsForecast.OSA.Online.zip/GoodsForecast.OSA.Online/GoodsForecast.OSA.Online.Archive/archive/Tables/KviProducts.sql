﻿CREATE TABLE [archive].[KviProducts] (
    [SyncId]      INT           NOT NULL,
    [SyncCreated] DATETIME      NOT NULL,
    [StoreId]     NVARCHAR (32) NOT NULL,
    [ProductId]   NVARCHAR (32) NOT NULL
);

