﻿CREATE TABLE [archive].[ProductTypes] (
    [SyncId]        INT            NOT NULL,
    [SyncCreated]   DATETIME       NOT NULL,
    [ProductTypeId] NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL
);

