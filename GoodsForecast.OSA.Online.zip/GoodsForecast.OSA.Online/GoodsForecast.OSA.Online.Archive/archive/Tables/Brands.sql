﻿CREATE TABLE [archive].[Brands] (
    [SyncId]      INT            NOT NULL,
    [SyncCreated] DATETIME       NOT NULL,
    [BrandId]     NVARCHAR (32)  NOT NULL,
    [Name]        NVARCHAR (256) NOT NULL
);

