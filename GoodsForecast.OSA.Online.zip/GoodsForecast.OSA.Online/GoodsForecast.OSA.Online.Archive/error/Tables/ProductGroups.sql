﻿CREATE TABLE [error].[ProductGroups] (
    [SyncId]           INT            NOT NULL,
    [SyncCreated]      DATETIME       NOT NULL,
    [ProductGroupId]   NVARCHAR (32)  NOT NULL,
    [ParentId]         NVARCHAR (32)  NULL,
    [Name]             NVARCHAR (256) NOT NULL,
    [ErrorCode]        INT            NOT NULL,
    [ErrorDescription] NVARCHAR (256) NOT NULL
);

