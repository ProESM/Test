﻿CREATE TABLE [error].[Clusters] (
    [SyncId]           INT            NOT NULL,
    [SyncCreated]      DATETIME       NOT NULL,
    [ClusterId]        NVARCHAR (32)  NOT NULL,
    [Name]             NVARCHAR (256) NOT NULL,
    [ErrorCode]        INT            NOT NULL,
    [ErrorDescription] NVARCHAR (256) NOT NULL
);

