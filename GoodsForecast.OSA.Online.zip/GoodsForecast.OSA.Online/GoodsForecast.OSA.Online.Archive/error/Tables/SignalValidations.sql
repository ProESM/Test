﻿CREATE TABLE [error].[SignalValidations] (
    [SyncId]                 INT            NOT NULL,
    [SyncCreated]            DATETIME       NOT NULL,
    [SignalId]               BIGINT         NOT NULL,
    [ValidationDateTime]     DATETIME       NOT NULL,
    [IsCorrect]              BIT            NOT NULL,
    [SignalValidationTypeId] INT            NOT NULL,
    [ValidationDescription]  NVARCHAR (80)  NULL,
    [AuditorName]            NVARCHAR (80)  NULL,
    [ErrorCode]              INT            NOT NULL,
    [ErrorDescription]       NVARCHAR (256) NOT NULL
);

