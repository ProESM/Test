﻿CREATE USER [OKEY\dtarasov3] FOR LOGIN [OKEY\dtarasov3];

