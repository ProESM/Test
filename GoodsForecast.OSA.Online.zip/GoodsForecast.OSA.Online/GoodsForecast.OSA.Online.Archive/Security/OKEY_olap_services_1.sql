﻿CREATE LOGIN [OKEY\olap_services]
    FROM WINDOWS WITH DEFAULT_LANGUAGE = [us_english];

