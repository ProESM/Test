﻿CREATE SCHEMA [history]
    AUTHORIZATION [dbo];

