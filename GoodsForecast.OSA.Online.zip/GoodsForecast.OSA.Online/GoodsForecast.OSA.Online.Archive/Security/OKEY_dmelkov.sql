﻿CREATE USER [OKEY\dmelkov] FOR LOGIN [OKEY\dmelkov];

