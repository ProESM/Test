﻿CREATE USER [gfc_dba] FOR LOGIN [gfc_dba];

