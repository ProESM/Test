﻿CREATE USER [OKEY\olap_services] FOR LOGIN [OKEY\olap_services];

