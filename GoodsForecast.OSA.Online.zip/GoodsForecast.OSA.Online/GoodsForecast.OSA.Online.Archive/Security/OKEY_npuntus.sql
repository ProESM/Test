﻿CREATE USER [OKEY\npuntus] FOR LOGIN [OKEY\npuntus];

