﻿CREATE USER [gfc_osa_online] FOR LOGIN [gfc_osa_online];

