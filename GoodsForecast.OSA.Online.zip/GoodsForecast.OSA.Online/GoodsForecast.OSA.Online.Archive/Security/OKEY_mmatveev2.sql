﻿CREATE USER [OKEY\mmatveev2] FOR LOGIN [OKEY\mmatveev2];

