﻿CREATE SCHEMA [archive]
    AUTHORIZATION [dbo];

