﻿CREATE SCHEMA [archive_main]
    AUTHORIZATION [dbo];

