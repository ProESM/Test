﻿CREATE USER [OKEY\dfedorov6] FOR LOGIN [OKEY\dfedorov6];

