﻿CREATE SCHEMA [metadata]
    AUTHORIZATION [dbo];

