﻿CREATE TABLE [tmp].[Stocks_2021-08-07] (
    [SyncId]        INT           NOT NULL,
    [SyncCreated]   DATETIME      NOT NULL,
    [StoreId]       NVARCHAR (32) NOT NULL,
    [ProductId]     NVARCHAR (32) NOT NULL,
    [Datetime]      DATETIME      NOT NULL,
    [StockQuantity] REAL          NOT NULL,
    [Created]       DATETIME      NOT NULL
);

