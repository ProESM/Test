﻿CREATE TABLE [chks].[TotalDetailStocks] (
    [Date]          DATE          NOT NULL,
    [StoreId]       NVARCHAR (32) NOT NULL,
    [ProductCount]  INT           NOT NULL,
    [StockQuantity] REAL          NOT NULL,
    CONSTRAINT [PK_TotalDetailStocks] PRIMARY KEY CLUSTERED ([Date] ASC, [StoreId] ASC)
);

