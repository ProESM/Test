﻿CREATE TABLE [chks].[TotalSales] (
    [Date]        DATE NOT NULL,
    [RecordCount] INT  NOT NULL,
    CONSTRAINT [PK_TotalSales] PRIMARY KEY CLUSTERED ([Date] ASC)
);

