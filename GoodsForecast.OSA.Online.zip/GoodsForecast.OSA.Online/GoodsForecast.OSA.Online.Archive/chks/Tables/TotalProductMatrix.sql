﻿CREATE TABLE [chks].[TotalProductMatrix] (
    [Date]        DATE NOT NULL,
    [RecordCount] INT  NOT NULL,
    CONSTRAINT [PK_TotalProductMatrix] PRIMARY KEY CLUSTERED ([Date] ASC)
);

