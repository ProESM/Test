﻿CREATE TABLE [chks].[TotalDetailSales] (
    [Date]         DATE          NOT NULL,
    [StoreId]      NVARCHAR (32) NOT NULL,
    [ProductCount] INT           NOT NULL,
    [Quantity]     REAL          NOT NULL,
    [PriceSum]     REAL          NOT NULL,
    CONSTRAINT [PK_TotalDetailSales] PRIMARY KEY CLUSTERED ([Date] ASC, [StoreId] ASC)
);

