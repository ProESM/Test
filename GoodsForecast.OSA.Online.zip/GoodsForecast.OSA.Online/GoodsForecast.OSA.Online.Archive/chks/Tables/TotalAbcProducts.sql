﻿CREATE TABLE [chks].[TotalAbcProducts] (
    [Date]        DATE NOT NULL,
    [RecordCount] INT  NOT NULL,
    CONSTRAINT [PK_TotalAbcProducts] PRIMARY KEY CLUSTERED ([Date] ASC)
);

