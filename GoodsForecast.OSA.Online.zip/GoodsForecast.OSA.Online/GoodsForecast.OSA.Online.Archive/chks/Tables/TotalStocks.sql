﻿CREATE TABLE [chks].[TotalStocks] (
    [Date]        DATE NOT NULL,
    [RecordCount] INT  NOT NULL,
    CONSTRAINT [PK_TotalStocks] PRIMARY KEY CLUSTERED ([Date] ASC)
);

