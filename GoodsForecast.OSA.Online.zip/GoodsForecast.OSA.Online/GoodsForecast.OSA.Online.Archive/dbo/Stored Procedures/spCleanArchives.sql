﻿
CREATE PROCEDURE [dbo].[spCleanArchives]
AS
	DECLARE @LimitDate DATE = DATEADD(DAY, -7, CAST(GETDATE() AS DATE));

	DELETE s
	FROM [archive].[Sales] AS s
	WHERE s.[Datetime] < @LimitDate

	DELETE s
	FROM [archive].[Stocks] AS s
	WHERE s.[Datetime] < @LimitDate
