﻿
CREATE PROCEDURE [dbo].[spCleanArchivesAndErrors]
AS
	/*G4C. Clean archives and errors in STG*/

	/*Variables*/
	DECLARE @TableNameArchive [nvarchar](128),
			@TableNameError [nvarchar](128),
			@SQLString [nvarchar](max),

			@DeleteFromArchive [int] = 21,
			@DeleteFromError [int] = 21;

	/*Clean archive cursor*/
	DECLARE c CURSOR LOCAL FAST_FORWARD FOR 
		SELECT [TABLE_SCHEMA] + '.' +  [TABLE_NAME]
		FROM [INFORMATION_SCHEMA].[TABLES]
		WHERE [TABLE_SCHEMA] LIKE '%archive' 
			AND [TABLE_TYPE]='BASE TABLE'

	OPEN c
	WHILE 1=1 
	BEGIN
		FETCH c INTO @TableNameArchive
		IF @@fetch_status <> 0 BREAK

		SET @SQLString = 
			'DECLARE @DeletedRows [int];
			SET @DeletedRows = 1;
			WHILE (@DeletedRows > 0)
			BEGIN
				DELETE TOP (100000) ' + @TableNameArchive + '
				WHERE [SyncCreated] < DATEADD(MONTH,-' + CAST(@DeleteFromArchive AS [nvarchar](5)) + ',GETDATE())

				SET @DeletedRows = @@ROWCOUNT;
			END'
		EXEC (@SQLString)

	END
	CLOSE c
	DEALLOCATE c

	/*Clean errors cursor*/
	DECLARE c CURSOR LOCAL FAST_FORWARD FOR
		SELECT [TABLE_SCHEMA] + '.' + [TABLE_NAME]
		FROM [INFORMATION_SCHEMA].[TABLES]
		WHERE [TABLE_SCHEMA] LIKE 'error'
			AND [TABLE_TYPE]='BASE TABLE'

	OPEN c
	WHILE 1=1
	BEGIN
		FETCH c INTO @TableNameError
		IF @@fetch_status <> 0 BREAK
      
		SET @SQLString = 
			'DECLARE @DeletedRows [int];
			SET @DeletedRows = 1;
			WHILE (@DeletedRows > 0)
			BEGIN
				DELETE TOP (100000) ' + @TableNameError + '
				WHERE [SyncCreated] < DATEADD(MONTH,-' + CAST(@DeleteFromError AS [nvarchar](5)) + ',GETDATE())

				SET @DeletedRows = @@ROWCOUNT;
			END'
		EXEC (@SQLString)

	END
	CLOSE c
	DEALLOCATE c
