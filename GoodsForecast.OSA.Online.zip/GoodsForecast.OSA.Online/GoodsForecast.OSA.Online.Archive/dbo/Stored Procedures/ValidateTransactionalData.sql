﻿




CREATE PROCEDURE [dbo].[ValidateTransactionalData] 
   @SyncId INT
AS 

--DECLARE @SyncId INT = 1
DECLARE @Created DATETIME 

SELECT @Created = GETDATE()
DECLARE @StartDate DATE

SELECT @StartDate = CAST(s.StartDate AS DATE)
FROM [GFC.Projects.OSA.Online.Okey].dbo.SynchronizationDataLog AS s
WHERE s.SyncId = @SyncId

DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.SignalId,
	   DELETED.ValidationDateTime,
	   DELETED.IsCorrect,
	   DELETED.SignalValidationTypeId,
	   DELETED.ValidationDescription,
	   DELETED.AuditorName,   
       102, 
       'Поле SignalValidationTypeId не ссылается на SignalValidationTypeId таблицы SignalValidationTypeId'
 INTO ERROR.SignalValidations
(
   SyncId,
   SyncCreated,
   SignalId,
   ValidationDateTime,
   IsCorrect,
   SignalValidationTypeId,
   ValidationDescription,
   AuditorName, 
   ErrorCode,
   ErrorDescription
)    
FROM dbo.SignalValidations r
WHERE 
 NOT EXISTS ( SELECT 1 
              FROM dbo.SignalValidationTypes AS s 
              WHERE s.SignalValidationTypeId = r.SignalValidationTypeId
 ) 
  
 

DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId, 
       DELETED.ProductId, 
       DELETED.[Datetime],
       DELETED.StockQuantity, 
       DELETED.Created,
       103, 
       'Поле StoreId не ссылается на StoreId таблицы Stores'
 INTO ERROR.Stocks
(
   SyncId,
   SyncCreated,
   StoreId, 
   ProductId, 
   [Datetime],
   StockQuantity, 
   Created,
      ErrorCode,
   ErrorDescription
)  
FROM   dbo.Stocks r 
WHERE  r.DATETIME >= @StartDate AND
 NOT EXISTS ( SELECT 1 FROM dbo.Stores AS s 
              WHERE s.StoreId = r.StoreId
 )
 
 DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId, 
       DELETED.ProductId, 
       DELETED.[Datetime],
       DELETED.StockQuantity, 
       DELETED.Created,
       104, 
       'Поле ProductId не ссылается на ProductId таблицы Products'
 INTO ERROR.Stocks
(
   SyncId,
   SyncCreated,
   StoreId, 
   ProductId, 
   [Datetime],
   StockQuantity, 
   Created,
   ErrorCode,
   ErrorDescription
)  
FROM   dbo.Stocks r 
WHERE r.DATETIME >= @StartDate AND
 NOT EXISTS ( SELECT 1 FROM dbo.Products AS s 
              WHERE s.ProductId = r.ProductId
 )
 
  
 DELETE r
 OUTPUT @SyncId,
        @Created,
       DELETED.StoreId, 
       DELETED.ProductId, 
       DELETED.ChequeId,
	   DELETED.Datetime,
	   DELETED.Quantity,
	   DELETED.PriceSum, 
       DELETED.CREATED,
       105, 
       'Поле StoreId не ссылается на StoreId таблицы Stores'
 INTO ERROR.Sales
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ChequeId,
   Datetime,
   Quantity,
   PriceSum,   
   Created,
   ErrorCode,
   ErrorDescription
)  
FROM   dbo.Sales r 
WHERE r.Created >= @StartDate AND
 NOT EXISTS ( SELECT 1 FROM dbo.Stores AS s 
              WHERE s.StoreId = r.StoreId
 )
 
   
 DELETE r
 OUTPUT @SyncId,
        @Created,
      DELETED.StoreId, 
       DELETED.ProductId, 
       DELETED.ChequeId,
	   DELETED.Datetime,
	   DELETED.Quantity,
	   DELETED.PriceSum, 
       DELETED.CREATED,
       106, 
       'Поле ProductId не ссылается на ProductId таблицы Products'
 INTO ERROR.Sales
(
   SyncId,
   SyncCreated,
   StoreId,
   ProductId,
   ChequeId,
   Datetime,
   Quantity,
   PriceSum,   
   Created,
   ErrorCode,
   ErrorDescription
)  
FROM   dbo.Sales r 
 WHERE r.Created >= @StartDate AND
 NOT EXISTS ( SELECT 1 FROM dbo.Products AS s 
              WHERE s.ProductId = r.ProductId
 )
  
  
--2.4.15.	Продажи (Sales)
--1.	StoreId содержит не пустую строку
--2.	ProductId содержит не пустую строку
--3.	ChequeId содержит не пустую строку
--4.	Datetime содержит не пустую дату и время (локальное, не UTC)
--5.	Quantity содержит число с плавающей запятой, не может быть пустым
--6.	PriceSum содержит число с плавающей запятой, не может быть пустым
--7.	Поле StoreId ссылается на StoreId таблицы Stores
--8.	Поле ProductId ссылается на ProductId таблицы Products
