﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Reports
{ 
    /// <summary>
    /// Сводный отчет
    /// </summary>
    public class FilteredConsolidatedReport
    {
        /// <summary>
        /// дата проверки
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// день недели проверки
        /// </summary>
        public string WeekDay { get; set; }

        /// <summary>
        /// номер недели проверки
        /// </summary>
        public int WeekNumber { get; set; }

        /// <summary>
        /// время сигнала: 12, 15, 18 или 22 часа
        /// </summary>
        public TimeSpan SignalTime { get; set; }

        /// <summary>
        /// месяц проверки
        /// </summary>
        public string Month { get; set; }

        /// <summary>
        /// Товарная категория
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Товарная подкатегория
        /// </summary>
        public string SubCategory { get; set; }

        /// <summary>
        /// Товарная группа
        /// </summary>
        public string Group { get; set; }

        /// <summary>
        /// Товарная подгруппа
        /// </summary>
        public string SubGroup { get; set; }

        /// <summary>
        ///  Артикул товара
        /// </summary>
        public string Artikul { get; set; }

        /// <summary>
        /// Наименование товара
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Признак новинки
        /// </summary>
        public string IsNewItem { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public string Store { get; set; }

        /// <summary>
        /// Кластер
        /// </summary>
        public string Cluster { get; set; }

        /// <summary>
        /// Регион
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Номер сигнала
        /// </summary>
        public long SignalId { get; set; }

        /// <summary>
        /// Номер родительского сигнала
        /// </summary>
        public long? SignalParentId { get; set; }

        /// <summary>
        /// Корректность сигнала
        /// </summary>
        public string IsCorrect { get; set; }

        /// <summary>
        /// Обратная связь
        /// </summary>
        public int? SignalValidationTypeId { get; set; }

        /// <summary>
        /// Комментарий к обратной связи
        /// </summary>
        public string ValidationDescription { get; set; }

        /// <summary>
        /// Дата и время обратной связи
        /// </summary>
        public DateTime? ValidationDateTime { get; set; }

        /// <summary>
        /// ФИО сотрудника
        /// </summary>
        public string AuditorName { get; set; }

        /// <summary>
        /// Объем упущенных продаж, шт
        /// </summary>
        public float LostSalesQuantity { get; set; }

        /// <summary>
        /// Объем упущенных продаж, руб
        /// </summary>
        public float LostSalesMoney { get; set; }

        /// <summary>
        /// Объем доп продаж, шт
        /// </summary>
        public float AddSalesQuantity { get; set; }

        /// <summary>
        /// Объем доп продаж, руб
        /// </summary>
        public float AddSalesMoney { get; set; }
    }
}
