﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Reports
{
    /// <summary>
    /// Отчет о правильности проверки
    /// </summary>
    public class ValidationCorrectnessReport
    {
        public int LocationId { get; set; }

        public int ExternalId { get; set; } 

        public string ShortName { get; set; }

        public string ShopName { get; set; }
        public bool IsInPilot { get; set; }

        public DateTime DateTime { get; set; }

        public int SignalsCount { get; set; }

        public int SignalsIntimeCount { get; set; }

        public int SignalsWithAnyValidation { get; set; }

        public int HumanValidedSignalsCount { get; set; }

        public int HumanValidatedIntimeCount { get; set; }

        public int HumanValidatedCorrectSignalsCount { get; set; }

        public int TotalCorrectSignalsCount { get; set; }

        public int TotalCorrectIntimeSignalsCount { get; set; }

        public float HumanValidatedPart { get; set; }

        public float HumanValidatedIntimePart { get; set; }

        public float HumanValidatedPrecision { get; set; }

        public float LostSales { get; set; }

        public float HumanValidatedLostSales { get; set; }

        public float HumanValidatedCorrectLostSales { get; set; }

        public float TotalCorrectLostSales { get; set; }

        public float TotalCorrectIntimeLostSales { get; set; }

        public float HumanValidatedCorrectness { get; set; }

        public float TotalCorrectness { get; set; }

        public float TotalCorrectnessIntime { get; set; }

        public byte HasLateSignals { get; set; }

        public byte StrangeHumanValidation { get; set; }

        public byte LowHumalValidation { get; set; }

        public byte FullHumanValidation { get; set; }

        public int AuditorsCount { get; set; }
    }
}
