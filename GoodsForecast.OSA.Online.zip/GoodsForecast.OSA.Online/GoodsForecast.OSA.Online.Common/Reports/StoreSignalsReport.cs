﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Reports
{
    /// <summary>
    /// Отчет по сигналам магазинов
    /// </summary>
    public class StoreSignalsReport
    {
        /// <summary>
        /// Дата
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Название магазина
        /// </summary>
        public string StoreName { get; set; }

        /// <summary>
        /// Магазин в ОЭ
        /// </summary>
        public byte IsInPilot { get; set; }

        /// <summary>
        /// Количество отчетов
        /// </summary>
        public byte ReportsCount { get; set; }

        /// <summary>
        /// Количество сигналов
        /// </summary>
        public int SignalsCount { get; set; }

        /// <summary>
        /// С запозданием?
        /// </summary>
        public byte IsLate { get; set; }

        /// <summary>
        /// Количество сигналов с обратной связью
        /// </summary>
        public int SignalsWithFeedbackCount { get; set; }

        /// <summary>
        /// Количетсво сигналов без обратной связи
        /// </summary>
        public int SignalsWithoutFeedbackCount { get; set; }

        /// <summary>
        /// Точность по магазину
        /// </summary>
        public double ShopAccuracy { get; set; }

        /// <summary>
        /// Точность только по тем сигналам, по которым была обратная связь
        /// </summary>
        public double SignalsWithFeedbackAccuracy { get; set; }
    }
}
