﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Reports
{
    /// <summary>
    /// Отчет по неделе, сгруппированный по категориям
    /// </summary>
    public class CategoryWeekAggregationReport
    {
        /// <summary>
        /// Номер недели
        /// </summary>
        public int WeekNumber { get; set; }

        /// <summary>
        /// День недели
        /// </summary>
        public string WeekDay { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public string Store { get; set; }

        /// <summary>
        /// Название категории
        /// </summary>
        public string Category { get; set; }

        /// <summary>
        /// Количество сигналов
        /// </summary>
        public int SignalCount { get; set; }

        /// <summary>
        /// Количество правильных сигналов
        /// </summary>
        public int CorrectSignalCount { get; set; }

        /// <summary>
        /// Объем упущенных продаж в руб
        /// </summary>
        public float SumLossSalesMoney { get; set; }

        /// <summary>
        /// Объем доп продаж в руб
        /// </summary>
        public float SumAddSalesMoney { get; set; }
    }
}
