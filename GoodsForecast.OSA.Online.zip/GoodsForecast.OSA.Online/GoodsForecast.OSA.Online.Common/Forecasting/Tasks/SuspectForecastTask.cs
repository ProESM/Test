﻿using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks
{
    /// <summary>
    /// Задания для формирования сигналов 
    /// </summary>
    public class SuspectForecastTask
    {
        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Продукт
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Интервалы-кандидаты для TSA
        /// </summary>
        public IEnumerable<Suspect> Suspects { get; set; }

        /// <summary>
        /// Остатки по дням
        /// </summary>
        public ProductStockSeries Stocks { get; set; }

        /// <summary>
        /// Продажи по часам
        /// </summary>
        public ProductSaleSeries Sales { get; set; }

        /// <summary>
        /// Специальные периоды по дням
        /// </summary>
        public HolidayPeriodSeries HolidayPeriods { get; set; }

        /// <summary>
        /// Акции по дням
        /// </summary>
        public PromotionSeries Promotions { get; set; }

        /// <summary>
        /// Связанные по кластеру магазины
        /// </summary>
        public List<RelatedStore> RelatedStores { get; set; }

        /// <summary>
        /// Расписание работы магазинов
        /// </summary>
        public IDictionary<DayOfWeek, TimePeriod> Schedule { get; set; }


        public override string ToString()
        {
            return string.Format("LocationId: {0}, ProductId: {1}", LocationId, ProductId);
        }
    }
}
