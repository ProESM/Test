﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks
{
    /// <summary>
    /// Тип алгоритма
    /// </summary>
    public enum AlgType
    {
        ByOneStore = 1,
        ByCluster = 2
    }
}
