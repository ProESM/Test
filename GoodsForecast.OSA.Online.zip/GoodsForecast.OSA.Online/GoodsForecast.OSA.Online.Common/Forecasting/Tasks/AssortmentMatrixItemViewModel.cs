﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Ассортиментная матрица
    /// </summary>
    public class AssortmentMatrixItemViewModel
    {
        /// <summary>
        /// Дата наличия товара в магазине
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Участвует ли товар в промоакции
        /// </summary>
        public bool IsPromo { get; set; }

        /// <summary>
        /// Является товар kvi товаром
        /// </summary>
        public bool IsKvi { get; set; }

        /// <summary>
        /// Цена товара
        /// </summary>
        public float Price { get; set; }

        /// <summary>
        /// Категория товара
        /// </summary>
        public string AbcCategory { get; set; }
    }
}
