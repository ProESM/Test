﻿using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks
{
    /// <summary>
    /// Связанные магазины из того же кластера, что и подозреваемый магазин
    /// </summary>
    public class RelatedStore : IEquatable<RelatedStore>
    {
        /// <summary>
        /// Связанный по кластеру магазин 
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Подозреваемый товар, связанный с подозреваемым магазином
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Начало периода подозрений для подозреваемого магазина
        /// </summary>
        public DateTime StartDateTime { get; set; }

        /// <summary>
        /// Конец периода подозрений для подозреваемого магазина
        /// </summary>
        public DateTime EndDateTime { get; set; }

        /// <summary>
        /// Расписание работы связанного по кластеру магазина
        /// </summary>
        public IDictionary<DayOfWeek, TimePeriod> Schedule { get; set; }

        /// <summary>
        /// Время открытия связанного по кластеру магазина
        /// </summary>
        public TimeSpan OpenTime { get; set; }

        /// <summary>
        /// Время закрытия связанного по кластеру магазина
        /// </summary>
        public TimeSpan CloseTime { get; set; }

        /// <summary>
        /// Остатки по дням связанного по кластеру магазина
        /// </summary>
        public List<ProductStockSeries> Stocks { get; set; }

        /// <summary>
        /// Продажи по часам связанного по кластеру магазина
        /// </summary>
        public List<ProductSaleSeries> Sales { get; set; }

        /// <summary>
        /// Специальные периоды по дням связанного по кластеру магазина
        /// </summary>
        public List<HolidayPeriodSeries> HolidayPeriods { get; set; }

        /// <summary>
        /// Акции по дням связанного по кластеру магазина
        /// </summary>
        public List<PromotionSeries> Promotions { get; set; }


        public bool Equals(RelatedStore other)
        {
            if (Object.ReferenceEquals(other, null)) return false;

            if (Object.ReferenceEquals(this, other)) return true;

            return LocationId.Equals(other.LocationId) && ProductId.Equals(other.ProductId);
        }

        public override int GetHashCode()
        {
            int hashProductId = ProductId.GetHashCode();
            int hashLocationId = LocationId.GetHashCode();
            return hashProductId ^ hashLocationId;
        }
    }
}
