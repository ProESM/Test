﻿using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Задача на расчет для пары товар-магазин
    /// </summary>
    public class LostSalesAnalysisTaskViewModel
    {
        /// <summary>
        /// Идентификатор задачи
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Задание на расчет
        /// </summary>
        public long LostSalesAnalysisJobId { get; set; }

        /// <summary>
        /// Субджоб
        /// </summary>
        public long? LostSalesAnalysisSubJobId { get; set; }

        /// <summary>
        /// Батч
        /// </summary>
        public long? LostSalesAnalysisBatchId { get; set; }

        /// <summary>
        /// Пачка задания на расчет
        /// </summary>
        public long? LostSalesAnalysisSubBatchId { get; set; }

        /// <summary>
        /// Тип батча
        /// </summary>
        public CalcType CalcType { get; set; }

        /// <summary>
        /// Тип алгоритма
        /// </summary>
        public AlgType AlgType { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Начало предполагаемого периода (дата и время)
        /// </summary>
        public DateTime StartDateTime { get; set; }

        /// <summary>
        /// Окончание предполагаемого периода (дата и время)
        /// </summary>
        public DateTime EndDateTime { get; set; }

        /// <summary>
        /// Длительность предполагаемого периода в часах
        /// </summary>
        public short? LengthHours { get; set; }

        /// <summary>
        /// Количество пустых часов, при котором период считается пустым
        /// </summary>
        public short ThresholdLengthWorkingHours { get; set; }

        /// <summary>
        /// Дата создания задачи (время московское)
        /// </summary>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Цена товара в магазине
        /// </summary>
        public float? Price { get; set; }

        /// <summary>
        /// Длительность предполагаемого периода в часах 
        /// во время работы магазина
        /// </summary>
        public short? LengthWorkingHours { get; set; }

        /// <summary>
        /// Время открытия магазина
        /// </summary>
        public TimeSpan OpenTime { get; set; }

        /// <summary>
        /// Время закрытия магазина
        /// </summary>
        public TimeSpan CloseTime { get; set; }

        /// <summary>
        /// Тип алгоритма промо
        /// </summary>
        public bool PromoAlgType { get; set; }

        /// <summary>
        /// Является ли товар kvi товаром
        /// </summary>
        public bool IsKvi { get; set; }
    }
}
