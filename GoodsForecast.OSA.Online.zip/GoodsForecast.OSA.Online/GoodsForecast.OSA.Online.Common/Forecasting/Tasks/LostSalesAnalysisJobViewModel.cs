﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Задание на расчет
    /// </summary>
    public class LostSalesAnalysisJobViewModel
    {
        /// <summary>
        /// Идентификатор задания
        /// </summary>
        public long JobId { get; set; }

        /// <summary>
        /// Анализируемая дата (за 1 час до сигнала)
        /// </summary>
        public DateTime AnalizeDatetime { get; set; }

        /// <summary>
        /// Статус расчета
        /// </summary>
        public LostSalesAnalysisStatus Status { get; set; }

        /// <summary>
        /// Дата и время создания задания на расчет
        /// </summary>
        public DateTime? Created { get; set; }

        /// <summary>
        /// Дата и время подготовки параметров
        /// </summary>
        public DateTime? JobPreparedParams { get; set; }

        /// <summary>
        /// Дата и время подготовки задач
        /// </summary>
        public DateTime? FilledTasks { get; set; }

        /// <summary>
        /// Дата и время сохранения результатов
        /// </summary>
        public DateTime? FilledJobResults { get; set; }

        /// <summary>
        /// Дата и время переноса результатов в ПБД
        /// </summary>
        public DateTime? JobResultsProceed { get; set; }

        /// <summary>
        /// Дата и время переноса данных по расчету в историю
        /// </summary>
        public DateTime? MovedToHistory { get; set; }

        /// <summary>
        /// Задачи на расчет
        /// </summary>
        public IEnumerable<LostSalesAnalysisTaskViewModel> Tasks { get; set; }
    }
}
