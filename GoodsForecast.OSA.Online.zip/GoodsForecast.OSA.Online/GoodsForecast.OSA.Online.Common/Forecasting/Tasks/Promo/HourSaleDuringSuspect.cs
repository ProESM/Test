﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks.Promo
{
    /// <summary>
    /// Продажи по похожим магазинам для расчета по промо
    /// </summary>
    public class HourSaleDuringSuspect
    {
        /// <summary>
        /// Магазин, в котором предполагается отсутствие продаж
        /// </summary>
        public int SuspectLocationId { get; set; }

        /// <summary>
        /// Количество магазинов, похожих на магазин,
        /// в котором предполагается отсутствие продаж
        /// </summary>
        public int SimilarLocationCount { get; set; }

        /// <summary>
        /// Магазин, похожий на магазин,
        /// в котором предполагается отсутствие продаж
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Задача на расчет
        /// </summary>
        public long LostSalesAnalysisTaskId { get; set; }

        /// <summary>
        /// Дата и время продажи
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Количество продаж
        /// </summary>
        public float Quantity { get; set; }
    }
}
