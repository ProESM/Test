﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks.Promo
{
    public class HourSaleDuringPromo
    {
        public int LocationId { get; set; }

        public int ProductId { get; set; }

        public long TaskId { get; set; }

        public DateTime TaskStart { get; set; }

        public DateTime TaskEnd { get; set; }

        public DateTime Date { get; set; }

        public float Quantity { get; set; }
    }
}
