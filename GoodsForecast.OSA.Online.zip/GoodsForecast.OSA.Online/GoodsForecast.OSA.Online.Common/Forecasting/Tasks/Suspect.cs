﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Интервалы-кандидаты
    /// </summary>
    public class Suspect
    {
        /// <summary>
        /// Идентификатор интервала
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Начало интевала
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Окончание интервала
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Продолжительность интевала в часах
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// Количество пустых часов, 
        /// при котором интервал считается пустым
        /// </summary>
        public int Threshold { get; set; }

        /// <summary>
        /// Тип алгоритма для промо
        /// </summary>
        public bool? PromoAlgType { get; set; }

        /// <summary>
        /// Является ли товар kvi-товаром
        /// </summary>
        public bool? IsKvi { get; set; }
    }
}
