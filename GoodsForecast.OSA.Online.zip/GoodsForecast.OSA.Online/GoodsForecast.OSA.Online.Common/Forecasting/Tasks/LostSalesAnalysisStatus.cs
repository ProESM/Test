﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Статусы расчета
    /// </summary>
    public enum LostSalesAnalysisStatus: byte
    {
        Undefined = 0,
        New = 1,
        JobPreparedParams = 2,
        FilledTasks = 3,
        FilledJobResults = 4,
        JobResultProceed = 5,
        MoveToHistory = 6
    }
}
