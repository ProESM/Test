﻿using Forecsys.TSA.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks
{
    /// <summary>
    /// Параметры расчета
    /// </summary>
    public class LostSalesAnalysisParamViewModel
    {
        /// <summary>
        ///Задание на расчет
        /// </summary>
        public long JobId { get; set; }

        public float Threshold { get; set; }

        public float HistParam1 { get; set; }

        public float HistParam2 { get; set; }

        public float HistParam3 { get; set; }

        public bool IsGlobalProfile { get; set; }

        /// <summary>
        /// Использовать дефициты
        /// </summary>
        public bool UseDeficit { get; set; }

        /// <summary>
        /// Использовать промо
        /// </summary>
        public bool UsePromo { get; set; }

        public bool UseClosed { get; set; }

        public bool UseClearOutliers { get; set; }

        /// <summary>
        /// Если флаг не выставлен (по умолчанию), промо всегда убирается из истории. 
        /// Если флаг выставлен, промо убирается из истории, только если оно попадает в интервал с подозрением на отсутствие товара на полке.
        /// </summary>
        public bool AdjustPromoForTask { get; set; }

        public bool AdjustHolidayForTask { get; set; }

        /// <summary>
        /// Использовать праздники (специальные периоды)
        /// </summary>
        public bool UseHoliday { get; set; }

        /// <summary>
        /// Ширина окна, по которому считается уровень при фильтрации выбросов.(По умолчанию (21 * 24))
        /// </summary>
        public ParameterInt ClearOutliersWindowsWidth { get; set; }

        /// <summary>
        /// Порог (коэффициент), при отклонении на него от уровня (мультипликативно) значение считается выбросом
        /// </summary>
        public ParameterDouble ClearOutliersThreshold { get; set; }

        /// <summary>
        /// Режим фильтрации выбросов.
        /// 1 - Replace_NaN
        /// 2 - Replace_Med
        /// 3 - Replace_Max (or Min)
        /// 4 - No_Replace
        /// 5 - Replace_Avg
        /// </summary>
        public ParameterInt ClearOutliersReplacementMode { get; set; }

        /// <summary>
        /// Выгружать ли json, который подается на вход TSA
        /// </summary>
        public bool NeedPreExecutionJson { get; set; }

        /// <summary>
        /// Выгружать ли json, который возвращает TSA
        /// </summary>
        public bool NeedPostExecutionJson { get; set; }

        /// <summary>
        /// Максимальное число ДНЕЙ, по которому оценивается вероятность
        /// </summary>
        public int DaysCount { get; set; }

        /// <summary>
        /// Использовать ли недельный профиль при оценке вероятности
        /// </summary>
        public bool UseWeekProfile { get; set; }

        /// <summary>
        /// Максимально возможное соотношение числа незначащих точек к длине интервала
        /// </summary>
        public double MaxNanPointsIntervalPart { get; set; }

        /// <summary>
        /// Минимально возможное число значащих точек с аналогичной фазой (часом и днем недели, например).
        /// Если точек с такой фазой меньше, то считается, что вероятность нуля для фазы - NaN;
        /// </summary>
        public int MinValidPointsCount { get; set; }

        /// <summary>
        /// Порог, который проставляется всем подозреваемым, вне зависимости от дополнительных логик
        /// </summary>
        public double DefaultThreshold { get; set; }

        /// <summary>
        /// Порог, который проставляется подозреваемым с нулевым остатком на момент начала.
        /// </summary>
        public double StockThresholdForBegin { get; set; }

        /// <summary>
        /// Порог, который проставляется подозреваемым с нулевым остатком на момент начала в случае подозреваемого, расположенного внутри одного дня.
        /// </summary>
        public double StockThresholdForBeginInOneDay { get; set; }

        /// <summary>
        /// Порог в часах, выше которого при наличии нулевого остатка подозреваемый признается OOS.
        /// </summary>
        public int HourLenThreshold { get; set; }

        /// <summary>
        /// Использовать алгоритм по кластерам
        /// </summary>
        public bool UseStoresAnalysis { get; set; }

        /// <summary>
        /// Очищать выбросы (отклонения) только для подозрений
        /// </summary>
        public bool ClearOutliersOnlyForSuspects { get; set; }
    }
}
