﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Tasks
{
    /// <summary>
    /// Предполагаемая пара товар-магазин, кандидат на сигнал
    /// </summary>
    public class SuspectPair: IEquatable<SuspectPair>
    {
        private int _productId;
        private int? _locationId;
        private int? _openTime;
        private int? _closeTime;

        public SuspectPair(int productId, int? locationId = null, int? openTime = null, int? closeTime = null)
        {
            _productId = productId;
            _locationId = locationId;
            _openTime = openTime;
            _closeTime = closeTime;
        }

        public int ProductId 
        { 
            get { return _productId; }
            set { _productId = value; }
        }
        public int? LocationId
        {
            get { return _locationId; }
            set { _locationId = value; }
        }
        public int? OpenTime
        {
            get { return _openTime; }
            set { _openTime = value; }
        }
        public int? CloseTime
        {
            get { return _closeTime; }
            set { _closeTime = value; }
        }



        //
        public bool Equals(SuspectPair other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return ProductId == other.ProductId && (LocationId == null && other.LocationId == null || LocationId == other.LocationId);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((SuspectPair)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (ProductId * 397) ^ ProductId;
            }
        }

        public static bool operator ==(SuspectPair left, SuspectPair right)
        {
            return Equals(left, right);
        }

        public static bool operator !=(SuspectPair left, SuspectPair right)
        {
            return !Equals(left, right);
        }
    }
}
