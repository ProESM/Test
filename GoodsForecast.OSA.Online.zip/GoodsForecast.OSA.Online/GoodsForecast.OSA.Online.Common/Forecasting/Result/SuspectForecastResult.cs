﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Result
{
    /// <summary>
    /// Данные о подозреваемых (возможных упущенных продажах)
    /// </summary>
    public class SuspectForecastResult
    {
        /// <summary>
        /// Идентификатор задачи
        /// </summary>
        public long TaskId { get; set; }

        /// <summary>
        /// Магазин, в котором найден подозреваемый.
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар, на котором найден подозреваемый.
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Является ли результат сигналом
        /// </summary>
        public bool IsPhantom { get; set; }

        /// <summary>
        /// Вероятность нормы нулевых продаж.
        /// </summary>
        public float Probability { get; set; }

        /// <summary>
        /// Сумма упущенных продаж за период, шт.
        /// </summary>
        public float MeanSell { get; set; }

        /// <summary>
        /// Рассчитано ли в TSA (промо могут считаться нами по средним продажам)
        /// </summary>
        public bool IsCalculatedInTsa { get; set; }

        /// <summary>
        /// Почасовые данные о подозреваемых (возможных упущенных продажах)
        /// </summary>
        public SortedList<DateTime, SuspectResult> SuspectResults { get; set; }

        public override string ToString()
        {
            return string.Format("TaskId: {0}, LocationId: {1}, ProductId: {2}", LocationId, ProductId);
        }
    }
}
