﻿using System;
using System.Collections.Generic;


namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Задача на расчет
    /// </summary>
    public class SuspectForecastBatchItem
    {
        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Интервалы-кандидаты
        /// </summary>
        public ICollection<Suspect> Suspects { get; set; }

        /// <summary>
        /// Расписание работы магазина
        /// </summary>
        public Dictionary<DayOfWeek, TimePeriod> Schedule { get; set; }
    }
}
