﻿using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Батч на расчет
    /// </summary>
    public class SuspectForecastBatch: BrokerToCalculatorMessage
    {
        /// <summary>
        /// Расписание работы магазина
        /// </summary>
        public Dictionary<DayOfWeek, TimePeriod> Schedule { get; set; }

        /// <summary>
        /// Задачи на расчет
        /// </summary>
        public ICollection<SuspectForecastBatchItem> Items { get; set; }

        /// <summary>
        /// Дата начала для получения исторических данных(продаж, остатков, ...)
        /// </summary>
        public DateTime? HistoryStartDate { get; set; }

        /// <summary>
        /// Дата окончания для получения исторических данных(продаж, остатков, ...)
        /// </summary>
        public DateTime? HistoryEndDate { get; set; }

        /// <summary>
        /// Брать ли вероятность из расчета TSA или считать за 1
        /// </summary>
        public bool IsAbsoluteProbability { get; set; }
    }
}
