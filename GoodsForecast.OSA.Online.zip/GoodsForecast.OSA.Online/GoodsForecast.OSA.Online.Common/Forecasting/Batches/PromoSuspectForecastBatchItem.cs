﻿using System;
using System.Collections.Generic;


namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Задача на расчет для промо
    /// </summary>
    public class PromoSuspectForecastBatchItem
    {
        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Расписание работы магазина
        /// </summary>
        public Dictionary<DayOfWeek, TimePeriod> Schedule { get; set; }

        /// <summary>
        /// Идентификатор задачи на расчет
        /// </summary>
        public long Id { get; set; }

        /// <summary>
        /// Начало анализируемого периода
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Окончание анализируемого периода
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Продолжительность анализируемого периода в часах
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// Количество пустых часов, когда период будет считаться пустым
        /// </summary>
        public int Threshold { get; set; }

        /// <summary>
        /// Тип алгоритма промо
        /// </summary>
        public bool? PromoAlgType { get; set; }

        /// <summary>
        /// Является ли товар kvi-товаром
        /// </summary>
        public bool? IsKvi { get; set; }
    }
}
