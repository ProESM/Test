﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Тип расчета
    /// </summary>
    public enum CalcType
    {
        LocationProduct = 1,
        Kvi = 2,
        Promo = 3
    }
}
