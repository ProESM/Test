﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Временной период для TSA
    /// </summary>
    public struct TimePeriod
    {
        public TimeSpan Start { get; set; }

        public TimeSpan End { get; set; }
    }
}
