﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Остатки
    /// </summary>
    public class LocationStateStocksViewModel
    {
        /// <summary>
        /// Дата остатков в днях
        /// </summary>
        public DateTime Datetime { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Размер остатка
        /// </summary>
        public float? Quantity { get; set; }
    }
}
