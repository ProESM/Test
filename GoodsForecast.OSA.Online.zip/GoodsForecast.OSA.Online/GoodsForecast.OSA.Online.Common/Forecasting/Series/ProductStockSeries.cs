﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Временной ряд остатков
    /// </summary>
    public class ProductStockSeries : ISeries, ISeries<float>
    {
        public ProductStockSeries() { }

        /// <summary>
        /// Начало периода
        /// </summary>
        public DateTime StartDate { get; set; }
        
        /// <summary>
        ///  Конец периода
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///  Шаг приращения
        /// </summary>
        public TimeSpan Step { get; set; }

        /// <summary>
        ///  Значения
        /// </summary>
        public IEnumerable<float> Values { get; set; }
    }
}
