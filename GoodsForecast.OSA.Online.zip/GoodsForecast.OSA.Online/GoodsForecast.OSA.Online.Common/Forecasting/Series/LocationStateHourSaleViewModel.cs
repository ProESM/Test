﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting
{
    /// <summary>
    /// Почасовые продажи
    /// </summary>
    public class LocationStateHourSaleViewModel
    {
        /// <summary>
        /// Дата и время продажи
        /// </summary>
        public DateTime Datetime { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Количество продаж
        /// </summary>
        public float? Quantity { get; set; }

        /// <summary>
        /// Цена
        /// </summary>
        public float? PriceSum { get; set; }

        /// <summary>
        /// Время открытия магазина
        /// </summary>
        public TimeSpan? OpenTime { get; set; }

        /// <summary>
        /// Время закрытия магазина
        /// </summary>
        public TimeSpan? CloseTime { get; set; }
    }
}
