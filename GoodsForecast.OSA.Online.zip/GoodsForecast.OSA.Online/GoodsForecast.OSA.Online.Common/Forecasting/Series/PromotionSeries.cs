﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Временной ряд акций
    /// </summary>
    public class PromotionSeries : ISeries<long>
    {
        /// <summary>
        /// Дата начала
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Дата окончания
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Шаг (день, час...)
        /// </summary>
        public TimeSpan Step { get; set; }

        /// <summary>
        /// Набор значений (1, 0 - акция, не акция)
        /// </summary>
        public IEnumerable<long> Values { get; set; }
    }
}
