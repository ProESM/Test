﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Матрица промо
    /// </summary>
    public class PromotionMatrixViewModel
    {
        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Товар
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Дата начала промоакции
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Дата окончания промоакции
        /// </summary>
        public DateTime EndDate { get; set; }
    }
}
