﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Временной ряд продаж
    /// </summary>
    public class ProductSaleSeries : ISeries, ISeries<float>
    {
        public ProductSaleSeries() { }

        /// <summary>
        /// Начало периода
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        ///  Конец периода
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        ///  Шаг приращения
        /// </summary>
        public TimeSpan Step { get; set; }

        /// <summary>
        /// Продажи
        /// </summary>
        public IEnumerable<float> Values { get; set; }
    }
}
