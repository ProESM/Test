﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Forecasting.Series
{
    /// <summary>
    /// Сигнатура временного ряда
    /// </summary>
    /// <typeparam name="T">Тип значений ряда, обычно float</typeparam>
    public interface ISeries<T> where T : struct
    {
        DateTime StartDate { get; }
        DateTime EndDate { get; }
        TimeSpan Step { get; }
        IEnumerable<T> Values { get; }
    }

    /// <summary>
    /// Сигнатура временного ряда с типом значений float
    /// </summary>
    public interface ISeries : ISeries<float>
    {
    }
}
