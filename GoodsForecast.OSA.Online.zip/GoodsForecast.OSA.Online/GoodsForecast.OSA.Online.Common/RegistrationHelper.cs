﻿using GoodsForecast.OSA.Online.Common.Jobs;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace GoodsForecast.OSA.Online.Common
{
    public static class RegistrationHelper
    {
        /// <summary>
        /// Регистрирует джобы, которые можно запускать из командной строки
        /// </summary>
        /// <param name="services"></param>
        /// <returns></returns>
        public static IServiceCollection RegisterJobs(this IServiceCollection services)
        {
            return services
                .AddScoped<IServiceJob, TestServiceJob>();
        }
    }
}
