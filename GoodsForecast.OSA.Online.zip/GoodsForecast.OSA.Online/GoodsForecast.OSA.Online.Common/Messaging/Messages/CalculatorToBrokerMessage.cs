﻿using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    /// <summary>
    /// Сообщение от калькулятора к брокеру о завершении расчета по типу расчета
    /// </summary>
    public class CalculatorToBrokerMessage : IQueueMessage
    {
        /// <summary>
        /// Идентификатор расчета
        /// </summary>
        public long JobId { get; set; }

        /// <summary>
        /// Суббатч
        /// </summary>
        public long? SubBatchId { get; set; }

        /// <summary>
        /// Субджоб
        /// </summary>
        public long? SubJobId { get; set; }

        /// <summary>
        /// Батч
        /// </summary>
        public long? BatchId { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }

        /// <summary>
        /// Общее количество пачек
        /// </summary>
        public int AllCount { get; set; }

        /// <summary>
        /// Завершился ли расчет с ошибкой
        /// </summary>
        public bool IsError { get; set; }

        /// <summary>
        /// Текст ошибки, при наличии
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Количество перезапусков пачки
        /// </summary>
        public int RestartCount { get; set; }
    }
}
