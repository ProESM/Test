﻿using GoodsForecast.OSA.Online.Contracts.Interfaces;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    public class BrokerToReporterMessage : IQueueMessage
    {
        public long JobId { get; set; }
    }
}
