﻿using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System.Collections.Generic;
using System.Net.Mail;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    public class BrokerToMessengerMessage : IQueueMessage
    {
        public string Sender { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public IEnumerable<string> Recipients { get; set; }
        /// <summary>
        /// Вложения
        /// </summary>
        /// <remarks>
        /// <para>Ключ - название файла + расширение</para>
        /// <para>Значение - представление файла в виде массива byte</para>
        /// </remarks>
        /// <example>
        /// { example.txt, new byte[0] }
        /// { example.pdf, new byte[0] }
        /// </example>
        public Dictionary<string, byte[]> Attachments { get; set; }
        public MailPriority Priority { get; set; }
        public long JobId { get; set; }
    }
}
