﻿using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    public class BrokerToBrokerMessage : IQueueMessage
    {
        /// <summary>
        /// Расписание
        /// </summary>
        public int? JobScheduleId { get; set; }

        /// <summary>
        /// Джоб
        /// </summary>
        public long? JobId { get; set; }

        /// <summary>
        /// Субджоб
        /// </summary>
        public long? SubJobId { get; set; }

        /// <summary>
        /// Батч
        /// </summary>
        public long? BatchId { get; set; }

        /// <summary>
        /// Суббатч
        /// </summary>
        public long? SubBatchId { get; set; }

        /// <summary>
        /// Количество перезапусков пачки
        /// </summary>
        public int RestartCount { get; set; }
    }
}
