﻿using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System.Collections.Generic;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    public class ReporterToBrokerMessage : IQueueMessage
    {
        public long JobId { get; set; }
        public string Body { get; set; }
        public byte ExtensionType { get; set; }
        public string Subject { get; set; }
        public string Recepients { get; set; }
        public Dictionary<string, byte[]> Attachments { get; set; }
    }
}
