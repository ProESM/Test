﻿using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Contracts.Interfaces;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages
{
    /// <summary>
    /// Задание на расчет от брокера к калькулятору
    /// </summary>
    public class BrokerToCalculatorMessage : IQueueMessage
    {
        /// <summary>
        /// Идентификатор задания
        /// </summary>
        public long JobId { get; set; }

        /// <summary>
        /// Суббатч
        /// </summary>
        public long SubBatchId { get; set; }

        /// <summary>
        /// Субджоб
        /// </summary>
        public long? SubJobId { get; set; }

        /// <summary>
        /// Батч
        /// </summary>
        public long? BatchId { get; set; }

        /// <summary>
        /// Общее количество пачек
        /// </summary>
        public int AllCount { get; set; }

        /// <summary>
        /// Тип алгоритма
        /// </summary>
        public AlgType AlgType { get; set; }

        /// <summary>
        /// Магазин
        /// </summary>
        public int LocationId { get; set; }


        /// <summary>
        /// Количество перезапусков пачки
        /// </summary>
        public int RestartCount { get; set; }
    }
}
