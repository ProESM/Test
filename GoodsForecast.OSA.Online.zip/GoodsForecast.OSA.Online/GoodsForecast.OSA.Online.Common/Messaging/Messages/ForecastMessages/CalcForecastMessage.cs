﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages.ForecastMessages
{
    /// <summary>
    /// Сообщения о запуске расчета
    /// </summary>
    public class CalcForecastMessage: BrokerToBrokerMessage
    {
      
    }
}
