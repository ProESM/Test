﻿using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Data.Entities;
using System.Collections.Generic;

namespace GoodsForecast.OSA.Online.Common.Messaging.Messages.ReportsMessages
{
    public class DailySignalsReportMessage : IQueueMessage
    {
        /// <summary>
        /// Ид джоба
        /// </summary>
        public long JobId { get; set; }
    }
}
