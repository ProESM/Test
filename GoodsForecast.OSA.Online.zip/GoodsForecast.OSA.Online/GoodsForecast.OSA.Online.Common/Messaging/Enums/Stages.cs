﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Common.Messaging.Enums
{
    /// <summary>
    /// Этап расчета, с которого начинаем пересчет
    /// </summary>
    public enum Stages
    {
        PrepareParams,
        FillTasks,
        SplitTasks,
        CalcForecast,
        SendSignals
    }
}
