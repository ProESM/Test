﻿namespace GoodsForecast.OSA.Online.Common.Messaging.Enums
{
    public enum QueueName
    {
        BrokerToBroker,
        BrokerToCalculator,
        CalculatorToBroker,
        BrokerToReporter,
        ReporterToBroker,
        BrokerToMessenger
    }
}
