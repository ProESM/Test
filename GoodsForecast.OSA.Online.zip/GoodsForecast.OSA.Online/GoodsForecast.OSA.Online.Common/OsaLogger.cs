﻿using System;
using NLog;

namespace GoodsForecast.OSA.Online.Common
{
    /// <summary>
    /// Он нужен для того, чтобы пробросить в логи JobID.
    /// Логгер из Microsoft.Extensions.Logger не дает использовать WithProperty, только в NLog это можно сделать,
    /// поэтому надо его инстанцировать явно
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public sealed class OsaLogger<T> : OsaLogger
    {
        public OsaLogger()
        {
            Logger = LogManager.GetLogger(typeof(T).ToString());
        }
    }

    public abstract class OsaLogger
    {
        protected Logger Logger { get; set; }

        public void LogInformation(string machineName, string message, long? jobId = null)
        {
            Logger.WithProperty("jobId", jobId)
                  .WithProperty("machineName", machineName)
                  .Info(message);
        }

        public void LogDebug(string machineName, string message, long? jobId = null)
        {
            Logger.WithProperty("jobId", jobId)
                  .WithProperty("machineName", machineName)
                  .Debug(message);
        }

        public void LogTrace(string machineName, string message, long? jobId = null)
        {
            Logger.WithProperty("jobId", jobId)
                  .WithProperty("machineName", machineName)
                  .Trace(message);
        }

        public void LogError(string machineName, string message, Exception ex = null, long? jobId = null)
        {
            Logger.WithProperty("jobId", jobId)
                  .WithProperty("machineName", machineName)
                  .Error(ex, message);
        }
    }
}
