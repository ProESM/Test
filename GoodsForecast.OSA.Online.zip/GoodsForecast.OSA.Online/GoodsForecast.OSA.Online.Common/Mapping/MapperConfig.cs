﻿using System;
using AutoMapper;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Data.Entities;
using System.Linq;
using GoodsForecast.OSA.Online.Common.Reports;

namespace GoodsForecast.OSA.Online.Common.Mapping
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            CreateMap<LostSalesAnalysisJob, LostSalesAnalysisJobViewModel>()
                .ForMember(i => i.Tasks, j => j.MapFrom(c => c.LostSalesAnalysisTasks));
            CreateMap<LostSalesAnalysisTask, LostSalesAnalysisTaskViewModel>()
                .ForMember(i => i.CalcType, j => j.MapFrom(c => (Forecasting.CalcType)c.LostSalesAnalysisBatch.BatchTypeId))
                .ForMember(i => i.AlgType, j => j.MapFrom(c => (Forecasting.Tasks.AlgType)byte.Parse(
                    c.LostSalesAnalysisSubJob.LostSalesAnalysisSchema.LostSalesAnalisysSchemaParams.Where(x => x.Key == "AlgType").FirstOrDefault().Value
                    )
                ))
                .ForMember(i => i.OpenTime, j => j.MapFrom(c => c.Location.OpenTime ?? new TimeSpan()))
                .ForMember(i => i.CloseTime, j => j.MapFrom(c => c.Location.CloseTime ?? new TimeSpan()));
            CreateMap<LostSalesAnalysisTaskViewModel, Suspect>()
               .ForMember(i => i.StartDate, j => j.MapFrom(c => c.StartDateTime))
               .ForMember(i => i.EndDate, j => j.MapFrom(c => c.EndDateTime))
               .ForMember(i => i.Id, j => j.MapFrom(c => c.Id))
               .ForMember(i => i.Threshold, j => j.MapFrom(c => c.ThresholdLengthWorkingHours))
               .ForMember(i => i.Length,
                   j => j.MapFrom(c => c.LengthHours.HasValue ? Convert.ToInt32(c.LengthHours) : -1))
                   .ForMember(i => i.IsKvi, j => j.MapFrom(c => c.IsKvi))
                   .ForMember(i => i.PromoAlgType, j => j.MapFrom(c => c.PromoAlgType));
            CreateMap<ProductMatrix, AssortmentMatrixItemViewModel>();
            CreateMap<LocationStateHourSale, LocationStateHourSaleViewModel>()
                .ForMember(i => i.OpenTime, j => j.MapFrom(c => c.Location.OpenTime))
                .ForMember(i => i.CloseTime, j => j.MapFrom(c => c.Location.CloseTime));
            CreateMap<LocationStateStock, LocationStateStocksViewModel>();
            CreateMap<PromoPeriod, PromotionMatrixViewModel>()
                .ForMember(i => i.LocationId, opt => opt.MapFrom(c => c.LocationId))
                .ForMember(i => i.ProductId, opt => opt.MapFrom(c => c.ProductId))
                .ForMember(i => i.StartDate, opt => opt.MapFrom(c => c.DtBegin))
                .ForMember(i => i.EndDate, opt => opt.MapFrom(c => c.DtEnd)); ;

            CreateMap<ProductMatrix, Common.Forecasting.Tasks.RelatedStore>()
                .ForMember(i => i.OpenTime, j => j.MapFrom(c => c.Location.OpenTime))
                .ForMember(i => i.CloseTime, j => j.MapFrom(c => c.Location.CloseTime));

            CreateMap<ConsolidatedReport, FilteredConsolidatedReport>();
            CreateMap<SignalsFeedbackReport, FilteredSignalsFeedbackReport>();
        }
    }
}
