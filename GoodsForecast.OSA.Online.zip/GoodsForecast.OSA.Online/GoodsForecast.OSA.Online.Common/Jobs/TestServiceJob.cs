﻿using System;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Contracts.Interfaces;

namespace GoodsForecast.OSA.Online.Common.Jobs
{
    public class TestServiceJob : IServiceJob
    {
        private readonly OsaLogger<TestServiceJob> _logger;

        public TestServiceJob(OsaLogger<TestServiceJob> logger)
        {
            _logger = logger;
        }

        public async Task Execute()
        {
            _logger.LogInformation(Environment.MachineName, $"TestServiceJob начинает работу");
            try
            {

            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, "Ошибка в сервисе TestServiceJob", ex);
            }

            _logger.LogInformation(Environment.MachineName, $"TestServiceJob завершает работу");
            await Task.CompletedTask;
        }
    }
}
