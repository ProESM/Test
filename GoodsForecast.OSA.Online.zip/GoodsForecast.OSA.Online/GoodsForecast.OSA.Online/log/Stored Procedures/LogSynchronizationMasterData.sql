﻿CREATE PROC [log].[LogSynchronizationMasterData]
AS
BEGIN

 DECLARE @TargetDate DATE = DATEADD(DAY, -1, GETDATE())

DECLARE @LastMasterDataSyncId INT = 
(SELECT TOP(1) SyncId
 FROM dbo.SynchronizationDataLog (nolock)
 WHERE IsMasterDataSync = 1
 AND CAST(EndDate AS DATE) = @TargetDate)

 INSERT INTO log.MasterDataSynchronizationLog
 (
	SyncId,
	LocationInSalesCount,
	SaleRowsCount,
	SaleQuantity,
	SaleSum,
	SalesMinDate,
	SalesMaxDate,
	LocationInStocksCount,
	StockRowsCount,
	StockQuantity,
	StockSum,
	ProductMatrixRowsCount,
	LocationInProductMatrixCount,
	ProductInProductMatrixCount
 )
 SELECT TOP(1)
	@LastMasterDataSyncId,
	ouds.LocationCount,
	ouds.SalesRowCount,
	ouds.SaleQuantity,
	ouds.SaleSum,
	ouds.SalesMinDate,
	ouds.SalesMaxDate,
	st.LocationCount,
	st.StocksRowCount,
	st.StockQuantity,
	st.StockSum,
	oupm.MatrixRowCount,
	oupm.LocationInMatrixCount,
	oupm.ProductInMatrixCount
FROM (
	SELECT TOP(1)
		COUNT(DISTINCT st.LocationId) AS LocationCount,
		COUNT(*) AS StocksRowCount,
		SUM(st.Quantity) AS StockQuantity,
		SUM(st.Quantity * ds.PriceSum) AS StockSum
	FROM dbo.LocationStateStocks st (nolock)
	JOIN dbo.LocationStateDaySales ds (nolock)
		ON ds.ProductId = st.ProductId
	WHERE CAST(st.[Datetime] AS DATE) = @TargetDate
	AND ds.[Date] = @TargetDate
) AS st
OUTER APPLY(
	SELECT TOP(1)
		COUNT(DISTINCT ds.LocationId) AS LocationCount,
		COUNT(*) AS SalesRowCount,
		SUM(ds.Quantity) AS SaleQuantity,
		SUM(ds.PriceSum * ds.Quantity) AS SaleSum,
		MIN(ds.[Date]) AS SalesMinDate,
		MAX(ds.[Date]) AS SalesMaxDate
	FROM dbo.LocationStateDaySales ds (nolock)
	WHERE ds.[Date] = @TargetDate
) AS ouds
OUTER APPLY(
	SELECT TOP(1)
		COUNT(*) AS MatrixRowCount,
		COUNT(DISTINCT pm.LocationId) AS LocationInMatrixCount,
		COUNT(DISTINCT pm.ProductId) AS ProductInMatrixCount
	FROM dbo.ProductMatrix pm (nolock)
	WHERE pm.[Date] = @TargetDate
) AS oupm

SELECT Id 
INTO #Locations
FROM Locations 
WHERE IsActive = 1 
AND ShortName IS NOT NULL

INSERT INTO log.MasterDataSynchronizationLocationLog
(
	SyncId,
	LocationId,
	SaleRowsCount,
	SalesMinDate,
	SalesMaxDate,
	SaleQuantity,
	SaleSum,
	StockRowsCount,
	StockQuantity,
	StockSum,
	ProductMatrixRowsCount
)
SELECT
	@LastMasterDataSyncId,
	l.Id,
	ous.SalesRowCount,
	ous.SalesMinDate,
	ous.SalesMaxDate,
	ous.SaleQuantity,
	ous.SaleSum,
	oust.StocksRowCount,
	oust.StockQuantity,
	oust.StockSum,
	oupm.MatrixRowCount
FROM #Locations l
OUTER APPLY(
	SELECT 
		ds.LocationId,
		COUNT(*) AS SalesRowCount,
		MIN(ds.[Date]) AS SalesMinDate,
		MAX(ds.[Date]) AS SalesMaxDate,
		SUM(ds.Quantity) AS SaleQuantity,
		SUM(ds.Quantity * ds.PriceSum) AS SaleSum
	FROM dbo.LocationStateDaySales ds (nolock)
	WHERE ds.[Date] = @TargetDate
	AND ds.LocationId = l.Id
	GROUP BY ds.LocationId
) AS ous
OUTER APPLY(
	SELECT
		COUNT(*) AS StocksRowCount,
		SUM(ls.Quantity) AS StockQuantity,
		SUM(ls.Quantity * ds.PriceSum) AS StockSum
	FROM dbo.LocationStateStocks ls (nolock)
	JOIN dbo.LocationStateDaySales ds (nolock)
		ON ds.ProductId = ls.ProductId
	WHERE CAST(ls.[Datetime] AS DATE) = @TargetDate
	AND ds.[Date] = @TargetDate
	AND ls.LocationId = l.Id
	GROUP BY ls.LocationId
) AS oust
OUTER APPLY(
	SELECT
		COUNT(*) AS MatrixRowCount
	FROM dbo.ProductMatrix pm (nolock)
	WHERE pm.LocationId = l.Id
	AND pm.[Date] = @TargetDate
	GROUP BY pm.LocationId
) AS oupm

DROP TABLE #Locations
END