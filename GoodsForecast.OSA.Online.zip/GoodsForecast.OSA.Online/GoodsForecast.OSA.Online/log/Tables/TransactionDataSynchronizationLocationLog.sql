﻿CREATE TABLE [log].[TransactionDataSynchronizationLocationLog] (
    [SyncId]         INT      NOT NULL,
    [LocationId]     INT      NOT NULL,
    [SalesRowCount]  INT      NULL,
    [StocksRowCount] INT      NULL,
    [SalesMinDate]   DATETIME NULL,
    [SalesMaxDate]   DATETIME NULL,
    [StocksMinDate]  DATETIME NULL,
    [StocksMaxDate]  DATETIME NULL,
    CONSTRAINT [PK_TransactionDataSynchronizationLocationLog] PRIMARY KEY CLUSTERED ([SyncId] ASC, [LocationId] ASC) WITH (FILLFACTOR = 80)
);

