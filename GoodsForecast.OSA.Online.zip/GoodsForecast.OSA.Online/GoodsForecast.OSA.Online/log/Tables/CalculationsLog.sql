﻿CREATE TABLE [log].[CalculationsLog] (
    [JobId]         BIGINT   NOT NULL,
    [LocationCount] INT      NULL,
    [ProductCount]  INT      NULL,
    [SignalHour]    INT      NULL,
    [LastSyncId]    INT      NULL,
    [LastSyncDate]  DATETIME NULL,
    [SuspectCount]  INT      NULL,
    [SignalCount]   INT      NULL,
    CONSTRAINT [PK_CalculationsLog] PRIMARY KEY CLUSTERED ([JobId] ASC)
);

