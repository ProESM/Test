﻿CREATE TABLE [log].[TransactionDataSynchronizationLog] (
    [SyncId]              INT      NOT NULL,
    [StocksLocationCount] INT      NULL,
    [SalesLocationCount]  INT      NULL,
    [SalesMinDate]        DATETIME NULL,
    [SalesMaxDate]        DATETIME NULL,
    [StocksMinDate]       DATETIME NULL,
    [StocksMaxDate]       DATETIME NULL,
    CONSTRAINT [PK_TransactionDataSynchronizationLog] PRIMARY KEY CLUSTERED ([SyncId] ASC)
);

