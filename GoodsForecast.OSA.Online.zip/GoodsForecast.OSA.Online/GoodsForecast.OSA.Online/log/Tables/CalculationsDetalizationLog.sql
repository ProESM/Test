﻿CREATE TABLE [log].[CalculationsDetalizationLog] (
    [JobId]        BIGINT NOT NULL,
    [LocationId]   INT    NOT NULL,
    [SuspectCount] INT    NULL,
    [SignalCount]  INT    NULL,
    [LastSyncId]   INT    NULL,
    CONSTRAINT [PK_CalculationsDetalizationLog] PRIMARY KEY CLUSTERED ([JobId] ASC, [LocationId] ASC) WITH (FILLFACTOR = 80)
);

