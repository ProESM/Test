﻿CREATE TABLE [log].[MasterDataSynchronizationLocationLog] (
    [SyncId]                 INT          NOT NULL,
    [LocationId]             INT          NOT NULL,
    [SaleRowsCount]          INT          NULL,
    [SalesMinDate]           DATETIME     NULL,
    [SalesMaxDate]           DATETIME     NULL,
    [SaleQuantity]           INT          NULL,
    [SaleSum]                DECIMAL (18) NULL,
    [StockRowsCount]         INT          NULL,
    [StockQuantity]          INT          NULL,
    [StockSum]               DECIMAL (18) NULL,
    [ProductMatrixRowsCount] INT          NULL,
    CONSTRAINT [PK_MasterDataSynchronizationLocationLog] PRIMARY KEY CLUSTERED ([SyncId] ASC, [LocationId] ASC) WITH (FILLFACTOR = 80)
);

