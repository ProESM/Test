﻿CREATE TABLE [log].[MasterDataSynchronizationLog] (
    [SyncId]                       INT          NOT NULL,
    [LocationInSalesCount]         INT          NULL,
    [SaleRowsCount]                INT          NULL,
    [SaleQuantity]                 BIGINT       NULL,
    [SaleSum]                      DECIMAL (18) NULL,
    [SalesMinDate]                 DATETIME     NULL,
    [SalesMaxDate]                 DATETIME     NULL,
    [LocationInStocksCount]        INT          NULL,
    [StockRowsCount]               INT          NULL,
    [StockQuantity]                BIGINT       NULL,
    [StockSum]                     DECIMAL (18) NULL,
    [ProductMatrixRowsCount]       INT          NULL,
    [LocationInProductMatrixCount] INT          NULL,
    [ProductInProductMatrixCount]  INT          NULL,
    CONSTRAINT [PK_MasterDataSynchronizationLog] PRIMARY KEY CLUSTERED ([SyncId] ASC)
);

