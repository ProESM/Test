﻿CREATE TABLE [history].[TruncatedSuspectPeriods] (
    [JobId]                 BIGINT        NOT NULL,
    [LocationId]            INT           NOT NULL,
    [ProductId]             INT           NOT NULL,
    [DtBegin]               SMALLDATETIME NOT NULL,
    [DtEnd]                 SMALLDATETIME NOT NULL,
    [MaxValidationDateTime] DATETIME      NULL,
    [Price]                 FLOAT (53)    NULL,
    [PromoAlgType]          TINYINT       NULL,
    [isHoliday]             BIT           NULL,
    [isKVI]                 BIT           NULL,
    [isPromo]               BIT           NULL,
    [AbcCategory]           VARCHAR (1)   NULL,
    [SumSales]              REAL          NULL,
    [TheshHold]             SMALLINT      NULL,
    [PriceIncreased]        BIT           DEFAULT ((0)) NULL
);

