﻿CREATE TABLE [history].[DuplicateLocationStateStocks] (
    [LocationId]    INT  NOT NULL,
    [ProductId]     INT  NOT NULL,
    [Date]          DATE NULL,
    [DatetimeCount] INT  NULL
);

