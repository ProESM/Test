﻿CREATE TABLE [history].[DuplicateWithMaxDatetimeLocationStateStocks] (
    [LocationId]  INT      NOT NULL,
    [ProductId]   INT      NOT NULL,
    [Date]        DATE     NULL,
    [MaxDatetime] DATETIME NULL
);

