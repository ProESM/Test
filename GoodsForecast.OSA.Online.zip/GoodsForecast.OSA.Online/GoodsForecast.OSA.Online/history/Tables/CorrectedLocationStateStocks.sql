﻿CREATE TABLE [history].[CorrectedLocationStateStocks] (
    [LocationId] INT      NOT NULL,
    [ProductId]  INT      NOT NULL,
    [Date]       DATE     NULL,
    [Datetime]   DATETIME NOT NULL,
    [Quantity]   REAL     NOT NULL
);

