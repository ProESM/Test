﻿CREATE TABLE [etl].[Sales] (
    [StoreId]      NVARCHAR (32) NOT NULL,
    [ProductId]    NVARCHAR (32) NOT NULL,
    [ChequeId]     NVARCHAR (32) NOT NULL,
    [Datetime]     DATETIME      NOT NULL,
    [Quantity]     REAL          NOT NULL,
    [PriceSum]     REAL          NOT NULL,
    [Created]      DATETIME      NULL,
    [IsMasterSync] BIT           DEFAULT ((0)) NOT NULL
);

