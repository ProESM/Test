﻿CREATE TABLE [etl].[StoreFormats] (
    [StoreFormatId] NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_StoreFormats] PRIMARY KEY CLUSTERED ([StoreFormatId] ASC)
);

