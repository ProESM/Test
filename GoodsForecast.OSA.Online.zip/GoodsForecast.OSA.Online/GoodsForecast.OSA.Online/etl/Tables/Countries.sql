﻿CREATE TABLE [etl].[Countries] (
    [CountryId] NVARCHAR (32)  NOT NULL,
    [Name]      NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_Countries] PRIMARY KEY CLUSTERED ([CountryId] ASC)
);

