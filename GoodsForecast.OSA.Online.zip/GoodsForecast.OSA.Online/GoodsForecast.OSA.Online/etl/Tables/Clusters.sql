﻿CREATE TABLE [etl].[Clusters] (
    [ClusterId] NVARCHAR (32)  NOT NULL,
    [Name]      NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_Clusters] PRIMARY KEY CLUSTERED ([ClusterId] ASC)
);

