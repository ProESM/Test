﻿CREATE TABLE [etl].[Promotions] (
    [StoreId]                     NVARCHAR (32)  NOT NULL,
    [ProductId]                   NVARCHAR (32)  NOT NULL,
    [PromoId]                     NVARCHAR (32)  NOT NULL,
    [Name]                        NVARCHAR (256) NOT NULL,
    [PromoTypeId]                 NVARCHAR (32)  NOT NULL,
    [StartDate]                   DATE           NOT NULL,
    [EndDate]                     DATE           NOT NULL,
    [AdditionalPlacementQuantity] INT            NOT NULL,
    CONSTRAINT [PK_Promotions] PRIMARY KEY CLUSTERED ([StoreId] ASC, [ProductId] ASC, [PromoId] ASC, [StartDate] ASC, [EndDate] ASC) WITH (FILLFACTOR = 80)
);

