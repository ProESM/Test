﻿CREATE TABLE [etl].[ProductMatrix] (
    [StoreId]   NVARCHAR (32) NOT NULL,
    [ProductId] NVARCHAR (32) NOT NULL,
    [Date]      DATE          NOT NULL,
    [Price]     REAL          NOT NULL,
    CONSTRAINT [PK_ProductMatrix] PRIMARY KEY CLUSTERED ([StoreId] ASC, [ProductId] ASC, [Date] ASC) WITH (FILLFACTOR = 80)
);

