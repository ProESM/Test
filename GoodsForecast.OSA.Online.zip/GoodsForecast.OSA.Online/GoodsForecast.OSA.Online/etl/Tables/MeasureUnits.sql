﻿CREATE TABLE [etl].[MeasureUnits] (
    [MeasureUnitId] NVARCHAR (32)  NOT NULL,
    [Name]          NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_MeasureUnits] PRIMARY KEY CLUSTERED ([MeasureUnitId] ASC)
);

