﻿CREATE TABLE [etl].[Regions] (
    [RegionId] NVARCHAR (32)  NOT NULL,
    [ParentId] NVARCHAR (32)  NULL,
    [Name]     NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_Regions] PRIMARY KEY CLUSTERED ([RegionId] ASC)
);

