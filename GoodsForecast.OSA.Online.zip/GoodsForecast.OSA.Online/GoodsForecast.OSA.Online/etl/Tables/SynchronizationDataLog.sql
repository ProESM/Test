﻿CREATE TABLE [etl].[SynchronizationDataLog] (
    [SyncId]           INT      NOT NULL,
    [StartNewDataSeek] DATETIME NULL,
    [EndNewDataSeek]   DATETIME NULL
);

