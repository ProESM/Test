﻿CREATE PROCEDURE [dbo].[MergeProductsSync_ONCE]
AS

	MERGE dbo.Products AS trg
	USING
	(
		SELECT p.ProductId AS ExternalId,
			   p.Name AS Name,
			   pg.Id AS ProductGroupId,
			   CAST(1 AS BIT) AS IsActive,
			   p.Barcode AS Barcode,
			   c.Id AS CountryId,
			   b.Id AS BrandId,
			   pt.Id AS ProductTypeId,
			   prd.Id AS ProducerId,
			   mu.Id AS MeasureUnitId
		FROM [OSA-DEV-01].[GFC.Projects.OSA.Online.Okey.Stg].dbo.Products AS p
			INNER JOIN dbo.ProductGroups AS pg
				ON pg.ExternalId = p.ProductGroupId
			LEFT JOIN dbo.Countries AS c
				ON c.ExternalId = p.CountryId
			LEFT JOIN dbo.Brands AS b
				ON b.ExternalId = p.BrandId
			LEFT JOIN dbo.ProductTypes AS pt
				ON pt.ExternalId = p.ProductTypeId
			LEFT JOIN dbo.Locations AS prd
				ON prd.ExternalId = p.ProducerId
				   AND prd.TypeKey = N'Producer'
			LEFT JOIN dbo.MeasureUnits AS mu
				ON mu.ExternalId = p.MeasureUnitId
	) AS source
	ON trg.ExternalId = source.ExternalId
	WHEN MATCHED THEN
		UPDATE SET trg.ExternalId = source.ExternalId,
				   trg.Name = source.Name,
				   trg.ProductGroupId = source.ProductGroupId,
				   trg.IsActive = source.IsActive,
				   trg.Barcode = source.Barcode,
				   trg.CountryId = source.CountryId,
				   trg.BrandId = source.BrandId,
				   trg.ProductTypeId = source.ProductTypeId,
				   trg.ProducerId = source.ProducerId,
				   trg.MeasureUnitId = source.MeasureUnitId
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
		(
			ExternalId,
			Name,
			ProductGroupId,
			IsActive,
			Barcode,
			CountryId,
			BrandId,
			ProductTypeId,
			ProducerId,
			MeasureUnitId
		)
		VALUES
		(source.ExternalId, source.Name, source.ProductGroupId, source.IsActive, source.Barcode, source.CountryId,
		 source.BrandId, source.ProductTypeId, source.ProducerId, source.MeasureUnitId);



	DECLARE @GroupTable TABLE
	(
		HId HIERARCHYID NOT NULL PRIMARY KEY,
		Id INT NOT NULL
	);

	INSERT INTO @GroupTable
	(
		HId,
		Id
	)
	SELECT pg.HId,
		   pg.Id
	FROM dbo.ProductGroups AS pg;

	MERGE dbo.ProductAncestorGroups AS target
	USING
	(
		SELECT p.Id AS ProductId,
			   ans.AncestorProductGroupId AS ProductGroupId,
			   ans.AncestorProductGroupLevel AS GroupLevel
		FROM Products AS p
			INNER JOIN ProductGroupAncestorGroups AS ans
				ON ans.ProductGroupId = p.ProductGroupId
	) AS source
	ON (
		   target.ProductId = source.ProductId
		   AND target.ProductGroupId = source.ProductGroupId
	   )
	WHEN NOT MATCHED THEN
		INSERT
		(
			ProductId,
			ProductGroupId,
			GroupLevel
		)
		VALUES
		(source.ProductId, source.ProductGroupId, source.GroupLevel)
	WHEN NOT MATCHED BY SOURCE THEN
		DELETE;
