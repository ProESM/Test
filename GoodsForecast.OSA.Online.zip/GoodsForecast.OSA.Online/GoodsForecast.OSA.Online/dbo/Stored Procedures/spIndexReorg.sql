﻿
--==================================
-- Rebuild and reorganize indices
--==================================
CREATE PROCEDURE [dbo].[spIndexReorg]
AS
BEGIN
	DECLARE @tablename [varchar](255)
	DECLARE @sql [nvarchar](500)
	DECLARE @fillfactor [int] = 80
	DECLARE @low@fraglevel [int] = 5
	DECLARE @fraglevel [int] = 30

	DECLARE @ErrorMessage nvarchar(max) = '';
	DECLARE @Message nvarchar(max) = '';

	CREATE TABLE #RelatedStores
    (
        LocationId INT,
        ProductId INT,
        StartDateTime DATETIME,
        EndDateTime DATETIME,
        PRIMARY KEY (LocationId, ProductId)
    )

    --rebuild more then 30% fragmentation indexes
	DECLARE tablecursor CURSOR FOR
		SELECT DISTINCT
			   OBJECT_SCHEMA_NAME(indexstats.[object_id])+'.'+OBJECT_NAME(ind.[object_id]) AS tablename
		FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) AS indexstats 
			INNER JOIN sys.indexes AS ind
				ON ind.[object_id] = indexstats.[object_id]
				AND ind.[index_id] = indexstats.[index_id]
		WHERE indexstats.[avg_fragmentation_in_percent] > @fraglevel
			AND ind.[name] IS NOT NULL

	BEGIN TRY	
		OPEN tablecursor
		FETCH NEXT FROM tablecursor INTO @tablename
		WHILE @@fetch_status = 0
		BEGIN
			SET @sql = 'ALTER INDEX ALL ON ' + @tablename + ' REBUILD WITH (FILLFACTOR = ' + CONVERT(VARCHAR(3), @fillfactor) + ')'
			
			EXEC (@sql)
			FETCH NEXT FROM tablecursor INTO @tablename
		END
		CLOSE tablecursor
		DEALLOCATE tablecursor
	END TRY
	BEGIN CATCH
		SET @ErrorMessage = ERROR_MESSAGE();
		PRINT @ErrorMessage
		
		CLOSE tablecursor
		DEALLOCATE tablecursor
		
		RETURN;
	END CATCH

	--reorganize less then 30% fragmentation indexes
	DECLARE tablecursor CURSOR FOR
		SELECT DISTINCT
			   OBJECT_SCHEMA_NAME(indexstats.[object_id]) + '.' + OBJECT_NAME(ind.[object_id]) AS tablename
		FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) AS indexstats 
			INNER JOIN sys.indexes AS ind
				ON ind.[object_id] = indexstats.[object_id]
				AND ind.[index_id] = indexstats.[index_id] 
		WHERE indexstats.[avg_fragmentation_in_percent] BETWEEN @low@fraglevel AND @fraglevel
			AND ind.[Name] IS NOT NULL
	
	BEGIN TRY
		OPEN tablecursor
		FETCH NEXT FROM tablecursor INTO @tablename
		WHILE @@fetch_status = 0
		BEGIN
			SET @sql = 'ALTER INDEX ALL ON ' + @tablename + ' REORGANIZE'
			EXEC (@sql)
			FETCH NEXT FROM tablecursor INTO @tablename
		END
		CLOSE tablecursor
		DEALLOCATE tablecursor
	END TRY
	BEGIN CATCH
		SET @ErrorMessage = ERROR_MESSAGE();
		PRINT @ErrorMessage
		
		CLOSE tablecursor
		DEALLOCATE tablecursor
		
		RETURN;
	END CATCH
END
