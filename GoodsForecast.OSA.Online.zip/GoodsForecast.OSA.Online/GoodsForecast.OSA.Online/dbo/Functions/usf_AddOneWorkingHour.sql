﻿

CREATE FUNCTION [dbo].[usf_AddOneWorkingHour] 
(
 @Date SMALLDATETIME,
 @HourStart INT,
 @HourEnd INT
)
RETURNS SMALLDATETIME
AS
BEGIN
 
 SET @HourEnd = IIF(@HourEnd = 0, 24, @HourEnd);

 IF DATEPART(HOUR, @Date) + 1 = @HourEnd
 BEGIN
  RETURN DATEADD(HOUR, @HourStart - @HourEnd + 1, DATEADD(day, 1, @Date))
 END

 RETURN DATEADD(HOUR, 1, @Date) 

END
