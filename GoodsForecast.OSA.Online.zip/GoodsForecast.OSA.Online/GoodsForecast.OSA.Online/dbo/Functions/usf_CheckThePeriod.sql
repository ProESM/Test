﻿CREATE FUNCTION [dbo].[usf_CheckThePeriod] 
(
	@periodLength INT,
	@isPromo INT,
	@isKVI INT,
	@defaultThreshHold INT,
	@promoThreshHold INT,
	@kviTreshHold INT
)
RETURNS INT
AS
BEGIN

	IF @periodLength >= dbo.[usf_GetTheBorder](@isPromo, @isKVI, @defaultThreshHold, @promoThreshHold, @kviTreshHold) 
		RETURN 1

	RETURN 0	

END
