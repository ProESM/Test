﻿




CREATE FUNCTION [dbo].[usf_WorkingHoursDiff] 
(
 @DateStart SMALLDATETIME,
 @DateEnd SMALLDATETIME,
 @HourStart TINYINT,
 @HourEnd TINYINT
)
RETURNS SMALLINT
AS
BEGIN

 SET @HourEnd = IIF(@HourEnd = 0, 24, @HourEnd);
 DECLARE @DateStartHour TINYINT = IIF(DATEPART(HOUR, @DateStart) = 0, 24, DATEPART(HOUR, @DateStart));
 DECLARE @DateEndHour TINYINT = IIF(DATEPART(HOUR, @DateEnd) = 0, 24, DATEPART(HOUR, @DateEnd));
 
 RETURN DATEDIFF(day, @DateStart, @DateEnd)*(@HourEnd-@HourStart) - (@HourEnd-@HourStart) 
  + @DateEndHour - @HourStart
  + @HourEnd - DATEPART(HOUR, @DateStart)

END
