﻿CREATE FUNCTION [dbo].[usf_GetTheBorder] 
(
	@isPromo INT,
	@isKVI INT,
	@defaultThreshHold INT,
	@promoThreshHold INT,
	@kviTreshHold INT
)
RETURNS INT
AS
BEGIN

	IF @isPromo = 1 
		RETURN @promoThreshHold
	
	IF @isKVI = 1 
	BEGIN
		IF @kviTreshHold <=  @defaultThreshHold
			RETURN @kviTreshHold
	END
	
	RETURN @defaultThreshHold;			
	
END
