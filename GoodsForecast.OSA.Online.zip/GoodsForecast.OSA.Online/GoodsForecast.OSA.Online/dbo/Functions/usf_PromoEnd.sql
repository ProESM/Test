﻿

CREATE FUNCTION [dbo].[usf_PromoEnd]
(
	@StartDate AS DATE,
	@EndDate AS DATE,
	@CheckDateTime AS DATETIME,
    @PromoDuration INT,
    @PromoSubstruct INT
)
RETURNS DATE
AS
BEGIN

	IF DATEDIFF(DAY, @StartDate, @EndDate) + 1 < @PromoDuration
		RETURN @EndDate;

	IF (@CheckDateTime < @StartDate) OR (@CheckDateTime > DATEADD(DAY,1,@EndDate))
		RETURN @EndDate;

	RETURN @EndDate

END
