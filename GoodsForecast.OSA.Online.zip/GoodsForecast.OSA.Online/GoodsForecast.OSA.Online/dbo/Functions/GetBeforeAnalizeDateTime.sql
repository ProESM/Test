﻿--==========================================
-- Получить предыдущую дату анализа
--==========================================
CREATE FUNCTION [dbo].[GetBeforeAnalizeDateTime]
(
	@jobId INT,
    @AnalizeDateTime DATETIME
)
RETURNS DATETIME
AS
BEGIN

	DECLARE @JobTypeId INT, @TimezoneId INT
    SELECT @JobTypeId = JobTypeId, @TimezoneId = TimezoneId 
    FROM mng.Jobs j
    INNER JOIN mng.JobSchedules js
        ON js.Id = j.JobScheduleId
    INNER JOIN mng.JobTypes jt
        ON jt.Id = js.JobTypeId
    WHERE j.Id = @jobId

    DECLARE @BeforeAnalizeDatetime DATETIME 

    SELECT TOP 1 @BeforeAnalizeDatetime = AnalizeDatetime 
    FROM dbo.LostSalesAnalysisJobs lj
    JOIN mng.Jobs j
    ON j.Id = lj.JobId
    INNER JOIN mng.JobSchedules js
        ON js.Id = j.JobScheduleId
    INNER JOIN mng.JobTypes jt
        ON jt.Id = js.JobTypeId
    WHERE jt.Id = @JobTypeId
        AND TimezoneId = @TimezoneId
        AND j.Id != @jobId
    ORDER BY AnalizeDatetime DESC

    IF @BeforeAnalizeDatetime IS NULL
    BEGIN
        RETURN 
        (
            SELECT 
                CASE 
                    WHEN DATEPART(HOUR, @AnalizeDateTime) = 11
                        THEN DATEADD(HOUR, 23, DATEADD(DAY, -1, CAST(@AnalizeDateTime AS DATE)))
                    WHEN DATEPART(HOUR, @AnalizeDateTime) = 14
                        THEN DATEADD(HOUR, 11, CAST(CAST(@AnalizeDateTime AS DATE) AS DATETIME) )
                    WHEN DATEPART(HOUR, @AnalizeDateTime) = 17
                        THEN DATEADD(HOUR, 14, CAST(CAST(@AnalizeDateTime AS DATE) AS DATETIME))
                    WHEN DATEPART(HOUR, @AnalizeDateTime) = 21
                        THEN DATEADD(HOUR, 17, CAST(CAST(@AnalizeDateTime AS DATE) AS DATETIME))
                END
        )

    END

    RETURN @BeforeAnalizeDatetime

END
