﻿CREATE FUNCTION [dbo].[GetAnalizeDate] 
(
    @JobId BIGINT
)
RETURNS SMALLDATETIME
AS
BEGIN
    DECLARE @SyncDate SMALLDATETIME =
     (
         SELECT CASE 
         WHEN 
              (
                SELECT [Value]
                FROM svc.AnalysisParams
                WHERE [Name] = 'IsToday'
              ) = 0 
          THEN 
              (
                SELECT [Value]
                FROM svc.AnalysisParams
                WHERE [Name] = 'LastSyncDate'
              )
          ELSE CAST(GETDATE() AS DATE)
        END
     );

    DECLARE @AnalizeDate SMALLDATETIME = 
    (
      SELECT DATEADD(HOUR, ISNULL(aj.SignalHour, 22) - 1, @SyncDate)
      FROM [dbo].[ActiveJobs] AS aj
      WHERE Id = @JobId
    );

    RETURN @AnalizeDate
END
