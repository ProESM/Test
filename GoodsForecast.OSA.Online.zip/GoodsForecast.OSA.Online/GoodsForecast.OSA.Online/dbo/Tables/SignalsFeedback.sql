﻿CREATE TABLE [dbo].[SignalsFeedback] (
    [SignalDatetime]        DATETIME       NULL,
    [SignalId]              FLOAT (53)     NULL,
    [LocationId]            FLOAT (53)     NULL,
    [ProductId]             FLOAT (53)     NULL,
    [IsCorrect]             NVARCHAR (255) NULL,
    [ValidationDateTime]    DATETIME       NULL,
    [ValidationDescription] NVARCHAR (255) NULL,
    [HasPhoto]              FLOAT (53)     NULL
);

