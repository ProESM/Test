﻿CREATE TABLE [dbo].[TempLocationStateChequesDATA] (
    [LocationId] INT      NOT NULL,
    [ProductId]  INT      NOT NULL,
    [ChequeId]   BIGINT   NOT NULL,
    [Datetime]   DATETIME NOT NULL,
    [Quantity]   REAL     NOT NULL,
    [PriceSum]   REAL     NOT NULL
);

