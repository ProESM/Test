﻿CREATE TABLE [dbo].[ListIMPORT] (
    [Регион]              NVARCHAR (255) NULL,
    [Город]               NVARCHAR (255) NULL,
    [Группа магазинов/ОД] NVARCHAR (255) NULL,
    [Сайт]                NVARCHAR (255) NULL,
    [Название]            NVARCHAR (255) NULL,
    [Директор]            NVARCHAR (255) NULL,
    [ЗДРП]                NVARCHAR (255) NULL,
    [ЗП]                  NVARCHAR (255) NULL,
    [РО DRY]              NVARCHAR (255) NULL,
    [РО NF]               NVARCHAR (255) NULL,
    [РО UF]               NVARCHAR (255) NULL
);

