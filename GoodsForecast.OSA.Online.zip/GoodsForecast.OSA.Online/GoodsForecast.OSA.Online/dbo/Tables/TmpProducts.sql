﻿CREATE TABLE [dbo].[TmpProducts] (
    [Id]             INT            NULL,
    [ExternalId]     NVARCHAR (32)  NOT NULL,
    [Name]           NVARCHAR (256) NOT NULL,
    [ProductGroupId] INT            NOT NULL,
    [IsActive]       BIT            NOT NULL,
    [Barcode]        NVARCHAR (80)  NULL,
    [CountryId]      INT            NULL,
    [BrandId]        INT            NULL,
    [ProductTypeId]  INT            NOT NULL,
    [ProducerId]     INT            NULL,
    [MeasureUnitId]  INT            NOT NULL
);

