﻿CREATE TABLE [dbo].[DuplicateLocationStateCheques] (
    [Datetime]    DATETIME NOT NULL,
    [LocationId]  INT      NOT NULL,
    [ProductId]   INT      NOT NULL,
    [ChequeId]    BIGINT   NOT NULL,
    [Quantity]    REAL     NULL,
    [PriceSum]    REAL     NULL,
    [RecordCount] INT      NULL
);

