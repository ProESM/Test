﻿CREATE TABLE [dbo].[ShopsIMPORT] (
    [Сайт]     NVARCHAR (255) NULL,
    [Название] NVARCHAR (255) NULL,
    [Директор] NVARCHAR (255) NULL,
    [ЗДРП]     NVARCHAR (255) NULL,
    [ЗП]       NVARCHAR (255) NULL,
    [РО DRY]   NVARCHAR (255) NULL,
    [РО NF]    NVARCHAR (255) NULL,
    [РО UF]    NVARCHAR (255) NULL
);

