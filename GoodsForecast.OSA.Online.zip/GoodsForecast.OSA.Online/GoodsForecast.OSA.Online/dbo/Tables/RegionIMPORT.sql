﻿CREATE TABLE [dbo].[RegionIMPORT] (
    [Регион]   NVARCHAR (255) NULL,
    [Почта]    NVARCHAR (255) NULL,
    [Сайт]     NVARCHAR (255) NULL,
    [Название] NVARCHAR (255) NULL
);

