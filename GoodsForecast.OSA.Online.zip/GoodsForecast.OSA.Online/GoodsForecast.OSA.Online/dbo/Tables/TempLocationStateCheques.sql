﻿CREATE TABLE [dbo].[TempLocationStateCheques] (
    [LocationId] INT      NOT NULL,
    [ProductId]  INT      NOT NULL,
    [ChequeId]   BIGINT   NOT NULL,
    [Datetime]   DATETIME NOT NULL
);

