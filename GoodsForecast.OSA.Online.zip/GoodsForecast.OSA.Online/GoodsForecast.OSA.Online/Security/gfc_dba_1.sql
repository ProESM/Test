﻿CREATE LOGIN [gfc_dba]
    WITH PASSWORD = N'tt%uk?az{awolkaziuqak8q{msFT7_&#$!~<rw,Ajd@q4fwa', SID = 0x08B2EAD4B9C1AA43BECA25D2C3C22EE9, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

