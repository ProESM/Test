﻿CREATE LOGIN [gfc_osa_online]
    WITH PASSWORD = N'tt<ue7;ka1zu{awlkaziuLq9msFT7_&#$!~<AaBkq3{r.w0d', SID = 0xED986CFD3702E140A44E73A34F9F8AC0, DEFAULT_LANGUAGE = [us_english], CHECK_POLICY = OFF;

