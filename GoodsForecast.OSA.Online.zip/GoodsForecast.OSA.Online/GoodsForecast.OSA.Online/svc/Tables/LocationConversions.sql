﻿CREATE TABLE [svc].[LocationConversions] (
    [LocationId]     INT  NOT NULL,
    [Conversion]     REAL NOT NULL,
    [KoefConversion] REAL NOT NULL,
    PRIMARY KEY CLUSTERED ([LocationId] ASC)
);

