﻿CREATE TABLE [svc].[LostSalesAnalisysSchemaParams] (
    [Id]          INT            NOT NULL,
    [SchemaId]    TINYINT        NOT NULL,
    [Key]         NVARCHAR (256) NOT NULL,
    [Description] NVARCHAR (MAX) NULL,
    [Value]       NVARCHAR (MAX) NOT NULL
);

