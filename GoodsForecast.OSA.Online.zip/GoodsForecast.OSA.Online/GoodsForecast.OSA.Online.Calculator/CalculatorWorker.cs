using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator
{
    public class CalculatorWorker : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly OsaLogger<CalculatorWorker> _logger;
        private readonly IEnumerable<IQueueMessageHandler> _handlers;

        public CalculatorWorker(
            IServiceProvider services,
            OsaLogger<CalculatorWorker> logger,
            IEnumerable<IQueueMessageHandler> handlers)
        {
            _services = services;
            _logger = logger;
            _handlers = handlers;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Calculator запущен");

            try
            {
                using var scope = _services.CreateScope();
                foreach (var handler in _handlers)
                {
                    await handler.Register();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, "Ошибка в CalculatorWorker", ex);
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Calculator завершает работу");
            await Task.CompletedTask;
        }
    }
}
