﻿using AutoMapper;
using GoodsForecast.OSA.Online.Common.Forecasting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Extensions
{
    /// <summary>
    /// Формирование батчей по задачам
    /// </summary>
    public static class LostSalesAnalysisTaskExtension
    {
        public static Dictionary<(int LocationId, int ProductId), IEnumerable<Suspect>> ToSuspectBatch(this IEnumerable<LostSalesAnalysisTaskViewModel> tasks, IMapper _mapper)
        {
            var suspects = tasks.GroupBy(t => (t.LocationId, t.ProductId))
                            .ToDictionary(l => l.Key,
                              s =>s.Select(c => _mapper.Map<Suspect>(c)));

            return suspects;
        }
    }
}
