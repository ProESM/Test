﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Forecsys.TSA.Core;
using ISeries = GoodsForecast.OSA.Online.Common.Forecasting.Series.ISeries;

namespace GoodsForecast.OSA.Online.Calculator.Extensions
{
    /// <summary>
    /// Преобразование временных рядов для TSA
    /// </summary>
    public static class SeriesExtensions
    {
        public static TimeSeries ToTimeSeries(this ISeries target)
        {
            var result = new TimeSeries
            {
                TimeStep = target.Step,
                BeginDate = target.StartDate
            };

            result.SetArray(0, target.Values.Select(value => (double)value).ToList());

            return result;
        }
        public static TimeSeries ToTimeSeries(this ISeries target, PointUnit unit = PointUnit.Day)
        {
            var result = new TimeSeries(unit)
            {
                TimeStep = target.Step,
                BeginDate = target.StartDate
            };

            result.SetArray(0, target.Values.Select(value => (double)value).ToList());

            return result;
        }

        public static Forecsys.TSA.Core.Marking ToMarking(this Common.Forecasting.Series.ISeries<long> target)
        {
            var marking = new Forecsys.TSA.Core.Marking() { BeginDate = target.StartDate, TimeStep = target.Step };

            marking.SetArray(0, target.Values.ToList());

            return marking;
        }
    }
}
