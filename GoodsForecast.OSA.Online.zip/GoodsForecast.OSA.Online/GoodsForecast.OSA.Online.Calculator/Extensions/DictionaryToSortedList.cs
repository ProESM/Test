﻿using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GoodsForecast.OSA.Online.Calculator.Extensions
{
    /// <summary>
    /// Преобразование результатов расчета по промо к результатам расчета в TSA
    /// </summary>
    public static class DictionaryToSortedList
    {
        public static SortedList<DateTime, SuspectResult> ToSortedList(this Dictionary<DateTime, float> source)
        {
            var list = new SortedList<DateTime, SuspectResult>();

            source.ToList().ForEach(i => list.Add(i.Key, new SuspectResult() { LossNumber = i.Value, Profile = 0 }));

            return list;
        }
    }
}
