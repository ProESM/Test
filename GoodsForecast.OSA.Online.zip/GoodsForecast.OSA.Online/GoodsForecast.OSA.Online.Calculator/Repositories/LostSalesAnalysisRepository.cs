﻿using AutoMapper;
using Forecsys.TSA.Core;
using GoodsForecast.OSA.Online.Calculator.Extensions;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks.Promo;
using GoodsForecast.OSA.Online.Data;
using GoodsForecast.OSA.Online.Data.Entities;
using LinqKit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.SqlServer;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Repositories
{
    /// <summary>
    /// Получение данных для расчета
    /// </summary>
    public class LostSalesAnalysisRepository : ILostSalesAnalysisRepository
    {
        private readonly OsaLogger<LostSalesAnalysisRepository> _logger;
        private readonly IServiceScopeFactory _serviceScopeFactory;
        private readonly IMapper _mapper;

        public LostSalesAnalysisRepository(OsaLogger<LostSalesAnalysisRepository> logger,
                             IServiceScopeFactory serviceScopeFactory,
                             IMapper mapper)
        {
            _logger = logger;
            _serviceScopeFactory = serviceScopeFactory;
            _mapper = mapper;
        }

        /// <summary>
        /// Получить джоб с заданиями на расчет
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<LostSalesAnalysisJobViewModel> GetLostSalesAnalysisJobs(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    return await _mapper.ProjectTo<LostSalesAnalysisJobViewModel>(
                                        context.LostSalesAnalysisJobs
                                        .Where(i => i.JobId == jobId)
                                )
                                .FirstOrDefaultAsync();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetLostSalesAnalysisJobs)}. Ошибка при получения джоба с заданиями на расчет", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Получение матрицы для формирования заданий на расчет
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<AssortmentMatrixItemViewModel>> GetAssortmentMatrix(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var query = context.ProductMatrix.AsQueryable();

                    query = query.Where(t => locationId == t.LocationId);
                    query = query.Where(t => productsIds.Contains(t.ProductId));

                    if (startDate.HasValue)
                        query = query.Where(t => t.Date >= startDate.Value.Date);

                    if (endDate.HasValue)
                        query = query.Where(t => t.Date <= endDate.Value.Date);

                    var result = await _mapper.ProjectTo<AssortmentMatrixItemViewModel>(query).ToListAsync();

                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetAssortmentMatrix)}. Ошибка при получении матрицы для формирования заданий на расчет", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение матрицы для формирования заданий на расчет по связанным магазинам из того же кластера
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<List<Common.Forecasting.Tasks.RelatedStore>> GetRelatedStoreProducts(int locationId, Dictionary<(int ProductId, DateTime StartDate), DatePeriod> products, DateTime historyEndDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var productIds = products.Keys.Select(x => x.ProductId)
                        .ToList();

                    var storeGroupId = context.StoresStoreGroups.Where(x => x.LocationId == locationId).Select(x => x.StoreGroupId).FirstOrDefault();
                    var stores = context.StoresStoreGroups.Where(x => x.StoreGroupId == storeGroupId && x.LocationId != locationId).Select(x => x.LocationId).ToList();
                    var query = await context.ProductMatrix
                                .Include(pm => pm.Location)
                                .Where(t => stores.Contains(t.LocationId) 
                                            && productIds.Contains(t.ProductId)
                                            && t.Date == historyEndDate
                                        )
                                .ToListAsync();

                    var result = from p in products
                               join pm in query on p.Key.Item1 equals pm.ProductId
                               select new Common.Forecasting.Tasks.RelatedStore
                               {
                                   LocationId = pm.LocationId,
                                   ProductId = pm.ProductId,
                                   StartDateTime = p.Value.StartDate,
                                   EndDateTime = p.Value.EndDate,
                                   OpenTime = pm.Location.OpenTime ?? new TimeSpan(),
                                   CloseTime = pm.Location.CloseTime ?? new TimeSpan()
                               };

                    return result.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetAssortmentMatrix)}. Ошибка при получении матрицы для формирования заданий на расчет по связанным магазинам из того же кластера", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение продаж
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<LocationStateHourSaleViewModel>> GetSalesForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var query = context.LocationStateHourSales
                        .Where(t => locationId == t.LocationId && productsIds.Contains(t.ProductId));

                    if (startDate.HasValue)
                    {
                        query = query.Where(t => t.Datetime >= startDate.Value);
                    }

                    if (endDate.HasValue)
                    {
                        query = query.Where(t => t.Datetime < endDate.Value);
                    }

                    var result = await _mapper.ProjectTo<LocationStateHourSaleViewModel>(query).ToListAsync();

                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetSalesForSeries)}. Ошибка при получении продаж", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение продаж по связанным магазинам из того же кластера
        /// </summary>
        /// <param name="locationIds"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<LocationStateHourSaleViewModel>> GetRelatedStoresSalesForSeries(IEnumerable<Common.Forecasting.Tasks.RelatedStore> relatedStores, DateTime startDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var stores = relatedStores.Select(x => x.LocationId).Distinct();
                    var products = relatedStores.Select(x => x.ProductId).Distinct();

                    //var query = await context.ExecuteProcedureAsync<LocationStateHourSale>("dbo.GetRelatedSales", new
                    //{
                    //    RelatedStores = DataHelper.ToDataTable(relatedStores.Select(x => new Data.Entities.RelatedStore()
                    //    {
                    //        LocationId = x.LocationId,
                    //        ProductId = x.ProductId,
                    //        StartDateTime = x.StartDateTime.Date,
                    //        EndDateTime = x.EndDateTime
                    //    }).ToList())
                    //});

                    var minDate = relatedStores.Min(x => x.StartDateTime).Date;
                    var maxDate = relatedStores.Min(x => x.EndDateTime);

                    var allSales = await context.LocationStateHourSales
                        .Where(t => stores.Contains(t.LocationId) && products.Contains(t.ProductId)
                                    && t.Datetime >= minDate
                                    && t.Datetime < maxDate
                               ).ToListAsync();

                    var query = from s in allSales
                                join rs in relatedStores on new { s.LocationId, s.ProductId } equals new { rs.LocationId, rs.ProductId }
                                where s.Datetime >= rs.StartDateTime.Date && s.Datetime < rs.EndDateTime
                                select s;

                    return _mapper.Map<List<LocationStateHourSaleViewModel>>(query); 
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetSalesForSeries)}. Ошибка при получении продаж по связанным магазинам из того же кластера", ex);
                throw;
            }
        }


        /// <summary>
        /// Получение остатков
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<LocationStateStocksViewModel>> GetStocksForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var query = context.LocationStateStocks
                        .Where(t => locationId == t.LocationId && productsIds.Contains(t.ProductId));

                    if (startDate.HasValue)
                    {
                        query = query.Where(t => t.Datetime >= startDate.Value);
                    }

                    if (endDate.HasValue)
                    {
                        query = query.Where(t => t.Datetime < endDate.Value);
                    }

                    var result = await _mapper.ProjectTo<LocationStateStocksViewModel>(query).ToListAsync();

                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetStocksForSeries)}. Ошибка при получении остатков", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение остатков по связанным магазинам из того же кластера
        /// </summary>
        /// <param name="locationIds"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<LocationStateStocksViewModel>> GetRelatedStoresStocksForSeries(IEnumerable<Common.Forecasting.Tasks.RelatedStore> relatedStores, DateTime startDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
            
                    var stores = relatedStores.Select(x => x.LocationId).Distinct();
                    var products = relatedStores.Select(x => x.ProductId).Distinct();

                    //var allStocks = await context.ExecuteProcedureAsync<LocationStateStock>("dbo.GetRelatedStocks", new
                    //{
                    //    RelatedStores = DataHelper.ToDataTable(relatedStores.Select(x => new Data.Entities.RelatedStore()
                    //    {
                    //        LocationId = x.LocationId,
                    //        ProductId = x.ProductId,
                    //        StartDateTime = x.StartDateTime.Date.AddDays(-1),
                    //        EndDateTime = x.EndDateTime.Date
                    //    }).ToList())
                    //});

                    //var query = from s in allStocks
                    //            join rs in relatedStores on new { s.LocationId, s.ProductId } equals new { rs.LocationId, rs.ProductId }
                    //            select s;

                    var minDate = relatedStores.Min(x => x.StartDateTime.Date).AddDays(-1);
                    var maxDate = relatedStores.Min(x => x.EndDateTime.Date);

                    var allSales = await context.LocationStateStocks
                        .Where(t => stores.Contains(t.LocationId) && products.Contains(t.ProductId)
                                    && t.Datetime >= minDate
                                    && t.Datetime < maxDate
                               ).ToListAsync();

                    var query = from s in allSales
                                join rs in relatedStores on new { s.LocationId, s.ProductId } equals new { rs.LocationId, rs.ProductId }
                                where s.Datetime >= rs.StartDateTime.Date.AddDays(-1) && s.Datetime < rs.EndDateTime.Date
                                select s;

                    return _mapper.Map<List<LocationStateStocksViewModel>>(query);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetStocksForSeries)}. Ошибка при получении остатков по связанным магазинам из того же кластера", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение промо акций
        /// </summary>
        /// <param name="locationIds></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<PromotionMatrixViewModel>> GetPromotionsForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var query = context.PromoPeriods
                                .Where(t => locationId == t.LocationId && productsIds.Contains(t.ProductId));

                    if (startDate.HasValue)
                    {
                        query = query.Where(t => t.DtEnd >= startDate.Value);
                    }

                    if (endDate.HasValue)
                    {
                        query = query.Where(t => t.DtBegin <= endDate.Value);
                    }

                    var result = await _mapper.ProjectTo<PromotionMatrixViewModel>(query).ToListAsync();

                    return result;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetPromotionsForSeries)}. Ошибка при получении промоакций", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение промо акций по связанным магазинам из того же кластера
        /// </summary>
        /// <param name="locationIds"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<IEnumerable<PromotionMatrixViewModel>> GetRelatedStoresPromotionsForSeries(IEnumerable<Common.Forecasting.Tasks.RelatedStore> relatedStores)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
               
                    var stores = relatedStores.Select(x => x.LocationId).Distinct();
                    var products = relatedStores.Select(x => x.ProductId).Distinct();

                    //var allPromotions = await context.ExecuteProcedureAsync<PromoPeriod>("dbo.GetRelatedPromotions", new
                    //{
                    //    RelatedStores = DataHelper.ToDataTable(relatedStores.Select(x => new Data.Entities.RelatedStore()
                    //    {
                    //        LocationId = x.LocationId,
                    //        ProductId = x.ProductId,
                    //        StartDateTime = x.StartDateTime.Date,
                    //        EndDateTime = x.EndDateTime.Date
                    //    }).ToList())
                    //});

                    //var query = from s in allPromotions
                    //            join rs in relatedStores on new { s.LocationId, s.ProductId } equals new { rs.LocationId, rs.ProductId }
                    //            select s;

                    var minDate = relatedStores.Min(x => x.StartDateTime.Date);
                    var maxDate = relatedStores.Max(x => x.EndDateTime.Date);

                    var allPromos = await context.PromoPeriods
                        .Where(t => stores.Contains(t.LocationId) && products.Contains(t.ProductId) && t.DtEnd >= minDate && t.DtBegin <= maxDate)
                        .ToListAsync();

                    var query = from s in allPromos
                                join rs in relatedStores on new { s.LocationId, s.ProductId } equals new { rs.LocationId, rs.ProductId }
                                where s.DtEnd >= rs.StartDateTime.Date && s.DtBegin <= rs.EndDateTime.Date
                                select s;

                    return _mapper.Map<List<PromotionMatrixViewModel>>(query);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetPromotionsForSeries)}. Ошибка при получении промоакций по связанным магазинам из того же кластера", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение праздников
        /// </summary>
        /// <param name="locationId"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IEnumerable<HolidayPeriodMatrixViewModel> GetHolidayPeriodForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate)
        {
            try
            {
                Expression<Func<HolidayPeriod, bool>> predicateOnHolidayPeriods = PredicateBuilder.New<HolidayPeriod>(false);

                if (startDate.HasValue && endDate.HasValue)
                {
                    predicateOnHolidayPeriods = predicateOnHolidayPeriods.Or(i => i.StartDate >= startDate.Value && i.EndDate <= endDate.Value);

                    predicateOnHolidayPeriods = predicateOnHolidayPeriods.Or(i => i.StartDate <= endDate.Value && i.EndDate > endDate.Value);

                    predicateOnHolidayPeriods = predicateOnHolidayPeriods.Or(i => i.EndDate >= startDate.Value && i.StartDate < startDate.Value);
                }

                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var holidayPeriods = context.HolidayPeriods
                    .Where(t => t.IsActive == true)
                    .AsExpandable()
                    .Where(predicateOnHolidayPeriods.Expand())
                    .ToList();

                    var stores = new List<int>() { locationId };

                    var query =
                        stores.SelectMany(
                            loc =>
                                productsIds.SelectMany(
                                    prod =>
                                        holidayPeriods.Select(
                                            h =>
                                                new HolidayPeriodMatrixViewModel()
                                                {
                                                    LocationId = loc,
                                                    ProductId = prod,
                                                    HolidayPeriodId = h.Id,
                                                    StartDate = h.StartDate,
                                                    EndDate = h.EndDate
                                                })));

                    return query.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetHolidayPeriodForSeries)}. Ошибка при получении праздников", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение праздников по связанным магазинам из того же кластера
        /// </summary>
        /// <param name="locationIds"></param>
        /// <param name="productsIds"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IEnumerable<HolidayPeriodMatrixViewModel> GetRelatedStoresHolidayPeriodForSeries(IEnumerable<Common.Forecasting.Tasks.RelatedStore> relatedStores)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    var holidayPeriods = context.HolidayPeriods
                    .Where(t => t.IsActive == true)
                    .AsExpandable()
                    .ToList();


                    var query =
                        relatedStores.SelectMany(
                            s =>                                
                                holidayPeriods
                                .Where(hp => hp.StartDate >= s.StartDateTime && hp.EndDate <= s.EndDateTime
                                            || hp.StartDate <= s.EndDateTime && hp.EndDate > s.EndDateTime
                                            || hp.EndDate >= s.StartDateTime && hp.StartDate < s.StartDateTime)
                                .Select(
                                    h =>
                                        new HolidayPeriodMatrixViewModel()
                                        {
                                            LocationId = s.LocationId,
                                            ProductId = s.ProductId,
                                            HolidayPeriodId = h.Id,
                                            StartDate = h.StartDate,
                                            EndDate = h.EndDate
                                        }));

                    return query.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetHolidayPeriodForSeries)}. Ошибка при получении праздников по связанным магазинам из того же кластера", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение часвого пояса
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        public async Task<int> GetTimeZone(long jobId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = await context.Jobs
                                .Where(j => j.Id == jobId)
                                .Include(j => j.JobSchedule)
                                .Join(context.CalcTypes, 
                                        js => js.JobSchedule.CalcTypeId, 
                                        jt => jt.Id, 
                                        (j, jt) => new { TimezoneId = jt.TimezoneId }
                                      )
                                .FirstOrDefaultAsync();

                    if (!query.TimezoneId.HasValue)
                        throw new Exception("Не задан часовой пояс!");

                    return query.TimezoneId.Value;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetParam)}. Ошибка при получении часового пояса", ex, jobId);
                throw;
            }
        }

        /// <summary>
        /// Получение параметра по названию
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        public async Task<string> GetParam(long jobId, string paramName, int storeId, int productId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var query = await context.LostSalesAnalysisTasks
                                .Where(j => j.LostSalesAnalysisJobId == jobId && j.LocationId == storeId && j.ProductId == productId)
                                .Join(context.LostSalesAnalysisSubJobs, sj => sj.LostSalesAnalysisSubJobId, lj => lj.Id, (jt, lj) => new { lj.SchemaId })
                                .Join(context.LostSalesAnalisysSchemaParams.Where(p => p.Key == paramName), s => s.SchemaId, p => p.SchemaId, (s, p) => p.Value)
                                .FirstOrDefaultAsync();

                    return query;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetParam)}. Ошибка при получении параметра {paramName}", ex, jobId);
                throw;
            }
        }

        public delegate bool TryParseNumberDelegate<T>(string str, NumberStyles styles, NumberFormatInfo info, out T value);
        public delegate bool TryParseDelegate<T>(string str, out T value);
        private T ConvertParam<T>(string name, Dictionary<string, string> dict, long jobId, TryParseNumberDelegate<T> parseNumber = null, TryParseDelegate<T> parse = null) where T: struct
        {
            T convertedParam;

            if( !dict.ContainsKey(name))
                throw new Exception($"Параметр {name} для JobId = {jobId} не найден.");

            var numberFormatInfo = new System.Globalization.CultureInfo("ru-Ru", false).NumberFormat;

            if (parseNumber != null)
            {
                if (!parseNumber(dict[name], NumberStyles.Any, numberFormatInfo, out convertedParam))
                    throw new Exception($"Значение {dict[name]} параметра {name} для JobId = {jobId} имеет неверный формат.");
            }
            else
            {
                if (!parse(dict[name], out convertedParam))
                    throw new Exception($"Значение {dict[name]} параметра {name} для JobId = {jobId} имеет неверный формат.");
            }


            return convertedParam;
        }

        /// <summary>
        /// Получение параметров расчета
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<LostSalesAnalysisParamViewModel> GetForecastParams(long jobId, int storeId, int productId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {

                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var schemaId = (await context.LostSalesAnalysisTasks
                                .Where(j => j.LostSalesAnalysisJobId == jobId && j.LocationId == storeId && j.ProductId == productId)                                
                                .Join(context.LostSalesAnalysisSubJobs, t => t.LostSalesAnalysisSubJobId, sj => sj.Id, (t,sj) => new { sj.SchemaId})
                                .FirstOrDefaultAsync())?.SchemaId;

                    if (schemaId == null)
                        throw new Exception($"Для JobId = {jobId} не найдена схема.");

                    var paramDict = await context.LostSalesAnalisysSchemaParams
                                .Where(p => p.SchemaId == schemaId)
                                .ToDictionaryAsync(k => k.Key, v => v.Value);

                    if(!paramDict.ContainsKey("HistParam3") 
                        || paramDict["HistParam3"].Split("/").Count() != 2
                        || !float.TryParse(paramDict["HistParam3"].Split("/")[0], out float dividend)
                        || !float.TryParse(paramDict["HistParam3"].Split("/")[1], out float divider))
                       throw new Exception($"Параметр HistParam3 для JobId = {jobId} не найден или имеет неверный формат.");

                    return new LostSalesAnalysisParamViewModel
                    {
                        JobId = jobId,
                        HistParam1 = ConvertParam<float>("HistParam1", paramDict, jobId, float.TryParse),
                        HistParam2 = ConvertParam<float>("HistParam2", paramDict, jobId, float.TryParse),
                        HistParam3 = divider == 0 ? 0 : dividend / divider,
                        Threshold = ConvertParam<float>("Threshold", paramDict, jobId, float.TryParse),
                        IsGlobalProfile = ConvertParam<bool>("IsGlobalProfile", paramDict, jobId, null, bool.TryParse),
                        UseDeficit = ConvertParam<bool>("UseDeficit", paramDict, jobId, null, bool.TryParse),
                        UsePromo = ConvertParam<bool>("UsePromo", paramDict, jobId, null, bool.TryParse),
                        UseClosed = ConvertParam<bool>("UseClosed", paramDict, jobId, null, bool.TryParse),
                        UseClearOutliers = ConvertParam<bool>("UseClearOutliers", paramDict, jobId, null, bool.TryParse),
                        AdjustPromoForTask = ConvertParam<bool>("AdjustPromoForTask", paramDict, jobId, null, bool.TryParse),
                        AdjustHolidayForTask = ConvertParam<bool>("AdjustHolidayForTask", paramDict, jobId, null, bool.TryParse),
                        UseHoliday = ConvertParam<bool>("UseHoliday", paramDict, jobId, null, bool.TryParse),
                        ClearOutliersWindowsWidth = new ParameterInt(ConvertParam<int>("ClearOutliersWindowsWidth", paramDict, jobId, int.TryParse)),
                        ClearOutliersThreshold = new ParameterDouble(ConvertParam<int>("ClearOutliersThreshold", paramDict, jobId, int.TryParse)),
                        ClearOutliersReplacementMode = new ParameterInt(ConvertParam<int>("ClearOutliersReplacementMode", paramDict, jobId, int.TryParse)),
                        NeedPreExecutionJson = ConvertParam<bool>("NeedPreExecutionJson", paramDict, jobId, null, bool.TryParse),
                        NeedPostExecutionJson = ConvertParam<bool>("NeedPostExecutionJson", paramDict, jobId, null, bool.TryParse),
                        DaysCount = ConvertParam<int>("DaysCount", paramDict, jobId, int.TryParse),
                        UseWeekProfile = ConvertParam<bool>("UseWeekProfile", paramDict, jobId, null, bool.TryParse),
                        MaxNanPointsIntervalPart = ConvertParam<double>("MaxNanPointsIntervalPart", paramDict, jobId, double.TryParse),
                        MinValidPointsCount = ConvertParam<int>("MinValidPointsCount", paramDict, jobId, int.TryParse),
                        DefaultThreshold = ConvertParam<double>("DefaultThreshold", paramDict, jobId, double.TryParse),
                        StockThresholdForBegin = ConvertParam<double>("StockThresholdForBegin", paramDict, jobId, double.TryParse),
                        StockThresholdForBeginInOneDay = ConvertParam<double>("StockThresholdForBeginInOneDay", paramDict, jobId, double.TryParse),
                        HourLenThreshold = ConvertParam<int>("HourLenThreshold", paramDict, jobId, int.TryParse),
                        UseStoresAnalysis = ConvertParam<bool>("UseStoresAnalysis", paramDict, jobId, null, bool.TryParse),
                        ClearOutliersOnlyForSuspects = ConvertParam<bool>("ClearOutliersOnlyForSuspects", paramDict, jobId, null, bool.TryParse),
                    };
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetForecastParams)}. Ошибка при получении параметров расчета ", ex, jobId);
                throw;
            }

        }

        /// <summary>
        /// Сохранить результаты расчета
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tasks"></param>
        public void SaveMultiple<T>(List<T> tasks) where T : class
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = (OsaOnlineDbContext)scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();
                    context.Insert(tasks);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(SaveMultiple)}. Ошибка при сохранении результатов расчета", ex);
                throw;
            }
        }

        /// <summary>
        /// Получение почасовых продаж для предполагаемых интервалов
        /// </summary>
        /// <param name="analyseDate"></param>
        /// <param name="taskIds"></param>
        /// <returns></returns>
        public IEnumerable<HourSaleDuringSuspect> GetHourSaleDuringSuspect(DateTime analyseDate, IEnumerable<long> taskIds, int LocationId)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var inAssortmentAndPromo = from ass in context.ProductMatrix.Where(i => i.IsPromo && i.Date == analyseDate.Date)
                                               from sale in context.LocationStateDaySales
                                                   .Where(
                                                       i =>
                                                           i.ProductId == ass.ProductId
                                                           && i.LocationId == ass.LocationId
                                                           && i.Date == analyseDate.Date
                                                           && i.Quantity > 0
                                                         )
                                               select new
                                               {
                                                   LocationId = sale.LocationId,
                                                   ProductId = sale.ProductId
                                               };

                    var suspects =
                        context.LostSalesAnalysisTasks
                            .Where(i => taskIds.Contains(i.Id))
                            .Select(
                                i =>
                                    new
                                    {
                                        Id = i.Id,
                                        ProductId = i.ProductId,
                                        LocationId = i.LocationId,
                                        StoreFormat = (i.Location as Location).StoreFormat.Name,
                                        RegionId = (i.Location as Location).StoreRegion.Id,
                                        DateStart = i.StartDateTime,
                                        DateEnd = i.EndDateTime
                                    });

                    var suspectsWithLocations = from suspect in suspects
                                                from l in
                                                    context.Locations
                                                        .Where(
                                                            i =>
                                                                i.StoreRegion.Id == suspect.RegionId &&
                                                                i.StoreFormat.Name == suspect.StoreFormat &&
                                                                i.Id != suspect.LocationId)
                                                select
                                                    new
                                                    {
                                                        SuspectLocationId = suspect.LocationId,
                                                        LocationId = l.Id,
                                                        ProductId = suspect.ProductId,
                                                        Start = suspect.DateStart,
                                                        End = suspect.DateEnd,
                                                        SuspectId = suspect.Id
                                                    };

                    var promo = from suspect in suspectsWithLocations
                                from ass in inAssortmentAndPromo.Where(i => i.ProductId == suspect.ProductId && i.LocationId == suspect.LocationId)
                                select new
                                {
                                    LocationId = ass.LocationId,
                                    ProductId = ass.ProductId,
                                    SuspectId = suspect.SuspectId,
                                    SuspectStart = suspect.Start,
                                    SuspectEnd = suspect.End,
                                    SuspectLocationId = suspect.SuspectLocationId
                                };

                    var sales = (from pr in promo
                                 from sale in context.LocationStateHourSales
                                     .Where(i => i.LocationId == pr.LocationId &&
                                                 i.ProductId == pr.ProductId &&
                                                 i.Datetime >= pr.SuspectStart &&
                                                 i.Datetime < pr.SuspectEnd)
                                 select
                                     new HourSaleDuringSuspect
                                     {
                                         SimilarLocationCount = 0,
                                         SuspectLocationId = LocationId,
                                         LocationId = sale.LocationId,
                                         ProductId = sale.ProductId,
                                         Date = sale.Datetime,
                                         Quantity = sale.Quantity,
                                         LostSalesAnalysisTaskId = pr.SuspectId
                                     }).ToList();

                    var similarLocationCounts = sales.Select(t => new { t.LocationId, t.ProductId, t.SuspectLocationId })
                        .Distinct()
                        .GroupBy(t => (t.ProductId, t.SuspectLocationId))
                        .Select(t => new { ProductLocation = t.Key, SimilarLocationCount = t.Count() })
                        .ToDictionary(t => t.ProductLocation, t => t.SimilarLocationCount);

                    foreach (var sale in sales)
                    {
                        if (similarLocationCounts.ContainsKey((sale.ProductId, sale.SuspectLocationId)))
                        {
                            sale.SimilarLocationCount = similarLocationCounts[(sale.ProductId, sale.SuspectLocationId)];
                        }
                    }

                    return sales.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetHourSaleDuringSuspect)}. Ошибка при получении почасовых продаж по промо для предполагаемых интервалов", ex);
                throw;
            }
        }

        public IEnumerable<HourSaleDuringPromo> GetHourSaleDuringSuspect(DateTime analyseDate, IEnumerable<long> taskIds)
        {
            try
            {
                using (var scope = _serviceScopeFactory.CreateScope())
                {
                    var context = scope.ServiceProvider.GetRequiredService<IOsaOnlineDbContext>();

                    var suspects = context.LostSalesAnalysisTasks
                    .Where(i => taskIds.Contains(i.Id))
                    .Select(i => new
                    {
                        i.LocationId,
                        TaskId = i.Id,
                        i.ProductId,
                        i.StartDateTime,
                        i.EndDateTime
                    });

                    var promoperiods = from pm in context.PromotionMatrix
                                       from promo in
                                           context.Promotions
                                               .Where(
                                                   i =>
                                                       i.Id == pm.PromotionId && i.StartDate <= analyseDate &&
                                                       analyseDate <= i.EndDate && EF.Functions.DateDiffDay(i.StartDate, analyseDate) <= 27)
                                       group promo by new { pm.ProductId, pm.LocationId }
                                       into grouping
                                       select new
                                       {
                                           grouping.Key.LocationId,
                                           grouping.Key.ProductId,
                                           Start = grouping.Min(i => i.StartDate)
                                       };

                    var saleperiod = from task in suspects
                                     from promo in promoperiods.Where(i => i.LocationId == task.LocationId && i.ProductId == task.ProductId)
                                     select new
                                     {
                                         task.LocationId,
                                         task.ProductId,
                                         task.TaskId,
                                         TaskStart = task.StartDateTime,
                                         TaskEnd = task.EndDateTime,
                                         PeriodEnd = task.StartDateTime.AddHours(-1),
                                         PeriodSatrt = promo.Start
                                     };

                    var sales = from sale in context.LocationStateHourSales.Where(i => i.Quantity > 0)
                                from period in
                                    saleperiod.Where(
                                        i =>
                                            i.LocationId == sale.LocationId && i.ProductId == sale.ProductId &&
                                            i.PeriodSatrt <= sale.Datetime &&
                                            sale.Datetime <= i.PeriodEnd)
                                select new HourSaleDuringPromo
                                {
                                    LocationId = sale.LocationId,
                                    ProductId = sale.ProductId,
                                    Date = sale.Datetime,
                                    Quantity = sale.Quantity,
                                    TaskId = period.TaskId,
                                    TaskStart = period.TaskStart,
                                    TaskEnd = period.TaskEnd
                                };

                    return sales.ToList();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(GetHourSaleDuringSuspect)}. Ошибка при получении почасовых продаж по промо для предполагаемых интервалов", ex);
                throw;
            }
    
        }


    }
}
