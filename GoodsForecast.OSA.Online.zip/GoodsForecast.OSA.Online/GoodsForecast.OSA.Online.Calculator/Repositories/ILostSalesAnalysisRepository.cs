﻿using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks.Promo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Repositories
{
    /// <summary>
    /// Получение данных для расчета
    /// </summary>
    public interface ILostSalesAnalysisRepository
    {
        Task<LostSalesAnalysisJobViewModel> GetLostSalesAnalysisJobs(long jobId);
        Task<IEnumerable<AssortmentMatrixItemViewModel>> GetAssortmentMatrix(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate);
        Task<IEnumerable<LocationStateHourSaleViewModel>> GetSalesForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate);
        Task<IEnumerable<LocationStateStocksViewModel>> GetStocksForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate);
        Task<IEnumerable<PromotionMatrixViewModel>> GetPromotionsForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate);
        IEnumerable<HolidayPeriodMatrixViewModel> GetHolidayPeriodForSeries(int locationId, IEnumerable<int> productsIds, DateTime? startDate, DateTime? endDate);
        Task<string> GetParam(long jobId, string paramName, int storeId, int productId);
        /// <summary>
        /// Получение часвого пояса
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="paramName"></param>
        /// <returns></returns>
        Task<int> GetTimeZone(long jobId);
        Task<LostSalesAnalysisParamViewModel> GetForecastParams(long jobId, int storeId, int productId);
        void SaveMultiple<T>(List<T> tasks) where T : class;

        IEnumerable<HourSaleDuringSuspect> GetHourSaleDuringSuspect(DateTime analyseDate, IEnumerable<long> taskIds, int locationId);
        IEnumerable<HourSaleDuringPromo> GetHourSaleDuringSuspect(DateTime analyseDate, IEnumerable<long> taskIds);

        Task<List<RelatedStore>> GetRelatedStoreProducts(int locationId, Dictionary<(int ProductId, DateTime StartDate), DatePeriod> productsPeriods, DateTime date);
        Task<IEnumerable<LocationStateHourSaleViewModel>> GetRelatedStoresSalesForSeries(IEnumerable<RelatedStore> relatedStores, DateTime startDate);
        Task<IEnumerable<LocationStateStocksViewModel>> GetRelatedStoresStocksForSeries(IEnumerable<RelatedStore> relatedStores, DateTime startDate);
        Task<IEnumerable<PromotionMatrixViewModel>> GetRelatedStoresPromotionsForSeries(IEnumerable<RelatedStore> relatedStores);
        IEnumerable<HolidayPeriodMatrixViewModel> GetRelatedStoresHolidayPeriodForSeries(IEnumerable<RelatedStore> relatedStores);        
    }
}
