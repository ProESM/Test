﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Calculator.Services;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using System;
using System.Linq;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using System.Collections.Generic;
using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using System.Collections;
using System.Diagnostics;
using GoodsForecast.OSA.Online.Calculator.Repositories;
using Microsoft.Extensions.Configuration;

namespace GoodsForecast.OSA.Online.Calculator.QueueHandlers
{
    /// <summary>
    /// Обработчик очередей для Calculator
    /// </summary>
    public class CalculatorQueueHandler : IQueueMessageHandler
    {
        /// <summary>
        /// Количество попыток переотправки сообщения
        /// </summary>
        private const int MaxReSendCount = 5;

        private readonly IBus _bus;
        private readonly OsaLogger<CalculatorQueueHandler> _logger;
        private IDisposable _busConnection;
        private int TaskCount;
        private readonly ILostSalesAnalysisRepository _lostSalesAnalysisRepository;
        private object LockObj = new object();
        private int MaxTaskCount { get; set; }

        public CalculatorQueueHandler(IBus bus,
            OsaLogger<CalculatorQueueHandler> logger, 
            ILostSalesAnalysisRepository lostSalesAnalysisRepository,
            IConfiguration configuration)
        {
            _bus = bus;
            _logger = logger;
            _lostSalesAnalysisRepository = lostSalesAnalysisRepository;
            TaskCount = 0;
            MaxTaskCount = configuration.GetValue<int>("TaskCount");
        }

        public async Task Register()
        {
            _busConnection = await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.BrokerToCalculator), Handle);
        }

        public async Task Handle(IQueueMessage message)
        {            
            if (TaskCount < MaxTaskCount)
            {                
                lock (LockObj)
                {
                    TaskCount++;
                }
                
                var task = Task.Run(async () =>
                {

                    switch (message)
                    {
                        case BrokerToCalculatorMessage bcMessage:
                            await ProcessMessageFromBroker(bcMessage);
                            break;
                        default:
                            throw new ArgumentOutOfRangeException($"Тип сообщения {message.GetType()} не найден");
                    }
                    lock (LockObj)
                    {
                        TaskCount--;
                    }
                });
            }
            else
            {
                await Task.Delay(1000);
                await Handle(message);
            }            
        }

        /// <summary>
        /// Обработка сообщения от брокера
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private async Task ProcessMessageFromBroker(BrokerToCalculatorMessage message)
        {           

            try
            {
                _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{message.SubBatchId}]. Получено задание на расчет.", message.JobId);

                switch (message)
                {
                    case SuspectForecastBatch batch:
                        await CalculateBatch(batch, batch.JobId);
                        break;
                    case PromoSuspectForecastBatch batch:
                        await CalculatePromoBatch(batch, batch.JobId);
                        break;
                    default:
                        throw new ArgumentOutOfRangeException($"Тип сообщения {message.GetType()} не найден");
                }

                //по окончанию расчета отправляем сообщение о его завершении брокеру
                await SendMessage(new CalculatorToBrokerMessage
                {
                    JobId = message.JobId,
                    SubJobId = message.SubJobId,
                    BatchId = message.BatchId,
                    SubBatchId = message.SubBatchId,
                    LocationId = message.LocationId,
                    AllCount = message.AllCount,
                    IsError = false,
                    RestartCount = message.RestartCount
                }, 0);

                _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{message.SubBatchId}]. Расчет по заданию завершен.", message.JobId);

            }
            catch (Exception exception)
            {
                _logger.LogError(Environment.MachineName, $"{nameof(ProcessMessageFromBroker)}. SubBatchId = [{message.SubBatchId}]. Произошла ошибка во время расчета: {exception.Message}", exception, message.JobId);

                //в случае ошибки все равно отправляем сообщение о завершении расчета, но с ошибкой
                await _bus.SendReceive.SendAsync(
                        nameof(QueueName.CalculatorToBroker),
                        new CalculatorToBrokerMessage
                        {
                            JobId = message.JobId,
                            SubJobId = message.SubJobId,
                            BatchId = message.BatchId,
                            SubBatchId = message.SubBatchId,
                            LocationId = message.LocationId,
                            AllCount = message.AllCount,
                            RestartCount = message.RestartCount,
                            IsError = true,
                            ErrorMessage = exception.ToString()
                        });
            }
        }

        /// <summary>
        /// Отправка сообщение в очередь с возможностью перезапуска
        /// </summary>
        /// <param name="message">Сообщение для отправки</param>
        /// <param name="sendCount">Количество попыток перезапуска</param>
        /// <returns></returns>
        private async Task SendMessage(CalculatorToBrokerMessage message, int sendCount)
        {
            try
            {
                await _bus.SendReceive.SendAsync(nameof(QueueName.CalculatorToBroker), message);
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"SubBatchId = [{message.SubBatchId}]. Не удалось отправить сообщение.", ex, message.JobId);                
                sendCount++;
                if (sendCount <= MaxReSendCount)
                {
                    await Task.Delay(10000);
                    await SendMessage(message, sendCount);
                }
                else
                   throw new Exception($"SubBatchId = [{message.SubBatchId}]. Не удалось отправить сообщение после {sendCount} попыток.");
                
            }
        }


        /// <summary>
        /// Расчет батча
        /// </summary>
        /// <param name="dateMessage"></param>
        /// <param name="calcType"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task CalculateBatch(SuspectForecastBatch dateMessage, long jobId)
        {            
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Получение параметров.", jobId);

            var _taskService = new TaskService(_logger, _lostSalesAnalysisRepository);
            var _forecastingService = new ForecastingService(_bus, _logger, _lostSalesAnalysisRepository);
            var _taskResultService = new TaskResultService(_logger, _lostSalesAnalysisRepository);

            var _forecastParams = await _taskService.GetForecastParams
                            (
                                dateMessage.JobId,
                                dateMessage.Items.Select(x => x.LocationId).First(),
                                dateMessage.Items.Select(x => x.ProductId).First()
                            );

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Запуск расчета батча.", jobId);

            Stopwatch sw = new Stopwatch();
            sw.Start();

            var tasks = await _taskService.GetTasks(dateMessage);

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Получены данные. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);
            sw.Restart();

            var suspectForecastResult = await _forecastingService.Analize(tasks, _forecastParams, jobId, dateMessage.SubBatchId, dateMessage.AlgType);

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Закончен расчет в TSA. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);

            suspectForecastResult.ToList().ForEach(i =>
            {
                //i.Probability = dateMessage.IsAbsoluteProbability ? 1 : i.Probability;
                i.IsCalculatedInTsa = true;
            });
            sw.Restart();

            await _taskResultService.SaveResults(dateMessage.JobId, suspectForecastResult);

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Сохранены результаты расчета. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);
            sw.Stop();

            GC.Collect();
            GC.SuppressFinalize(_taskService);
            GC.SuppressFinalize(_forecastingService);
            GC.SuppressFinalize(_taskResultService);
            GC.Collect();
        }

        /// <summary>
        /// Расчет промобатча
        /// </summary>
        /// <param name="dateMessage"></param>
        /// <param name="calcType"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task CalculatePromoBatch(PromoSuspectForecastBatch dateMessage, long jobId)
        {
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Запуск расчета промобатча.", jobId);
            Stopwatch sw = new Stopwatch();
            sw.Start();

            var _taskService = new TaskService(_logger, _lostSalesAnalysisRepository);
            var _forecastingService = new ForecastingService(_bus, _logger, _lostSalesAnalysisRepository);
            var _taskResultService = new TaskResultService(_logger, _lostSalesAnalysisRepository);

            var susperctForecastResult = await _forecastingService.PromoAnalize(dateMessage, _bus);
            var grouppedResults = susperctForecastResult
                .GroupBy(x => new 
                { 
                    x.TaskId, 
                    x.ProductId, 
                    x.Probability, 
                    x.LocationId, 
                    x.IsPhantom, 
                    x.IsCalculatedInTsa 
                })
                .ToDictionary(k => k.Key, v => new
                {
                    MeanSell = v.Sum(s => s.MeanSell),
                    SuspectResults = new SortedList<DateTime, SuspectResult>(
                        v.SelectMany(r => r.SuspectResults)
                        .GroupBy(y => y.Key)
                        .Select(rs => 
                            new KeyValuePair<DateTime, SuspectResult>(
                                    rs.Key, 
                                    new SuspectResult { Profile = 0, LossNumber = rs.Sum(rs => rs.Value.LossNumber)}
                                ))
                                    
                        .ToDictionary(x => x.Key, v => v.Value)
                     )  
                })
                .Select(z => new SuspectForecastResult
                { 
                    TaskId = z.Key.TaskId,
                    ProductId = z.Key.ProductId,
                    Probability = z.Key.Probability,
                    LocationId = z.Key.LocationId,
                    IsPhantom = z.Key.IsPhantom,
                    IsCalculatedInTsa = z.Key.IsCalculatedInTsa,
                    MeanSell = z.Value.MeanSell,
                    SuspectResults = z.Value.SuspectResults
                }
                );

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Закончен расчет по средним продажам.  <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);
            sw.Restart();

            grouppedResults.ToList().ForEach(i => { i.IsCalculatedInTsa = false; });

            if (susperctForecastResult.Any())
            {
                await _taskResultService.SaveResults(dateMessage.JobId, grouppedResults);
            }

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Сохранены результаты расчета промобатча. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);
            sw.Restart();

            await SendToCalculateTsa(dateMessage, grouppedResults, jobId);

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = [{dateMessage.SubBatchId}]. Закончен расчет промобатча. <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", jobId);
            sw.Stop();
        }

        /// <summary>
        /// Отправление на расчет в TSA, то что не удалось посчитать по средним продаж по промобатчу
        /// </summary>
        /// <param name="dateMessage"></param>
        /// <param name="susperctForecastResult"></param>
        /// <param name="calcType"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private async Task SendToCalculateTsa(PromoSuspectForecastBatch dateMessage, IEnumerable<SuspectForecastResult> susperctForecastResult, long jobId)
        {
            var batchItems = dateMessage.Items.ToList();
            batchItems.RemoveAll(i => susperctForecastResult.Select(c => c.ProductId).Contains(i.ProductId));
            if (batchItems.Any())
            {
                var batchItemsWithoutAvgSales = batchItems.Select(i =>
                    new SuspectForecastBatchItem()
                    {
                        ProductId = i.ProductId,
                        LocationId = dateMessage.LocationId,
                        Schedule = dateMessage.Schedule,
                        Suspects =
                            new List<Suspect>()
                            {
                                new Suspect()
                                {
                                    StartDate = i.StartDate,
                                    EndDate = i.EndDate,
                                    Length = i.Length,
                                    Id = i.Id,
                                    IsKvi = i.IsKvi,
                                    PromoAlgType = i.PromoAlgType,
                                    Threshold = i.Threshold
                                }
                            }
                    });

                var batchForTsa = new SuspectForecastBatch()
                {
                    SubBatchId = dateMessage.SubBatchId,
                    LocationId = dateMessage.LocationId,
                    JobId = dateMessage.JobId,
                    Schedule = dateMessage.Schedule,
                    HistoryStartDate = dateMessage.HistoryStartDate,
                    HistoryEndDate = dateMessage.HistoryEndDate,
                    IsAbsoluteProbability = true,
                    Items = batchItemsWithoutAvgSales.ToList()
                };

                await CalculateBatch(batchForTsa, jobId);
            }
        }

        public void Dispose()
        {
            _busConnection?.Dispose();
            _bus?.Dispose();
        }
    }
}