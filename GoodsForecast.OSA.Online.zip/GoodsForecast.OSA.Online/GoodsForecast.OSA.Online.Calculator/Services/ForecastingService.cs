﻿using Forecsys.TSA.Core;
using Forecsys.TSA.Okay;
using GoodsForecast.OSA.Online.Calculator.Extensions;
using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using Forecsys.TSA.Serialization;
using Forecsys.ForeGround.Core;
using System.IO;
using GoodsForecast.OSA.Online.Common.Forecasting;
using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Calculator.Repositories;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks.Promo;
using System.Threading.Tasks;
using GoodsForecast.OSA.Online.Common.Messaging;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using System.Runtime;
using GoodsForecast.OSA.Online.Calculator.QueueHandlers;
using System.Diagnostics;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Расчет сигналов и упущенных продаж в TSA
    /// - преобразование входных данных, 
    /// - запуск расчета, 
    /// - преобразование выходных данных
    /// </summary>
    public class ForecastingService: IForecastingService
    {
        private readonly OsaLogger<CalculatorQueueHandler> _logger;
        private readonly ILostSalesAnalysisRepository _lostSalesAnalysisRepository;
        private readonly IBus _bus;

        public ForecastingService(IBus bus, OsaLogger<CalculatorQueueHandler> logger, ILostSalesAnalysisRepository lostSalesAnalysisRepository)
        {
            _logger = logger;
            _lostSalesAnalysisRepository = lostSalesAnalysisRepository;
            _bus = bus;
        }

        protected long JobId { get; set; }
        protected long SubBatchId { get; set; }
        protected AlgType AlgType { get; set; }

        protected LostSalesAnalysisParamViewModel ForecastParams { get; set; }

        protected ExtendedSuspectAnalysis AnalyseSuspect { get; set; }
        private AnalyseSuspectProbabilityParameters SuspectProbabilityParameters
        {
            get
            {
                return new AnalyseSuspectProbabilityParameters()
                {
                    DaysCount = ForecastParams.DaysCount,
                    UseStoresAnalysis = ForecastParams.UseStoresAnalysis,
                    UseWeekProfile = ForecastParams.UseWeekProfile,
                    MaxNanPointsIntervalPart = ForecastParams.MaxNanPointsIntervalPart,
                    MinValidPointsCount = ForecastParams.MinValidPointsCount
                };
            }
        }

        private SuspectThresholdParams SuspectThresholdParams
        {
            get
            {
                return new SuspectThresholdParams()
                {
                    DefaultThreshold = ForecastParams.DefaultThreshold,
                    StockThresholdForBegin = ForecastParams.StockThresholdForBegin,
                    StockThresholdForBeginInOneDay = ForecastParams.StockThresholdForBeginInOneDay,
                    HourLenThreshold = ForecastParams.HourLenThreshold
                };
            }
        }

        public async Task<IEnumerable<SuspectForecastResult>> Analize(
            IEnumerable<SuspectForecastTask> tasks, 
            LostSalesAnalysisParamViewModel forecastParams, 
            long jobId, 
            long subBatchId,
            AlgType algType)
        {
            JobId = jobId;
            SubBatchId = subBatchId;
            AlgType = algType;
            ForecastParams = forecastParams;

            var suspects = tasks.ToList();

            PrepareAnalyseSuspect(suspects);

            var calculationResults = await Calculate(suspects);

            GC.Collect();
            GC.SuppressFinalize(suspects);
            GC.Collect();

            return calculationResults;
        }


        protected void PrepareAnalyseSuspect(IList<SuspectForecastTask> tasks)
        {
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {SubBatchId}. Заполнение структуры для TSA, алгоритм = {AlgType}", JobId);

            AnalyseSuspect = new ExtendedSuspectAnalysis
            {
                TsStorage = new TsStorage(),
                OpenHours = new OpenHours(),
                Suspect = new Forecsys.TSA.Okay.Suspect(),
                //Threshold = new List<double>(),
            };

            if (AlgType == AlgType.ByCluster && tasks.Count > 0)
            {
                foreach (var relatedStore in tasks.FirstOrDefault().RelatedStores)
                {
                    for (int i = 0; i < relatedStore.Sales.Count; i++)
                    {
                        AnalyseSuspect.TsStorage.Department.Add(relatedStore.LocationId);
                        AnalyseSuspect.TsStorage.Item.Add(relatedStore.ProductId);

                        var relatedSaleTimeSeries = relatedStore.Sales[i].ToTimeSeries(PointUnit.Hour);
                        relatedSaleTimeSeries.PointsWidth = TimeSpan.FromHours(1); // !!!
                        AnalyseSuspect.TsStorage.Series.Add(relatedSaleTimeSeries);

                        AnalyseSuspect.TsStorage.Rest.Add(relatedStore.Stocks[i].ToTimeSeries());

                        AnalyseSuspect.TsStorage.GroupSeries.Add(relatedSaleTimeSeries);

                        var relatedMarking = relatedStore.Promotions[i].ToMarking();
                        relatedMarking.PointsWidth = TimeSpan.FromDays(1);
                        AnalyseSuspect.TsStorage.Promo.Add(relatedMarking);

                        var relatedHolidayMarking = relatedStore.HolidayPeriods[i].ToMarking();
                        relatedHolidayMarking.PointsWidth = TimeSpan.FromDays(1);
                        AnalyseSuspect.TsStorage.Holiday.Add(relatedHolidayMarking);

                        for (var dayIndex = 0; dayIndex < 7; dayIndex++)
                        {
                            var dayOfWeek = (DayOfWeek)dayIndex;
                            AnalyseSuspect.OpenHours.Department.Add(relatedStore.LocationId);
                            AnalyseSuspect.OpenHours.WeekDay.Add(dayOfWeek);
                            AnalyseSuspect.OpenHours.OpenTime.Add(relatedStore.Schedule[dayOfWeek].Start.Hours);
                            AnalyseSuspect.OpenHours.CloseTime.Add(relatedStore.Schedule[dayOfWeek].End.Hours);
                        }
                    }
                }
            }

            foreach (var task in tasks)
            {
                AnalyseSuspect.TsStorage.Department.Add(task.LocationId);
                AnalyseSuspect.TsStorage.Item.Add(task.ProductId);

                var saleTimeSeries = task.Sales.ToTimeSeries(PointUnit.Hour);
                saleTimeSeries.PointsWidth = TimeSpan.FromHours(1); // !!!
                AnalyseSuspect.TsStorage.Series.Add(saleTimeSeries);

                AnalyseSuspect.TsStorage.Rest.Add(task.Stocks.ToTimeSeries());

                AnalyseSuspect.TsStorage.GroupSeries.Add(saleTimeSeries);

                var marking = task.Promotions.ToMarking();
                marking.PointsWidth = TimeSpan.FromDays(1);
                AnalyseSuspect.TsStorage.Promo.Add(marking);

                var holidayMarking = task.HolidayPeriods.ToMarking();
                holidayMarking.PointsWidth = TimeSpan.FromDays(1);
                AnalyseSuspect.TsStorage.Holiday.Add(holidayMarking);

                for (var dayIndex = 0; dayIndex < 7; dayIndex++)
                {
                    var dayOfWeek = (DayOfWeek)dayIndex;
                    AnalyseSuspect.OpenHours.Department.Add(task.LocationId);
                    AnalyseSuspect.OpenHours.WeekDay.Add(dayOfWeek);
                    AnalyseSuspect.OpenHours.OpenTime.Add(task.Schedule[dayOfWeek].Start.Hours);
                    AnalyseSuspect.OpenHours.CloseTime.Add(task.Schedule[dayOfWeek].End.Hours);
                }
                
                foreach (var suspect in task.Suspects)
                {
                    AnalyseSuspect.Suspect.Department.Add(task.LocationId);
                    AnalyseSuspect.Suspect.Item.Add(task.ProductId);
                    AnalyseSuspect.Suspect.Begin.Add(suspect.StartDate);
                    AnalyseSuspect.Suspect.Length.Add(suspect.Length);
                }
            }

            AnalyseSuspect.HistParams = new FloatParamsTable(ForecastParams.HistParam1, ForecastParams.HistParam2, ForecastParams.HistParam3);
            AnalyseSuspect.IsGlobalProfile = ForecastParams.IsGlobalProfile;

            AnalyseSuspect.UseDeficit = ForecastParams.UseDeficit;
            AnalyseSuspect.UseClosed = ForecastParams.UseClosed;
            AnalyseSuspect.UseClearOutliers = ForecastParams.UseClearOutliers;

            AnalyseSuspect.ClearOutliersWindowsWidth = ForecastParams.ClearOutliersWindowsWidth;
            AnalyseSuspect.ClearOutliersThreshold = ForecastParams.ClearOutliersThreshold;
            AnalyseSuspect.ClearOutliersReplacementMode = ForecastParams.ClearOutliersReplacementMode;

            AnalyseSuspect.UsePromo = ForecastParams.UsePromo;
            AnalyseSuspect.AdjustPromoForTask = ForecastParams.AdjustPromoForTask;
            AnalyseSuspect.UseHoliday = ForecastParams.UseHoliday;
            AnalyseSuspect.AdjustHolidayForTask = ForecastParams.AdjustHolidayForTask;

            AnalyseSuspect.ProbabilityParameters = SuspectProbabilityParameters;
            AnalyseSuspect.ThresholdParams = SuspectThresholdParams;
            
            AnalyseSuspect.ClearOutliersOnlyForSuspects = ForecastParams.ClearOutliersOnlyForSuspects;
        }

        protected async Task<IList<SuspectForecastResult>> Calculate(IList<SuspectForecastTask> tasks)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {SubBatchId}. Структура для результатов расчет, алгоритм = {AlgType} <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", JobId);

            var calculationResults = (from task in tasks
                                      from suspect in task.Suspects
                                      select new SuspectForecastResult
                                      {
                                          TaskId = suspect.Id,
                                          LocationId = task.LocationId,
                                          ProductId = task.ProductId,
                                          SuspectResults = new SortedList<DateTime, SuspectResult>(suspect.Length)
                                      }).ToList();

           
            sw.Restart();
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {SubBatchId}. TSA расчет, алгоритм = {AlgType}", JobId);

            SaveErrorSuspectsInJson(ForecastParams.NeedPreExecutionJson, AnalyseSuspect);

            AnalyseSuspect.Execute();

            await CheckFailedSuspects(AnalyseSuspect.FailedSuspects);

            SaveErrorSuspectsInJson(ForecastParams.NeedPostExecutionJson, AnalyseSuspect);

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {SubBatchId}. Перенос расчета в наши структуры, алгоритм = {AlgType} <{sw.Elapsed.ToString("mm\\:ss\\.ff")}>", JobId);
            sw.Stop();

            var phantomStruct = AnalyseSuspect.PhantomStruct;
            var t = phantomStruct.LossNumber.Where(x => x.Any(y => y > 0)).ToList();

            if (phantomStruct.Department.Count != calculationResults.Count)
                throw new Exception("phantomStruct.Department.Count != results.Count");

            for (int i = 0; i < calculationResults.Count; ++i)
            {
                var resultItem = calculationResults[i];

                if (resultItem.LocationId != phantomStruct.Department[i])
                    throw new Exception("resultsItem.LocationId != phantomStruct.Department[i]");

                if (resultItem.ProductId != phantomStruct.Item[i])
                    throw new Exception("resultsItem.ProductId != phantomStruct.Item[i]");

                var isPhantom = phantomStruct.IsPhantom[i];

                var probability = (float)phantomStruct.Prob[i];
                probability = float.IsNaN(probability) ? -1 : probability;
                probability = float.IsInfinity(probability) ? -1 : probability;

                var meanSell = (float)phantomStruct.MeanSell[i];
                meanSell = float.IsNaN(meanSell) ? -1 : meanSell;
                meanSell = float.IsInfinity(meanSell) ? -1 : meanSell;

                resultItem.IsPhantom = isPhantom;

                resultItem.Probability = probability;
                resultItem.MeanSell = meanSell;

                var dates = phantomStruct.Date[i];

                for (int j = 0; j < dates.Count; ++j)
                {
                    var lossNumber = (float)phantomStruct.LossNumber[i][j];
                    lossNumber = float.IsNaN(lossNumber) ? -1 : lossNumber;
                    lossNumber = float.IsInfinity(lossNumber) ? -1 : lossNumber;

                    var profile = (float)phantomStruct.Profile[i][j];
                    profile = float.IsNaN(profile) ? -1 : profile;
                    profile = float.IsInfinity(profile) ? -1 : profile;

                    resultItem.SuspectResults.Add(dates[j], new SuspectResult
                    {
                        LossNumber = lossNumber,
                        Profile = profile
                    });
                }
            }
            GC.Collect();
            GC.SuppressFinalize(AnalyseSuspect);
            GC.Collect();            

            return calculationResults;
        }

        protected async Task CheckFailedSuspects(List<AnalizeSuspectFailMessage> messages)
        {
            if (messages != null && messages.Count != 0)
            {
                var theme = "Ошибка при обработке подозрений";

                var text = "При обсчете подозрений в Tsa сгенерились следующие ошибки:\n\n";

                messages.ForEach(i => text += $"Description = {i.Description}, Task properties: LocationId = {i.Department}, ProductId = {i.Item}, BeginDate = {i.Begin.ToString("yyyy-M-dd HH:mm")}, Length = {i.Length}");

                await _bus.SendReceive.SendAsync(
                    nameof(QueueName.BrokerToMessenger),
                    new BrokerToMessengerMessage
                    {
                        Body = text,
                        Priority = System.Net.Mail.MailPriority.High,
                        Subject = theme
                    }
                );
            }
        }

        private void SaveErrorSuspectsInJson(bool isNeed, BaseModule module)
        {
            try
            {
                if (isNeed)
                {
                    var json = JsonSerialization.SerializeObject(module);

                    var time = DateTime.Now.ToString("yyyy-MM-dd_HH_mm_ss_ff");

                    var targetDirectory = @"F:\GFC.Services\Json";

                    File.WriteAllText(targetDirectory + $@"\json_{JobId}_{SubBatchId}_{time}.txt", json);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("", ex.Message, ex, JobId);
            }            
        }

        public async Task<IList<SuspectForecastResult>> PromoAnalize(PromoSuspectForecastBatch batch, IBus bus)
        {
            var result = new List<SuspectForecastResult>();

            var batchItems = batch.Items.ToList();

            var sales = _lostSalesAnalysisRepository.GetHourSaleDuringSuspect(
                batch.HistoryEndDate.Value.AddDays(-1),
                batch.Items.Select(i =>i.Id),
                batch.LocationId
            ).ToList();

            if (sales.Count != 0)
            {
                var resultByAvgSales = PromoCalculate(batch, sales);
                result.AddRange(resultByAvgSales);


                batchItems.RemoveAll(i => resultByAvgSales.Select(c => c.ProductId).Contains(i.ProductId));

                if (batchItems.Any())
                {
                    var resultByAvgInPromoSales = PromoCalculate(batch);

                    result.AddRange(resultByAvgInPromoSales);

                    batchItems.RemoveAll(i => resultByAvgInPromoSales.Select(c => c.ProductId).Contains(i.ProductId));
                }
            }
            return result;
        }


        public IEnumerable<SuspectForecastResult> PromoCalculate(PromoSuspectForecastBatch batch, IList<HourSaleDuringSuspect> sales)
        {
            var startHour = batch.Schedule.FirstOrDefault().Value.Start.Hours;
            var endHour = batch.Schedule.FirstOrDefault().Value.End.Hours == 0 ? 24 : batch.Schedule.FirstOrDefault().Value.End.Hours;
            var workingHoursInDay = endHour - startHour;

            var avgSales = (from s in sales.Where(i => i.Quantity >= 0)
                            group s by new { s.ProductId, s.Date, s.SuspectLocationId, s.LostSalesAnalysisTaskId, s.SimilarLocationCount }
                into grouping
                            select
                                new
                                {
                                    LocationId = grouping.Key.SuspectLocationId,
                                    TaskId = grouping.Key.LostSalesAnalysisTaskId,
                                    ProductId = grouping.Key.ProductId,
                                    Date = grouping.Key.Date,
                                    Cnt = grouping.Key.SimilarLocationCount,
                                    Quantity = grouping.Sum(i => i.Quantity) / grouping.Key.SimilarLocationCount
                                }).GroupBy(i => new { TaskId = i.TaskId, LocationId = i.LocationId, ProductId = i.ProductId })
                .ToDictionary(i => i.Key, j => j.ToDictionary(k => k.Date, v => v.Quantity));

            foreach (var key in avgSales.Keys)
            {
                var prodSuspect =
                    batch.Items.FirstOrDefault(i => i.ProductId == key.ProductId);

                for (DateTime h = prodSuspect.StartDate; h < prodSuspect.EndDate; h = h.AddHours(1))
                {
                    var isNullSale = avgSales[key].Keys.All(i => i != h);

                    var isWorkingHour = h.Hour >= startHour && h.Hour < endHour;

                    if (isNullSale && isWorkingHour)
                    {
                        avgSales[key].Add(h, 0);
                    }
                    else if (!isNullSale && !isWorkingHour)
                    {
                        avgSales[key].Remove(h);
                    }
                }
            }

            var result =
                avgSales.Where(i => i.Value.Keys.Count >= workingHoursInDay && i.Value.Values.Sum(c => c) > 0).Select(
                    i =>
                        new SuspectForecastResult()
                        {
                            IsPhantom = true,
                            Probability = 1,
                            LocationId = batch.LocationId,
                            ProductId = i.Key.ProductId,
                            TaskId = i.Key.TaskId,
                            MeanSell = i.Value.Values.Sum(quantity => quantity),
                            SuspectResults = i.Value.ToSortedList()
                        }).ToList();

            return result;
        }


        public IEnumerable<SuspectForecastResult> PromoCalculate(PromoSuspectForecastBatch batch)
        {
            var result = new List<SuspectForecastResult>();

            var sales = _lostSalesAnalysisRepository.GetHourSaleDuringSuspect(
                batch.HistoryEndDate.Value.AddDays(-1),
               batch.Items.Select(i => i.Id).ToList()
            ).ToList();


            var startHour = batch.Schedule.FirstOrDefault().Value.Start.Hours;
            var endHour = batch.Schedule.FirstOrDefault().Value.End.Hours == 0 ? 24 : batch.Schedule.FirstOrDefault().Value.End.Hours;

            var avgSales = (from s in sales.Where(i => i.Quantity > 0)
                            group s by new { s.LocationId, s.ProductId, SaleHour = s.Date.Hour, s.TaskId, s.TaskStart, s.TaskEnd }
                into grouping
                            select
                                new
                                {
                                    grouping.Key.LocationId,
                                    grouping.Key.ProductId,
                                    grouping.Key.SaleHour,
                                    grouping.Key.TaskId,
                                    grouping.Key.TaskStart,
                                    grouping.Key.TaskEnd,
                                    Quantity = grouping.Sum(c => c.Quantity) / grouping.Count()
                                }).GroupBy(i => new { i.LocationId, i.ProductId, i.SaleHour, i.TaskId, i.TaskStart, i.TaskEnd })
                .ToDictionary(k => k.Key, v => v.ToDictionary(i => i.SaleHour, j => j.Quantity));

            var salesByTask = avgSales.GroupBy(s => s.Key.TaskId).ToDictionary(k => k.Key, v => v.ToList());


            var t = salesByTask.Where(x => x.Key == 1608673).ToList();

            foreach (var sale in salesByTask)
            {
                var avgKey = sale.Value.FirstOrDefault().Key;

                var suspectResult = new SuspectForecastResult();
                suspectResult.IsPhantom = true;
                suspectResult.LocationId = avgKey.LocationId;
                suspectResult.Probability = 1;
                suspectResult.ProductId = avgKey.ProductId;
                suspectResult.TaskId = avgKey.TaskId;
                suspectResult.SuspectResults = new SortedList<DateTime, SuspectResult>();

                foreach (var key in sale.Value.Select(x => x.Key))
                {
                    for (DateTime date = key.TaskStart; date <= key.TaskEnd; date = date.AddHours(1))
                    {
                        var saleForSuspect = avgSales[key];

                        var isNullSale = saleForSuspect.Keys.All(i => i != date.Hour);

                        var isWorkingHour = date.Hour >= startHour && date.Hour < endHour;

                        if (isNullSale && isWorkingHour)
                        {
                            if(!suspectResult.SuspectResults.ContainsKey(date))
                                suspectResult.SuspectResults.Add(date, new SuspectResult() { LossNumber = 0, Profile = 0 });
                        }
                        else if (!isNullSale && isWorkingHour)
                        {
                            if (!suspectResult.SuspectResults.ContainsKey(date))
                                suspectResult.SuspectResults.Add(date, new SuspectResult() { LossNumber = saleForSuspect[date.Hour], Profile = 0 });
                            else
                                suspectResult.SuspectResults[date] = new SuspectResult() { LossNumber = saleForSuspect[date.Hour], Profile = 0 };
                        }
                    }
                }

                suspectResult.MeanSell = suspectResult.SuspectResults.Values.Sum(i => i.LossNumber);
                result.Add(suspectResult);
            }

            return result;
        }

    }
}
