﻿using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Сохранение результатов расчета
    /// </summary>
    public interface ITaskResultService
    {
        Task SaveResults(long jobId, IEnumerable<SuspectForecastResult> results);
    }
}
