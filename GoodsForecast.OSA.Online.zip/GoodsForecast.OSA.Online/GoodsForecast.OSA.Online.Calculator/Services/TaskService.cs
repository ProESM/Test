﻿using GoodsForecast.OSA.Online.Calculator.QueueHandlers;
using GoodsForecast.OSA.Online.Calculator.Repositories;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Series;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Получение и предобработка данных для задач на расчет
    /// </summary>
    public class TaskService:ITaskService
    {
        /// <summary>
        /// Если вдруг в базе нет 
        /// Глубина истории по умолчанию
        /// </summary>
        private const int DefaultHistoryLength = 91;

        private readonly OsaLogger<CalculatorQueueHandler> _logger;
        private readonly ILostSalesAnalysisRepository _lostSalesAnalysisRepository;

        public TaskService(OsaLogger<CalculatorQueueHandler> logger, ILostSalesAnalysisRepository lostSalesAnalysisRepository)
        {
            _logger = logger;
            _lostSalesAnalysisRepository = lostSalesAnalysisRepository;
        }

        private List<SuspectForecastTask> Tasks { get; set; }
        private AlgType AlgType { get; set; }
        private int LocationId { get; set; }
        private int? StoreGroupId { get; set; }
        private IList<int> ProductIds { get; set; }
        private DateTime HistoryStartDate { get; set; }
        private DateTime HistoryEndDate { get; set; }
        private Dictionary<SuspectPair, List<DateTime>> CurrentAssortmentMatrix { get; set; }
        private int TimeZoneId { get; set; }
        private List<RelatedStore> RelatedStores { get; set; }
        private Dictionary<(int, int), List<DateTime>> RelatedStartDates { get; set; }

        /// <summary>
        /// Получить параметры для математического алгоритма
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        public async Task<LostSalesAnalysisParamViewModel> GetForecastParams(long jobId, int storeId, int productId)
        {
            return await _lostSalesAnalysisRepository.GetForecastParams(jobId, storeId, productId);
        }

        public async Task<IEnumerable<SuspectForecastTask>> GetTasks(SuspectForecastBatch batch)
        {
            await InitializeProperties(batch);

            await GenerateTasks(batch);

            return Tasks;
        }

        private async Task InitializeProperties(SuspectForecastBatch batch)
        {
            TimeZoneId = await _lostSalesAnalysisRepository.GetTimeZone(batch.JobId);

            HistoryEndDate = batch.HistoryEndDate.HasValue ? batch.HistoryEndDate.Value : DateTime.UtcNow.AddHours(TimeZoneId).Date;
            HistoryEndDate = HistoryEndDate.AddMinutes(-HistoryEndDate.Minute);

            var item = batch.Items.First();

            if(!Int32.TryParse(await _lostSalesAnalysisRepository.GetParam(batch.JobId, "HistoryLength", item.LocationId, item.ProductId), out var historyLength))
                throw new Exception("Параметр HistoryLength не задан или имеет неверный формат!");

            HistoryStartDate = batch.HistoryStartDate.HasValue
                ? batch.HistoryStartDate.Value
                : HistoryEndDate.AddDays(-historyLength);
            HistoryStartDate = HistoryStartDate.AddMinutes(-HistoryStartDate.Minute);

            LocationId = batch.LocationId;

            AlgType = batch.AlgType;

            ProductIds = batch.Items.Select(t => t.ProductId).ToList();

            Tasks = batch.Items.Select(t => new SuspectForecastTask()
            {
                LocationId = t.LocationId,
                Schedule = t.Schedule,
                ProductId = t.ProductId,
                Suspects = t.Suspects,
            }).ToList();

            if(AlgType == AlgType.ByCluster)
            {
                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение связанных магазинов из матрицы.", batch.JobId);

                var productsPeriods = Tasks.SelectMany(t => t.Suspects.Select(s => new { t.ProductId, s.StartDate, s.EndDate }))
                                    .ToDictionary(k => (k.ProductId, k.StartDate), v => new DatePeriod { StartDate = v.StartDate, EndDate = v.EndDate });


                RelatedStores = await _lostSalesAnalysisRepository.GetRelatedStoreProducts(LocationId, productsPeriods, HistoryEndDate.Date);

                RelatedStartDates = RelatedStores.GroupBy(x => new { x.LocationId, x.ProductId}).ToDictionary(k => (k.Key.LocationId, k.Key.ProductId), v => v.Select(x => x.StartDateTime).ToList());

                RelatedStores.ForEach(s =>
                {
                    var schedule = new Dictionary<DayOfWeek, TimePeriod>();

                    for (var id = 0; id < 7; id++)
                    {
                        schedule.Add((DayOfWeek)id,
                            new TimePeriod()
                            {
                                Start = s.OpenTime,
                                End = s.CloseTime
                            });
                    }

                    s.Schedule = schedule;
                });


                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получены связанные магазины из матрицы.", batch.JobId);
            }
        }


        private async Task GenerateTasks(SuspectForecastBatch batch)
        {
            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение продаж.", batch.JobId);

            await SetSales();

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение остатков.", batch.JobId);

            await SetStocks();

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение промоакций.", batch.JobId);

            await SetPromotions();

            _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение праздников.", batch.JobId);

            SetHolidayPeriods();

            if (AlgType == AlgType.ByCluster)
            {
                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение продаж по связанным магазинам.", batch.JobId);
                await SetRelatedStoresSales();

                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение остатков по связанным магазинам.", batch.JobId);
                await SetRelatedStoresStocks();

                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение промоакций по связанным магазинам.", batch.JobId);
                await SetRelatedStoresPromotions();

                _logger.LogInformation(Environment.MachineName, $"SubBatchId = {batch.SubBatchId}. Получение праздников по связанным магазинам.", batch.JobId);
                SetRelatedStoresHolidayPeriods();

                Tasks.ForEach(t => t.RelatedStores = RelatedStores);
            }
        }

        /// <summary>
        /// Получение продаж
        /// </summary>
        /// <returns></returns>
        private async Task SetSales()
        {
            IDictionary<SuspectPair, ProductSaleSeries> sales;            

            var hourSales = await _lostSalesAnalysisRepository.GetSalesForSeries(LocationId, ProductIds, HistoryStartDate, HistoryEndDate);
            if (hourSales != null)
            {
                sales = hourSales.GroupBy(t => new SuspectPair(t.ProductId, null, t.OpenTime?.Hours, t.CloseTime?.Hours))
                    .ToDictionary(x => x.Key, g => g.ToDictionary(d => d.Datetime, q => q.Quantity))
                    .ToDictionary(sales => sales.Key,
                        sales => ToProductSaleSeries(sales.Value, sales.Key.OpenTime, sales.Key.CloseTime, HistoryStartDate, HistoryEndDate));
            }
            else
            {
                sales = new Dictionary<SuspectPair, ProductSaleSeries>();
            }

            foreach (var task in Tasks)
            {
                var openTime = task.Schedule.FirstOrDefault().Value.Start.Hours;
                var closeTime = task.Schedule.FirstOrDefault().Value.End.Hours;
                closeTime = closeTime == 0 ? 24 : closeTime;

                var suspectPair = new SuspectPair(task.ProductId, null, openTime, closeTime);
                if (sales.ContainsKey(suspectPair))
                {
                    task.Sales = sales[suspectPair];

                    //FillSaleSeriesByNanValueWithouAssortment(ref series, suspectPair);                            
                }
                else
                {
                    var dayCount = Convert.ToInt32((HistoryEndDate.Date - HistoryStartDate.Date).TotalDays);
                    var ln = dayCount * 24;
                    
                    var saleValues = new float[ln];
                    int idx = 0;

                    for (var tmpDate = HistoryStartDate; tmpDate < HistoryEndDate; tmpDate = tmpDate.AddHours(1))
                    {
                        //if (tmpDate.Hour >= openTime &&
                        //    tmpDate.Hour < closeTime)
                        //{                                                       
                            saleValues[idx] += 0;
                            idx++;
                        //}
                    }

                    task.Sales = new ProductSaleSeries()
                    {
                        StartDate = HistoryStartDate,
                        EndDate = HistoryEndDate,
                        Step = new TimeSpan(0, 1, 0, 0),
                        Values = saleValues
                    };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(hourSales);
            GC.Collect();
        }

        /// <summary>
        /// Получение продаж по связанным магазинам из того же кластера
        /// </summary>
        /// <returns></returns>
        private async Task SetRelatedStoresSales()
        {
            IDictionary<SuspectPair, List<ProductSaleSeries>> sales;

            var hourSales = await _lostSalesAnalysisRepository.GetRelatedStoresSalesForSeries(RelatedStores, HistoryStartDate);
            if (hourSales != null)
            {
                sales = hourSales.GroupBy(t => new SuspectPair(t.ProductId, t.LocationId, t.OpenTime?.Hours, t.CloseTime?.Hours))
                    .ToDictionary(x => x.Key, g => g.ToDictionary(d => d.Datetime, q => q.Quantity))
                    .ToDictionary(sales => sales.Key,
                        sales => RelatedStartDates.ContainsKey((sales.Key.LocationId.Value, sales.Key.ProductId)) ?
                                                    RelatedStartDates[(sales.Key.LocationId.Value, sales.Key.ProductId)].Select(d => ToProductSaleSeries(sales.Value, 
                                                    sales.Key.OpenTime, 
                                                    sales.Key.CloseTime,
                                                    sales.Key.LocationId.HasValue && RelatedStartDates.ContainsKey((sales.Key.LocationId.Value, sales.Key.ProductId)) 
                                                        ? d
                                                        : HistoryStartDate, 
                                                    HistoryEndDate
                                                    )).ToList() :
                                                    new List<ProductSaleSeries> {ToProductSaleSeries(sales.Value,
                                                    sales.Key.OpenTime,
                                                    sales.Key.CloseTime,
                                                    HistoryStartDate,
                                                    HistoryEndDate
                                                    ) });
            }
            else
            {
                sales = new Dictionary<SuspectPair, List<ProductSaleSeries>>();
            }

            foreach (var task in RelatedStores)
            {
                var openTime = task.Schedule.FirstOrDefault().Value.Start.Hours;
                var closeTime = task.Schedule.FirstOrDefault().Value.End.Hours;
                closeTime = closeTime == 0 ? 24 : closeTime;

                var suspectPair = new SuspectPair(task.ProductId, task.LocationId, openTime, closeTime);
                if (sales.ContainsKey(suspectPair))
                {
                    task.Sales = sales[suspectPair];

                    //FillSaleSeriesByNanValueWithouAssortment(ref series, suspectPair);                            
                }
                else
                {
                    var hourCount = Convert.ToInt32((HistoryEndDate - task.StartDateTime.Date).TotalHours);
                    var ln = hourCount;

                    var saleValues = new float[ln];
                    int idx = 0;

                    for (var tmpDate = task.StartDateTime.Date; tmpDate < HistoryEndDate; tmpDate = tmpDate.AddHours(1))
                    {
                        //if (tmpDate.Hour >= openTime &&
                        //    tmpDate.Hour < closeTime)
                        //{                                                       
                        saleValues[idx] += 0;
                        idx++;
                        //}
                    }

                    task.Sales = new List<ProductSaleSeries> { new ProductSaleSeries
                    {
                        StartDate = task.StartDateTime.Date,
                        EndDate = HistoryEndDate,
                        Step = new TimeSpan(0, 1, 0, 0),
                        Values = saleValues
                    } };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(hourSales);
            GC.Collect();
        }

        /// <summary>
        /// Получение остатков
        /// </summary>
        /// <returns></returns>
        private async Task SetStocks()
        {
            IDictionary<int, ProductStockSeries> stocks;

            var hourStocks = await _lostSalesAnalysisRepository.GetStocksForSeries(LocationId, ProductIds, HistoryStartDate.Date, HistoryEndDate.Date);
            if (hourStocks != null)
            {
                stocks = hourStocks.GroupBy(t => t.ProductId)
                            .ToDictionary(x => x.Key, g => g.ToDictionary(d => d.Datetime, q => q.Quantity))
                            .ToDictionary(sales => sales.Key,
                                sales => ToProductStockSeries(sales.Value, HistoryStartDate.Date, HistoryEndDate.Date));
            }
            else
            {
                stocks = new Dictionary<int, ProductStockSeries>();
            }

            foreach (var task in Tasks)
            {
                if (stocks.ContainsKey(task.ProductId))
                {
                    task.Stocks = stocks[task.ProductId];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - HistoryStartDate.Date).TotalDays);

                    var stockValues = new float[ln];
                    int idx = 0;

                    for (var tmpDate = HistoryStartDate.Date; tmpDate < HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        stockValues[idx] += 0;
                        idx++;
                    }

                    task.Stocks = new ProductStockSeries()
                    {
                        StartDate = HistoryStartDate.Date,
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = stockValues
                    };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(hourStocks);
            GC.Collect();
        }

        /// <summary>
        /// Получение остатков по связанным магазинам из того же кластера
        /// </summary>
        /// <returns></returns>
        private async Task SetRelatedStoresStocks()
        {
            IDictionary<SuspectPair, List<ProductStockSeries>> stocks;

            var hourStocks = await _lostSalesAnalysisRepository.GetRelatedStoresStocksForSeries(RelatedStores, HistoryStartDate.Date);
            if (hourStocks != null)
            {
                stocks = hourStocks.GroupBy(t => new SuspectPair(t.ProductId, t.LocationId))
                            .ToDictionary(x => x.Key, g => g.ToDictionary(d => d.Datetime, q => q.Quantity))
                            .ToDictionary(sales => sales.Key,
                                sales => RelatedStartDates.ContainsKey((sales.Key.LocationId.Value, sales.Key.ProductId)) ?
                                        RelatedStartDates[(sales.Key.LocationId.Value, sales.Key.ProductId)].Select(x => ToProductStockSeries(sales.Value,
                                        sales.Key.LocationId.HasValue && RelatedStartDates.ContainsKey((sales.Key.LocationId.Value, sales.Key.ProductId))
                                            ? x.AddDays(-1)
                                            : HistoryStartDate.Date, 
                                        HistoryEndDate.Date)).ToList() :
                                        new List<ProductStockSeries> {ToProductStockSeries(sales.Value,
                                        HistoryStartDate.Date,
                                        HistoryEndDate.Date) });
            }
            else
            {
                stocks = new Dictionary<SuspectPair, List<ProductStockSeries>>();
            }

            foreach (var task in RelatedStores)
            {
                var suspectPair = new SuspectPair(task.ProductId, task.LocationId);
                if (stocks.ContainsKey(suspectPair))
                {
                    task.Stocks = stocks[suspectPair];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - task.StartDateTime.Date.AddDays(-1)).TotalDays);

                    var stockValues = new float[ln];
                    int idx = 0;

                    for (var tmpDate = task.StartDateTime.Date.AddDays(-1); tmpDate < HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        stockValues[idx] += 0;
                        idx++;
                    }

                    task.Stocks = new List<ProductStockSeries> { new ProductStockSeries
                    {
                        StartDate = task.StartDateTime.Date.AddDays(-1),
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = stockValues
                    } };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(hourStocks);
            GC.Collect();
        }

        /// <summary>
        /// Получение промоакций
        /// </summary>
        /// <returns></returns>
        private async Task SetPromotions()
        {
            Dictionary<int, PromotionSeries> promo;

            var promotions = await _lostSalesAnalysisRepository.GetPromotionsForSeries(LocationId, ProductIds, HistoryStartDate.Date, HistoryEndDate.Date);
            if (promotions != null)
            {
                promo =
                    promotions.GroupBy(j => j.ProductId)
                        .ToDictionary(k => k.Key, h => h.Select(i => i))
                        .ToDictionary(k => k.Key,
                            v => ToPromotionSeries(v.Value, HistoryStartDate.Date, HistoryEndDate.Date));
            }
            else
            {
                promo = new Dictionary<int, PromotionSeries>();
            }

            foreach (var task in Tasks)
            {
                if (promo.ContainsKey(task.ProductId))
                {
                    task.Promotions = promo[task.ProductId];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - HistoryStartDate.Date).TotalDays) + 1;

                    var values = new long[ln];
                    int idx = 0;

                    for (var tmpDate = HistoryStartDate.Date; tmpDate <= HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        values[idx] += 0;
                        idx++;
                    }

                    task.Promotions = new PromotionSeries()
                    {
                        StartDate = HistoryStartDate.Date,
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = values
                    };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(promotions);
            GC.Collect();

        }

        /// <summary>
        /// Получение промоакций по связанным магазинам из того же кластера
        /// </summary>
        /// <returns></returns>
        private async Task SetRelatedStoresPromotions()
        {
            Dictionary<SuspectPair, List<PromotionSeries>> promo;

            var promotions = await _lostSalesAnalysisRepository.GetRelatedStoresPromotionsForSeries(RelatedStores);
            if (promotions != null)
            {
                promo =
                    promotions.GroupBy(j => new SuspectPair(j.ProductId, j.LocationId))
                        .ToDictionary(k => k.Key, h => h.Select(i => i))
                        .ToDictionary(k => k.Key,
                            v => RelatedStartDates.ContainsKey((v.Key.LocationId.Value, v.Key.ProductId)) ?
                                        RelatedStartDates[(v.Key.LocationId.Value, v.Key.ProductId)].Select(x => ToPromotionSeries(v.Value, 
                                        v.Key.LocationId.HasValue
                                            ? x
                                            : HistoryStartDate.Date, 
                                         HistoryEndDate.Date)).ToList() :
                                         new List<PromotionSeries>() {ToPromotionSeries(v.Value,
                                            HistoryStartDate.Date,
                                            HistoryEndDate.Date) });
            }
            else
            {
                promo = new Dictionary<SuspectPair, List<PromotionSeries>>();
            }

            foreach (var task in RelatedStores)
            {
                var suspectPair = new SuspectPair(task.ProductId, task.LocationId);
                if (promo.ContainsKey(suspectPair))
                {
                    task.Promotions = promo[suspectPair];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - task.StartDateTime.Date).TotalDays) + 1;

                    var values = new long[ln];
                    int idx = 0;

                    for (var tmpDate = task.StartDateTime.Date; tmpDate <= HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        values[idx] += 0;
                        idx++;
                    }

                    task.Promotions = new List<PromotionSeries> { new PromotionSeries
                    {
                        StartDate = task.StartDateTime.Date,
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = values
                    } };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(promotions);
            GC.Collect();

        }

        /// <summary>
        /// Получение праздников
        /// </summary>
        private void SetHolidayPeriods()
        {
            Dictionary<int, HolidayPeriodSeries> holidays;

            var holidayPeriodViewModels = _lostSalesAnalysisRepository.GetHolidayPeriodForSeries(LocationId, ProductIds, HistoryStartDate.Date, HistoryEndDate.Date);
            if (holidayPeriodViewModels != null)
            {
                holidays =
                    holidayPeriodViewModels.GroupBy(j => j.ProductId)
                        .ToDictionary(k => k.Key, h => h.Select(i => i))
                        .ToDictionary(k => k.Key,
                            v => ToHolidayPeriodSeries(v.Value, HistoryStartDate.Date, HistoryEndDate.Date));
            }
            else
            {
                holidays = new Dictionary<int, HolidayPeriodSeries>();
            }

            foreach (var task in Tasks)
            {
                if (holidays.ContainsKey(task.ProductId))
                {
                    task.HolidayPeriods = holidays[task.ProductId];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - HistoryStartDate.Date).TotalDays) + 1;

                    var values = new long[ln];
                    int idx = 0;

                    for (var tmpDate = HistoryStartDate.Date; tmpDate <= HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        values[idx] += 0;
                        idx++;
                    }

                    task.HolidayPeriods = new HolidayPeriodSeries()
                    {
                        StartDate = HistoryStartDate.Date,
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = values
                    };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(holidayPeriodViewModels);
            GC.Collect();
        }

        /// <summary>
        /// Получение праздников по связанным магазинам из того же кластера
        /// </summary>
        private void SetRelatedStoresHolidayPeriods()
        {
            Dictionary<SuspectPair, List<HolidayPeriodSeries>> holidays;

            var holidayPeriodViewModels = _lostSalesAnalysisRepository.GetRelatedStoresHolidayPeriodForSeries(RelatedStores);
            if (holidayPeriodViewModels != null)
            {
                holidays =
                    holidayPeriodViewModels.GroupBy(j => new SuspectPair(j.ProductId, j.LocationId))
                        .ToDictionary(k => k.Key, h => h.Select(i => i))
                        .ToDictionary(k => k.Key,
                            v => RelatedStartDates.ContainsKey((v.Key.LocationId.Value, v.Key.ProductId)) ?
                                            RelatedStartDates[(v.Key.LocationId.Value, v.Key.ProductId)].Select(x =>ToHolidayPeriodSeries(v.Value, 
                                            x,
                                            HistoryEndDate)).ToList() :
                                            new List<HolidayPeriodSeries>() { ToHolidayPeriodSeries(v.Value,
                                            HistoryStartDate.Date,
                                            HistoryEndDate) });
            }
            else
            {
                holidays = new Dictionary<SuspectPair, List<HolidayPeriodSeries>>();
            }

            foreach (var task in RelatedStores)
            {
                var suspectPair = new SuspectPair(task.ProductId, task.LocationId);
                if (holidays.ContainsKey(suspectPair))
                {
                    task.HolidayPeriods = holidays[suspectPair];
                }
                else
                {
                    var ln = Convert.ToInt32((HistoryEndDate.Date - task.StartDateTime.Date).TotalDays) + 1;

                    var values = new long[ln];
                    int idx = 0;

                    for (var tmpDate = task.StartDateTime.Date; tmpDate <= HistoryEndDate.Date; tmpDate = tmpDate.AddDays(1))
                    {
                        values[idx] += 0;
                        idx++;
                    }

                    task.HolidayPeriods = new List<HolidayPeriodSeries> { new HolidayPeriodSeries
                    {
                        StartDate = task.StartDateTime.Date,
                        EndDate = HistoryEndDate.Date,
                        Step = new TimeSpan(1, 0, 0, 0),
                        Values = values
                    } };
                }
            }

            GC.Collect();
            GC.SuppressFinalize(holidayPeriodViewModels);
            GC.Collect();
        }

        private ProductSaleSeries ToProductSaleSeries(IDictionary<DateTime, float?> sales, int? openTime, int? closeTime, DateTime historyStartDate, DateTime historyEndDate)
        {
            var openHour = openTime ?? 0;
            var closeHour = closeTime ?? 0;
            closeHour = closeHour == 0 ? 24 : closeHour;
            var hourCount = Convert.ToInt32((historyEndDate - historyStartDate).TotalHours);
            var ln = hourCount;

            var saleValues = new float[ln];
            int idx = 0;

            if (!sales.Any(t => t.Value > 0))
            {
                for (var tmpDate = historyStartDate; tmpDate < historyEndDate; tmpDate = tmpDate.AddHours(1))
                {
                    //if (tmpDate.Hour >= openHour &&
                    //    tmpDate.Hour < closeHour)
                    //{
                    saleValues[idx] = 0;
                    idx++;
                    //}
                }

                return new ProductSaleSeries
                {
                    StartDate = historyStartDate,
                    EndDate = historyEndDate,
                    Step = new TimeSpan(0, 1, 0, 0),
                    Values = saleValues
                };
            }

            for (var tmpDate = historyStartDate; tmpDate < historyEndDate; tmpDate = tmpDate.AddHours(1))
            {
                //if (tmpDate.Hour >= openHour &&
                //    tmpDate.Hour < closeHour)
                //{
                if (sales.ContainsKey(tmpDate)
                        && tmpDate.Hour >= openHour
                        && tmpDate.Hour < closeHour
                    )
                {
                    saleValues[idx] += sales[tmpDate] ?? 0;
                }
                else
                {
                    saleValues[idx] = 0;
                }
                idx++;
                //}
            }

            var saleSeries = new ProductSaleSeries
            {
                StartDate = historyStartDate,
                EndDate = historyEndDate,
                Step = new TimeSpan(0, 1, 0, 0),
                Values = saleValues,
            };
            

            return saleSeries;
        }
        private ProductStockSeries ToProductStockSeries(IDictionary<DateTime, float?> stocks, DateTime historyStartDate, DateTime historyEndDate)
        {

            var ln = Convert.ToInt32((historyEndDate.Date - historyStartDate.Date).TotalDays);
            var stockValues = new float[ln];
            int idx = 0;

            if (!stocks.Any(t => t.Value > 0))
            {
                for (var tmpDate = historyStartDate; tmpDate < historyEndDate; tmpDate = tmpDate.AddDays(1))
                {
                    stockValues[idx] = 0;
                    idx++;                    
                }

                return new ProductStockSeries
                {
                    StartDate = historyStartDate.Date,
                    EndDate = historyEndDate.Date,
                    Step = new TimeSpan(1, 0, 0, 0),
                    Values = stockValues
                };
            }

            for (var tmpDate = historyStartDate; tmpDate < historyEndDate; tmpDate = tmpDate.AddDays(1))
            {
                if (stocks.ContainsKey(tmpDate))
                {
                    stockValues[idx] += stocks[tmpDate] ?? 0;
                }
                else
                {
                    stockValues[idx] = 0;
                }
                idx++;
              
            }

            var stockSeries = new ProductStockSeries
            {
                StartDate = historyStartDate.Date,
                EndDate = historyEndDate.Date,
                Step = new TimeSpan(1, 0, 0, 0),
                Values = stockValues,
            };

            return stockSeries;
        }
        private PromotionSeries ToPromotionSeries(IEnumerable<PromotionMatrixViewModel> promos, DateTime historyStartDate, DateTime historyEndDate)
        {
            var ln = Convert.ToInt32((historyEndDate.Date - historyStartDate.Date).TotalDays) + 1;
            var values = new long[ln];
            int idx = 0;

            if (promos == null || !promos.Any() || promos.FirstOrDefault() == null)
            {
                for (var tmpDate = historyStartDate; tmpDate <= historyEndDate; tmpDate = tmpDate.AddDays(1))
                {
                    values[idx] = 0;
                    idx++;
                }
                return new PromotionSeries()
                {
                    StartDate = historyStartDate.Date,
                    EndDate = historyEndDate.Date,
                    Step = new TimeSpan(1, 0, 0, 0),
                    Values = values
                };
            }


            for (DateTime i = historyStartDate; i <= historyEndDate; i = i.AddDays(1))
            {
                var isPromoDay = promos.Any(k => k.StartDate <= i && k.EndDate >= i);

                values[idx] = Convert.ToInt32(isPromoDay);

                idx++;
            }

            var series = new PromotionSeries()
            {
                StartDate = historyStartDate.Date,
                EndDate = historyEndDate.Date,
                Step = new TimeSpan(1, 0, 0, 0),
                Values = values
            };

            return series;
        }
        private HolidayPeriodSeries ToHolidayPeriodSeries(IEnumerable<HolidayPeriodMatrixViewModel> holidayPeriods, DateTime historyStartDate, DateTime historyEndDate)
        {
            var ln = Convert.ToInt32((historyEndDate.Date - historyStartDate.Date).TotalDays) + 1;
            var values = new long[ln];
            int idx = 0;

            if (holidayPeriods == null || !holidayPeriods.Any() || holidayPeriods.FirstOrDefault() == null)
            {
                for (var tmpDate = historyStartDate; tmpDate <= historyEndDate; tmpDate = tmpDate.AddDays(1))
                {
                    values[idx] = 0;
                    idx++;
                }
                return new HolidayPeriodSeries()
                {
                    StartDate = historyStartDate.Date,
                    EndDate = historyEndDate.Date,
                    Step = new TimeSpan(0, 1, 0, 0),
                    Values = values
                };
            }

            for (DateTime i = historyStartDate; i <= historyEndDate; i = i.AddDays(1))
            {
                var isPromoDay = holidayPeriods.Any(k => k.StartDate <= i && k.EndDate >= i);

                values[idx] = Convert.ToInt32(isPromoDay);

                idx++;
            }

            var series = new HolidayPeriodSeries()
            {
                StartDate = historyStartDate.Date,
                EndDate = historyEndDate.Date,
                Step = new TimeSpan(1, 0, 0, 0),
                Values = values
            };

            return series;
        }

        /// <summary>
        /// Заполнить отсутствующие в матрице дни нулями
        /// </summary>
        /// <param name="series"></param>
        /// <param name="suspectPair"></param>
        /// <param name="needPeriodYearAgo"></param>
        protected void FillSaleSeriesByNanValueWithouAssortment(ref ProductSaleSeries series, SuspectPair suspectPair)
        {
            var assortment = CurrentAssortmentMatrix[suspectPair];

            if (assortment != null && assortment.Any())
            {
                var salesValues = series.Values.ToArray();

                for (var tmpDate = series.StartDate.Date;
                    tmpDate < series.EndDate;
                    tmpDate = tmpDate.AddDays(1))
                {

                    var idx = Convert.ToInt32((tmpDate - series.StartDate.Date).TotalDays);

                    if (assortment.All(t => t != tmpDate))
                    {
                        for (var i = idx * 24; i < (idx + 1) * 24; i++)
                        {
                            salesValues[i] = 0;
                        }
                    }
                }

                series.Values = salesValues;
            }
        }
    }
}
