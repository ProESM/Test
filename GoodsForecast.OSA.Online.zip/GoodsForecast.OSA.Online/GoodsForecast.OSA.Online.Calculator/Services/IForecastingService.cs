﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Расчет сигналов и упущенных продаж в TSA
    /// - преобразование входных данных, 
    /// - запуск расчета, 
    /// - преобразование выходных данных
    /// </summary>
    public interface IForecastingService
    {
        Task<IEnumerable<SuspectForecastResult>> Analize(
            IEnumerable<SuspectForecastTask> tasks,
            LostSalesAnalysisParamViewModel forecastParams,
            long jobId,
            long subBatchId,
            AlgType algType);

        Task<IList<SuspectForecastResult>> PromoAnalize(PromoSuspectForecastBatch batch, IBus bus);
    }
}
