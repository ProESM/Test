﻿using GoodsForecast.OSA.Online.Calculator.QueueHandlers;
using GoodsForecast.OSA.Online.Calculator.Repositories;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Forecasting.Result;
using GoodsForecast.OSA.Online.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Сохранение результатов расчета
    /// </summary>
    public class TaskResultService: ITaskResultService
    {
        private readonly OsaLogger<CalculatorQueueHandler> _logger;
        private readonly ILostSalesAnalysisRepository _lostSalesAnalysisRepository;
        private int TimeZoneId { get; set; }

        public TaskResultService(OsaLogger<CalculatorQueueHandler> logger, ILostSalesAnalysisRepository lostSalesAnalysisRepository)
        {
            _logger = logger;
            _lostSalesAnalysisRepository = lostSalesAnalysisRepository;
        }


        public async Task SaveResults(long jobId, IEnumerable<SuspectForecastResult> results)
        {
            var timeout = TimeSpan.FromMinutes(30);

            try
            {
                TimeZoneId = await _lostSalesAnalysisRepository.GetTimeZone(jobId);

                _logger.LogInformation(Environment.MachineName, $"Сохраняем результаты (часы)", jobId);

                var hourlyResultsData =
                results.SelectMany(q => q.SuspectResults.Select(w => new LostSalesAnalysisResultHourly
                {
                    Datetime = w.Key,
                    Created = DateTime.UtcNow.AddHours(TimeZoneId),
                    LocationId = q.LocationId,
                    Probability = !float.IsNaN(q.Probability) ? (float?)q.Probability : null,
                    ProductId = q.ProductId,
                    Quantity = !float.IsNaN(w.Value.LossNumber) ? (float?)w.Value.LossNumber : null,
                    LostSalesAnalysisJobId = jobId,
                    LostSalesAnalysisTaskId = q.TaskId,
                    IsPhantom = q.IsPhantom,
                    IsCalculatedInTsa = q.IsCalculatedInTsa
                })).ToList();
                _lostSalesAnalysisRepository.SaveMultiple<LostSalesAnalysisResultHourly>(hourlyResultsData);
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при сохранении результатов (часы) для JobId = {jobId}", ex);
            }

            try
            {
                _logger.LogInformation(Environment.MachineName, $"Сохраняем результаты (периоды)", jobId);
                var periodResultsData = results.Select(q => new LostSalesAnalysisResultPeriod
                {
                    StartDatetime = q.SuspectResults.Min(t => t.Key),
                    EndDatetime = q.SuspectResults.Max(t => t.Key),
                    Created = DateTime.UtcNow.AddHours(TimeZoneId),
                    LocationId = q.LocationId,
                    Probability = !float.IsNaN(q.Probability) ? (float?)q.Probability : null,
                    ProductId = q.ProductId,
                    LostSalesAnalysisJobId = jobId,
                    LostSalesAnalysisTaskId = q.TaskId,
                    HoursCount = (short)q.SuspectResults.Count,
                    Quantity =
                        q.SuspectResults.Sum(t => !float.IsNaN(t.Value.LossNumber) ? (float?)t.Value.LossNumber : null),
                    IsPhantom = q.IsPhantom
                }).ToList();
                _lostSalesAnalysisRepository.SaveMultiple<LostSalesAnalysisResultPeriod>(periodResultsData);
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка при сохранении результатов (периоды)", ex);
            }

            GC.Collect();
            GC.SuppressFinalize(results);
            GC.Collect();

            _logger.LogInformation(Environment.MachineName, $"Сохраняем результаты для джоба", jobId);

        }
    }
}
