﻿using GoodsForecast.OSA.Online.Common.Forecasting;
using GoodsForecast.OSA.Online.Common.Forecasting.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Calculator.Services
{
    /// <summary>
    /// Получение и предобработка данных для задач на расчет
    /// </summary>
    public interface ITaskService
    {
        /// <summary>
        /// Получить параметры для математического алгоритма
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns></returns>
        Task<LostSalesAnalysisParamViewModel> GetForecastParams(long jobId, int storeId, int productId);
        Task<IEnumerable<SuspectForecastTask>> GetTasks(SuspectForecastBatch batch);
    }
}
