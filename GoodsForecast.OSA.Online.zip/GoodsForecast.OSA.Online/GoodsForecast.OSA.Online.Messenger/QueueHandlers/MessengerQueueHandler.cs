﻿using EasyNetQ;
using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Messaging.Enums;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using GoodsForecast.OSA.Online.Messenger.Mail;
using System;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Messenger.QueueHandlers
{
    /// <summary>
    /// Обработчик очередей для Messenger
    /// </summary>
    public class MessengerQueueHandler : IQueueMessageHandler
    {
        private readonly IBus _bus;
        private readonly OsaLogger<MessengerQueueHandler> _logger;
        private IDisposable _busConnection;
        private readonly EmailSender _emailSender;

        public MessengerQueueHandler(
            IBus bus,
            OsaLogger<MessengerQueueHandler> logger,
            EmailSender emailSender)
        {
            _bus = bus;
            _logger = logger;
            _emailSender = emailSender;
        }

        public async Task Register()
        {
            _busConnection = await _bus.SendReceive.ReceiveAsync<IQueueMessage>(nameof(QueueName.BrokerToMessenger), Handle);
        }

        public async Task Handle(IQueueMessage message)
        {
            switch (message)
            {
                case BrokerToMessengerMessage bmMessage:
                    await ProcessMessageFromBroker(bmMessage);
                    break;
                default:
                    throw new ArgumentOutOfRangeException($"Тип сообщения {message.GetType()} не найден");
            }
        }

        private async Task ProcessMessageFromBroker(BrokerToMessengerMessage message)
        {
            _logger.LogInformation(Environment.MachineName, $"Сообщение \"{message.Subject}\" было получено из очереди {nameof(QueueName.BrokerToMessenger)}", message.JobId);

            _emailSender.Send(message);

            await Task.CompletedTask;
        }

        public void Dispose()
        {
            _busConnection?.Dispose();
            _bus?.Dispose();
        }
    }
}
