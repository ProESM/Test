using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Contracts.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GoodsForecast.OSA.Online.Messenger
{
    public class MessengerWorker : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly OsaLogger<MessengerWorker> _logger;
        private readonly IEnumerable<IQueueMessageHandler> _handlers;

        public MessengerWorker(
            IServiceProvider services,
            OsaLogger<MessengerWorker> logger,
            IEnumerable<IQueueMessageHandler> handlers)
        {
            _services = services;
            _logger = logger;
            _handlers = handlers;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Messenger запущен");

            try
            {
                using var scope = _services.CreateScope();
                foreach (var handler in _handlers)
                {
                    await handler.Register();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, "Ошибка в MessengerWorker", ex);
            }
        }

        public override async Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation(Environment.MachineName, "Messenger завершает работу");
            await Task.CompletedTask;
        }
    }
}
