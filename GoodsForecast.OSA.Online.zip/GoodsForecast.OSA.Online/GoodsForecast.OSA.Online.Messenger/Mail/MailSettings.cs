﻿namespace GoodsForecast.OSA.Online.Messenger.Mail
{
    public class MailSettings
    {
        public string EmailServer { get; set; }
        public int EmailServerPort { get; set; }
        public string ErrorRecipientsString { get; set; }
        public string DefaultSenderEmail { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
