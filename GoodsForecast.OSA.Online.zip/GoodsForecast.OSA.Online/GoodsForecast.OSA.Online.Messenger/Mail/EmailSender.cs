﻿using GoodsForecast.OSA.Online.Common;
using GoodsForecast.OSA.Online.Common.Messaging.Messages;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Security.Authentication;
using MailKit.Security;
using MimeKit;
using ContentDisposition = MimeKit.ContentDisposition;

namespace GoodsForecast.OSA.Online.Messenger.Mail
{
    /// <summary>
    /// Для отправки почтовых сообщений
    /// </summary>
    public class EmailSender
    {
        public readonly string Host;
        public readonly int? Port;
        public readonly string ErrorRecipientsString;
        public readonly string ConfigurationsString;
        public readonly (string DefaultSenderName, string DefaultSenderEmail) DefaultSender;
        public readonly MailKit.Net.Smtp.SmtpClient Client;
        private readonly OsaLogger<EmailSender> _logger;

        public string[] ErrorRecipients { get; }

        public EmailSender(OsaLogger<EmailSender> logger, IOptions<MailSettings> mailSettings)
        {
            if (string.IsNullOrWhiteSpace(mailSettings.Value.EmailServer))
                throw new ArgumentException("Host не может быть пустой строкой", nameof(mailSettings.Value.EmailServer));

            if (mailSettings.Value.EmailServerPort <= 0)
                throw new ArgumentException($"Port должен быть положительным числом (port = {mailSettings.Value.EmailServerPort})", nameof(mailSettings.Value.EmailServerPort));

            Host = mailSettings.Value.EmailServer;
            Port = mailSettings.Value.EmailServerPort;
            ErrorRecipientsString = mailSettings.Value.ErrorRecipientsString;

            if (!mailSettings.Value.DefaultSenderEmail.Contains(":"))
                throw new ArgumentException("DefaultSenderEmail не может быть разделен", nameof(mailSettings.Value.EmailServer));

            var defaultSenderVals = mailSettings.Value.DefaultSenderEmail.Split(":");
            DefaultSender = (defaultSenderVals[0], defaultSenderVals[1]);

            Client = new MailKit.Net.Smtp.SmtpClient();
            Client.ServerCertificateValidationCallback = (s, c, h, e) => true;
            Client.SslProtocols = SslProtocols.Tls | SslProtocols.Tls11 | SslProtocols.Tls12 |
                                  SslProtocols.Tls13;

            ErrorRecipients = !string.IsNullOrWhiteSpace(ErrorRecipientsString)
                                ? ErrorRecipientsString?.Split(';')
                                : new string[0];

#if TEST
            ConfigurationsString = "[Test] ";
#elif DEBUG
            ConfigurationsString = "[Debug] ";
#else
            ConfigurationsString = "[Prod] ";
#endif

            _logger = logger;
        }

        /// <summary>
        /// Отправить письмо по протоколу SMTP
        /// </summary>
        /// <returns>
        /// <para>true - если письмо было отправлено</para>
        /// <para>false - если письмо не было отправлено</para>
        /// </returns>
        public bool Send(BrokerToMessengerMessage message)
        {
            if(!Client.IsConnected)
                Client.Connect(Host, Port ?? 0, SecureSocketOptions.StartTls);
            MimeMessage mail = Create(message);

            //Если нет получателей, то добавить для отправки получателей по умолчанию
            if (!mail.To.Any())
                AddRecipients(mail, ErrorRecipients);

            try
            {
                Client.Send(mail);
                _logger.LogInformation(Environment.MachineName, $"Письмо \"{mail.Subject}\" было успешно отправлено!", message.JobId);
            }
            catch (SmtpException smtpex)
            {
                _logger.LogError(Environment.MachineName, $"Недостаточно прав для отправки письма \"{mail.Subject}\"!", smtpex, message.JobId);
                Client.Disconnect(true);
                return false;
            }
            catch (InvalidOperationException ioex)
            {
                _logger.LogError(Environment.MachineName, $"Не найдено ни одного получателя письма \"{mail.Subject}\"!", ioex, message.JobId);
                Client.Disconnect(true);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError(Environment.MachineName, $"Ошибка при отправке письма \"{mail.Subject}\"!", ex, message.JobId);
                Client.Disconnect(true);
                return false;
            }

            Client.Disconnect(true);
            return true;
        }

        ///// <summary>
        ///// Создать письмо на основе сообщения
        ///// </summary>
        ///// <returns>Письмо</returns>
        //private MailMessage Create(BrokerToMessengerMessage message)
        //{
        //    string sender = message.Sender;

        //    string subject = message.Subject;
        //    string body = message.Body;
        //    IEnumerable<string> recipients = message.Recipients;
        //    Dictionary<string, byte[]> attachments = message.Attachments;
        //    MailPriority mailPriority = message.Priority;

        //    MailMessage mail = new MailMessage()
        //    {
        //        Subject = subject,
        //        Body = body,
        //        Priority = mailPriority
        //    };

        //    (string senderName, string senderAddress) = SenderDeconstruct(sender);
        //    mail.From = new MailAddress(senderAddress, senderName);

        //    if (!(recipients is null))
        //        AddRecipients(mail, recipients);

        //    if (!(attachments is null))
        //        AddAttachments(mail, attachments);

        //    _logger.LogInformation(Environment.MachineName, $"Сообщение {message.Subject} было успешно сформировано.", message.JobId);

        //    return mail;
        //}

        /// <summary>
        /// Создать письмо на основе сообщения
        /// </summary>
        /// <returns>Письмо</returns>
        private MimeMessage Create(BrokerToMessengerMessage message)
        {
            string sender = message.Sender;

            IEnumerable<string> recipients = message.Recipients;
            Dictionary<string, byte[]> attachments = message.Attachments;
            
            MimeMessage mail = new MimeMessage()
            {
                Subject = ConfigurationsString + message.Subject
            };

            switch (message.Priority)
            {
                case MailPriority.Normal:
                    mail.Priority = MessagePriority.Normal;
                    break;
                case MailPriority.Low:
                    mail.Priority = MessagePriority.NonUrgent;
                    break;
                case MailPriority.High:
                    mail.Priority = MessagePriority.Urgent;
                    break;
            }

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = message.Body, 
                TextBody = message.Body
            };

            if (attachments != null)
            {
                foreach (var attachment in attachments)
                {
                    var attachmentExtension = Path.GetExtension(attachment.Key);
                    var mediaSubType = string.IsNullOrWhiteSpace(attachmentExtension) ? attachmentExtension : attachmentExtension.Substring(1);
                    var attachmentPart = new MimePart("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", mediaSubType)
                    {
                        Content = new MimeContent(new MemoryStream(attachment.Value), ContentEncoding.Default),
                        ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                        ContentTransferEncoding = ContentEncoding.Base64,
                        FileName = attachment.Key
                    };

                    bodyBuilder.Attachments.Add(attachmentPart);
                }
            }

            mail.Body = bodyBuilder.ToMessageBody();

            (string senderName, string senderAddress) = SenderDeconstruct(sender);
            mail.From.Add(new MailboxAddress(senderName, senderAddress));

            if (!(recipients is null))
                AddRecipients(mail, recipients);

            //if (!(attachments is null))
            //    AddAttachments(mail, attachments);

            _logger.LogInformation(Environment.MachineName, $"Сообщение {message.Subject} было успешно сформировано.", message.JobId);

            return mail;
        }

        /// <summary>
        /// Получить имя и email адрес отправителя
        /// </summary>
        /// <returns>Кортеж с именем и email адресом отправителя</returns>
        private (string senderName, string senderAddress) SenderDeconstruct(string sender)
        {
            if (sender == null || !sender.Contains(":"))
                return (DefaultSender.DefaultSenderName, DefaultSender.DefaultSenderEmail);

            var senderVals = sender.Split(":");
            return (senderVals[0], senderVals[1]);
        }

        ///// <summary>
        ///// Добавить получателей
        ///// </summary>
        //private void AddRecipients(MailMessage mail, IEnumerable<string> recipients)
        //{
        //    foreach (var recipient in recipients)
        //    {
        //        try
        //        {
        //            mail.To.Add(recipient);
        //        }
        //        catch
        //        {
        //            _logger.LogError(Environment.MachineName, $"Получатель {{{recipient}}} не был добавлен!");
        //            continue;
        //        }
        //    }
        //}

        /// <summary>
        /// Добавить получателей
        /// </summary>
        private void AddRecipients(MimeMessage mail, IEnumerable<string> recipients)
        {
            foreach (var recipient in recipients)
            {
                try
                {
                    mail.To.Add(new MailboxAddress(recipient, recipient));
                }
                catch
                {
                    _logger.LogError(Environment.MachineName, $"Получатель {{{recipient}}} не был добавлен!");
                    continue;
                }
            }
        }

        /// <summary>
        /// Добавить вложения
        /// </summary>
        private void AddAttachments(MailMessage mail, Dictionary<string, byte[]> attachments)
        {
            foreach (var attachment in attachments)
                mail.Attachments.Add(new Attachment(new MemoryStream(attachment.Value), attachment.Key, MediaTypeNames.Application.Octet));
        }
    }
}