﻿ALTER ROLE [db_owner] ADD MEMBER [gfc_osa_online];

