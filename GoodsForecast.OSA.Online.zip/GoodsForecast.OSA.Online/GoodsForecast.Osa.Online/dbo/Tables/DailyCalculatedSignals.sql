﻿CREATE TABLE [dbo].[DailyCalculatedSignals] (
    [Id]                          BIGINT   IDENTITY (1, 1) NOT NULL,
    [JobId]                       BIGINT   NOT NULL,
    [LocalDateTime]               DATETIME NOT NULL,
    [MskDateTime]                 DATETIME NOT NULL,
    [LocationId]                  INT      NOT NULL,
    [SignalsCount]                INT      NOT NULL,
    [LocalSalesLastDateTime]      DATETIME NOT NULL,
    [LocalRestLastDateTime]       DATETIME NOT NULL,
    [CountSalesItems3HoursBefore] INT      NOT NULL,
    [CountRestItems3HoursBefore]  INT      NOT NULL,
    [CountAssortMatrix]           INT      NOT NULL,
    [LastSynchroStatus]           TINYINT  NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_DailyCalculatedSignals_Locations] FOREIGN KEY ([LocationId]) REFERENCES [dbo].[Locations] ([Id])
);

