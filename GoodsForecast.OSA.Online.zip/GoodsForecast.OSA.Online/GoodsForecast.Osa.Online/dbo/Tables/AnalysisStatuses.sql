﻿CREATE TABLE [dbo].[AnalysisStatuses] (
    [Id]       TINYINT        IDENTITY (1, 1) NOT NULL,
    [Name]     NVARCHAR (256) NOT NULL,
    [IsActive] BIT            NOT NULL,
    CONSTRAINT [PK_AnalysisStatuses] PRIMARY KEY CLUSTERED ([Id] ASC)
);

