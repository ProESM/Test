﻿CREATE TABLE [dbo].[BatchTypes] (
    [Id]   TINYINT        NOT NULL,
    [Name] NVARCHAR (256) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

