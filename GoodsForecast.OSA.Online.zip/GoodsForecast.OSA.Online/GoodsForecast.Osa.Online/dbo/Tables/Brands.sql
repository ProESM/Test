﻿CREATE TABLE [dbo].[Brands] (
    [Id]         INT            IDENTITY (1, 1) NOT NULL,
    [ExternalId] NVARCHAR (32)  NOT NULL,
    [Name]       NVARCHAR (256) NOT NULL,
    [IsActive]   BIT            NOT NULL,
    CONSTRAINT [PK_Brands] PRIMARY KEY CLUSTERED ([Id] ASC)
);

