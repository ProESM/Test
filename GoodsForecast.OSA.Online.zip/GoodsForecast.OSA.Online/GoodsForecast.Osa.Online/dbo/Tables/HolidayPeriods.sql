﻿CREATE TABLE [dbo].[HolidayPeriods] (
    [Id]        INT  IDENTITY (1, 1) NOT NULL,
    [StartDate] DATE NOT NULL,
    [EndDate]   DATE NOT NULL,
    [HolidayId] INT  NOT NULL,
    [IsActive]  BIT  NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_HolidayPeriods_Holidays] FOREIGN KEY ([HolidayId]) REFERENCES [dbo].[Holidays] ([Id])
);

