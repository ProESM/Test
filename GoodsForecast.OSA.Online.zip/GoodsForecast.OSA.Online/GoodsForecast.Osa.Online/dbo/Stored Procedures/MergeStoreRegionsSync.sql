﻿

CREATE PROCEDURE [dbo].[MergeStoreRegionsSync]
AS

MERGE INTO [dbo].[StoreRegions] AS trg
USING (
	SELECT RegionId AS ExternalId
		  ,NULL AS ParentId
		  ,ParentId AS ParentExternalId
		  ,Name
		  ,CAST(1 AS BIT) AS IsActive
		  ,CAST(1 AS BIT) AS Level
	FROM  etl.Regions
	WHERE ParentId IS NULL
) AS source
	ON trg.[ExternalId] = source.[ExternalId]
WHEN MATCHED THEN
	UPDATE 
		SET trg.ExternalId = source.ExternalId
           ,trg.ParentId = source.ParentId 
           ,trg.Name = source.Name
           ,trg.IsActive = source.IsActive
           ,trg.Level = source.Level
WHEN NOT MATCHED BY TARGET THEN
	INSERT (ExternalId
           ,ParentId 
           ,Name
           ,IsActive
           ,[Level])
	VALUES  (source.ExternalId
            ,source.ParentId 
            ,source.Name
            ,source.IsActive
            ,source.Level)
WHEN NOT MATCHED BY SOURCE AND trg.[Level] = 1 THEN
	UPDATE 
		SET trg.IsActive = 0;

MERGE INTO dbo.StoreRegions AS trg
USING (
	SELECT r.RegionId AS ExternalId
		  ,sr.Id AS ParentId
		  ,r.ParentId AS ParentExternalId
		  ,r.Name
		  ,CAST(1 AS BIT) AS IsActive
		  ,CAST(2 AS BIT) AS Level
	FROM  etl.Regions AS r
		INNER JOIN dbo.StoreRegions AS sr
			ON sr.ExternalId = r.ParentId
	WHERE r.ParentId IS NOT NULL
) AS source
	ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
	UPDATE 
		SET trg.ExternalId = source.ExternalId
           ,trg.ParentId = source.ParentId 
           ,trg.Name = source.Name
           ,trg.IsActive = source.IsActive
           ,trg.Level = source.Level
WHEN NOT MATCHED BY TARGET THEN
	INSERT (ExternalId
           ,ParentId 
           ,Name
           ,IsActive
           ,Level)
	VALUES  (source.ExternalId
            ,source.ParentId 
            ,source.Name
            ,source.IsActive
            ,source.Level)
WHEN NOT MATCHED BY SOURCE AND trg.[Level] = 2 THEN
	UPDATE 
		SET trg.IsActive = 0;
