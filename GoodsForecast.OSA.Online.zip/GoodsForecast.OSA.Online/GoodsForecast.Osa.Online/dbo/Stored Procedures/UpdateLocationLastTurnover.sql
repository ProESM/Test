﻿

CREATE PROCEDURE [dbo].[UpdateLocationLastTurnover]
AS

 SET XACT_ABORT ON 

DECLARE @dt DATE  = GETDATE()
DECLARE @StartDate DATE = DATEADD(d,-28,@dt)

SELECT @startDate

--DROP TABLE #LastTurnover
 

 BEGIN TRAN 
    
    TRUNCATE TABLE dbo.LocationStateLastTurnover
    

	INSERT INTO dbo.LocationStateLastTurnover(LocationId, ProductId, SalesAmount, IsKvi, AbcCategory, Updated)
	SELECT 
		s.LocationId, 
		s.ProductId, 
		SUM(s.Quantity * pm.Price),
		pm.IsKvi, 
		pm.AbcCategory, 
		@dt
	FROM dbo.LocationStateDaySales s
	JOIN dbo.ProductMatrix pm
		ON s.LocationId = pm.LocationId
		AND s.ProductId = pm.ProductId
	WHERE pm.[Date] = @dt
		AND s.[Date] >= @StartDate
		AND s.[Date] < @dt
	GROUP BY s.LocationId, 
		s.ProductId, 
		pm.IsKvi, 
		pm.AbcCategory
    
COMMIT

