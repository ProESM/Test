﻿
CREATE PROCEDURE [dbo].[MergeBrandsSync]
AS
	MERGE INTO  dbo.Brands AS trg
	USING (
		SELECT BrandId AS ExternalId
			,[NAME]
			,CAST(1 AS BIT) AS IsActive
		FROM etl.Brands
		) AS source
		ON trg.ExternalId = source.ExternalId
	WHEN MATCHED
		THEN
			UPDATE
			SET trg.NAME = source.NAME
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				ExternalId
				,NAME
				,IsActive
				)
			VALUES (
				source.ExternalId
				,source.NAME
				,source.IsActive
				)
	WHEN NOT MATCHED BY SOURCE
		THEN
			UPDATE
			SET trg.IsActive = 0;
