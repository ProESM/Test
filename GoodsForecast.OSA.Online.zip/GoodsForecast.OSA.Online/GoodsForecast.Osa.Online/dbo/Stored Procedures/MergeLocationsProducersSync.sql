﻿
CREATE PROCEDURE [dbo].[MergeLocationsProducersSync]
AS  
MERGE INTO  Locations AS trg
USING (
	SELECT p.ProducerId AS ExternalId
		  ,p.Name AS Name
		  ,NULL AS ShortName
		  ,NULL AS StoreFormatId
		  ,NULL AS StoreClusterId
		  ,NULL AS StoreRegionId
		  ,NULL AS OpenDate
		  ,NULL AS Area
		  ,NULL AS OpenTime
		  ,NULL AS CloseTime
		  ,N'Producer' AS TypeKey
		  ,CAST(1 AS BIT) AS IsActive
		  ,NULL AS Timezone
	FROM etl.Producers AS p
) AS source
	ON trg.ExternalId = source.ExternalId
	AND trg.TypeKey = source.TypeKey
WHEN MATCHED THEN
	UPDATE 
		SET trg.Name = source.Name
		   ,trg.ShortName = source.ShortName
           ,trg.StoreFormatId = source.StoreFormatId
           ,trg.StoreClusterId = source.StoreClusterId
           ,trg.StoreRegionId = source.StoreRegionId
           ,trg.OpenDate = source.OpenDate
           ,trg.Area = source.Area
           ,trg.OpenTime = source.OpenTime
           ,trg.CloseTime = source.CloseTime
           ,trg.TypeKey = source.TypeKey
           ,trg.IsActive = source.IsActive
           ,trg.Timezone = source.Timezone
WHEN NOT MATCHED BY TARGET THEN
	INSERT (ExternalId
           ,Name
           ,ShortName
           ,StoreFormatId
           ,StoreClusterId
           ,StoreRegionId
           ,OpenDate
           ,Area
           ,OpenTime
           ,CloseTime
           ,TypeKey
           ,IsActive
           ,Timezone)
	VALUES  (source.ExternalId
			,source.Name
			,source.ShortName
			,source.StoreFormatId
			,source.StoreClusterId
			,source.StoreRegionId
			,source.OpenDate
			,source.Area
			,source.OpenTime
			,source.CloseTime
			,source.TypeKey
			,source.IsActive
			,source.Timezone)
WHEN NOT MATCHED BY SOURCE AND trg.TypeKey = N'Producer' THEN
	UPDATE 
		SET trg.IsActive = 0
		;
