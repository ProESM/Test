﻿

CREATE PROCEDURE [dbo].[MergePromotionMatrixSync]
	AS

	SELECT DISTINCT l.Id AS LocationId
			  ,pp.Id AS PromotionId
			  ,pr.Id AS ProductId
    INTO #PromotionMatrix
	FROM [etl].[Promotions] AS sp
		INNER JOIN dbo.Locations AS l
			ON l.ExternalId = sp.StoreId
			AND l.TypeKey = N'Store'
		INNER JOIN dbo.Products AS pr
			ON pr.ExternalId = sp.ProductId
		INNER JOIN [dbo].[Promotions] AS pp
			ON pp.[ExternalId] = IIF(LEN(sp.[PromoId]) <= 11
				,sp.[PromoId] + '_' + CONVERT(NVARCHAR, sp.[StartDate], 112) + '_' + CONVERT(NVARCHAR, sp.[EndDate], 112)
				,sp.[PromoId])
            
	MERGE INTO dbo.PromotionMatrix AS trg
	USING #PromotionMatrix AS source
		ON trg.LocationId = source.LocationId
		AND trg.PromotionId = source.PromotionId
		AND trg.ProductId = source.ProductId
 
	WHEN NOT MATCHED BY TARGET THEN
		INSERT (LocationId
			   ,PromotionId
			   ,ProductId)
		VALUES  (source.LocationId
				,source.PromotionId
				,source.ProductId)
	--WHEN NOT MATCHED BY SOURCE THEN
	--	DELETE
		;
