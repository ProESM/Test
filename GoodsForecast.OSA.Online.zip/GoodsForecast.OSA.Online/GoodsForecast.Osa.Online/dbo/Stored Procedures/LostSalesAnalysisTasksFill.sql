﻿
--=================================================
-- Заполнение заданий на расчет
--=================================================
CREATE PROCEDURE [dbo].[LostSalesAnalysisTasksFill]
       @JobId BIGINT
AS
BEGIN
		-- анализируемая дата - дата и время сигнала в местном времени - 1 час, т.е. дата последней синхронизации
		-- все продажи, остатки,время работы магазина  - в местном времени, поэтому работаем тоже в местном 
		DECLARE @DtAnalyse DATETIME
		SELECT @DtAnalyse = AnalizeDatetime 
		FROM LostSalesAnalysisJobs 
		WHERE JobId = @JobId

	    --порог изменения цены
		DECLARE @PriceChangeLimit FLOAT;
		SELECT @PriceChangeLimit = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'PriceChangeLimit'

		--количество дней для поиска подходящих интервалов
		DECLARE @maxDayCount AS INT
		SELECT @maxDayCount = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'MaxDayCount'

		-- для поиска подходящих интервалов ограничиваемся 3 месяцами
		DECLARE @DtBorder DATETIME
		SELECT @DtBorder = DATEADD(DAY, -@maxDayCount, @DtAnalyse)
	   
		--количество нулевых часов, когда интервал будет считаться пустым
		DECLARE @ParamDefault SMALLINT
		SELECT @ParamDefault = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'ParamDefault'

		--количество нулевых часов, когда интервал будет считаться пустым в случае промо
		DECLARE @ParamPromo SMALLINT       
		SELECT @ParamPromo = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'ParamPromo'

		--количество нулевых часов, когда интервал будет считаться пустым в случае kvi
		DECLARE @ParamKVI SMALLINT
		SELECT @ParamKVI = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'ParamKVI'

		--количество месяцев для анализа наличия товара-магазина в матрице
		DECLARE @MonthCountMatrix SMALLINT
		SELECT @MonthCountMatrix = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'MonthCountMatrix'

		--Конверсия подозрений в сигналы – какой процент подозрений выливается в сигнал (данные от математиков)
		DECLARE @Conversion FLOAT
		SELECT @Conversion = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'Conversion'
		select @Conversion

		--Корректирующий коэффициент (чтобы набрать чуть больше подозрений для учета РТО и вероятности корректности сигнала)
		DECLARE @KoefConversion FLOAT
		SELECT @KoefConversion = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'KoefConversion'

        --Дневной или ночной сигнал
        DECLARE @IsDaily BIT
        SELECT @IsDaily = aj.IsDaily 
        FROM [dbo].[ActiveJobs] aj
        WHERE aj.Id = @JobId

        --Минимальное количество сигналов
        DECLARE @MinSignalCount INT
        SELECT @MinSignalCount = [Value]  
        FROM [svc].[AnalysisParams]
        WHERE [Name] = IIF(@IsDaily = 0, 'MinNightlySignalCount', 'MinDailySignalCount')

        --Количество сигналов
        DECLARE @SignalCount INT = ROUND(@MinSignalCount / @Conversion * @KoefConversion, 0)

		--Конверсии подозрений в сигналы по магазинам
		IF(OBJECT_ID('tempdb..#LocationConversions') IS NOT NULL)
	    BEGIN
		    DROP TABLE #LocationConversions
	    END

		CREATE TABLE #LocationConversions 
			(
				[LocationId] [int] NOT NULL,
				[Conversion] [real] NOT NULL,
				[KoefConversion] [real] NOT NULL,
				[SignalCount] [int] NOT NULL,
				PRIMARY KEY CLUSTERED([LocationId])
			)

		INSERT INTO #LocationConversions
				   ([LocationId]
				   ,[Conversion]
				   ,[KoefConversion]
				   ,[SignalCount])
		SELECT l.[Id] AS [LocationId]
			  ,CAST(ISNULL(lc.[Conversion], 0.04) AS REAL) AS [Conversion]
			  ,CAST(ISNULL(lc.[KoefConversion], 1.25) AS REAL) AS [KoefConversion]
			  ,CAST(ROUND(@MinSignalCount / CAST(ISNULL(lc.[Conversion], 0.04) AS REAL) 
						* CAST(ISNULL(lc.[KoefConversion], 1.25) AS REAL), 0) AS INT) AS [SignalCount]
		FROM [dbo].[Locations] AS l
			LEFT JOIN [svc].[LocationConversions] AS lc
				ON lc.[LocationId] = l.[Id]
		WHERE l.[TypeKey] = 'Store'

		--Количество дней, когда товар считается новинкой
		DECLARE @NewItemsDays INT
		SELECT @NewItemsDays = [Value] 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'NewItemsDays'

		-----------------------------------------------------------------------------------------------
		--Средничасовые продажи магазинов кластера, ниже которых подозрение не перейдет в сигнал (по умолчанию 0)
		DECLARE @AvgClustHourSales INT = 0
		SELECT @AvgClustHourSales = ISNULL([Value], 0) 
		FROM [svc].[AnalysisParams]
		WHERE [Name] = 'AvgClustHourSales'	
		------------------------------------------------------------------------------------------------
              	   	   
		DECLARE @HolidayStartDate DATETIME
		DECLARE @HolidayEndDate DATETIME

		SET @HolidayStartDate = 
        (
            SELECT MIN(StartDate)
			FROM [dbo].[HolidayPeriods] AS hp
			INNER JOIN [dbo].[Holidays] AS h
			    ON hp.HolidayId = h.Id
			WHERE hp.IsActive = 1 
			    AND h.IsActive = 1
			    AND hp.StartDate <= CAST(@DtAnalyse AS DATE)
			    AND hp.EndDate >= CAST(@DtAnalyse AS DATE)
        )

		SET @HolidayEndDate = 
        (
            SELECT MAX(EndDate)
			FROM [dbo].[HolidayPeriods] AS hp
			INNER JOIN [dbo].[Holidays] AS h
			    ON hp.HolidayId = h.Id
			WHERE hp.IsActive = 1 
			    AND h.IsActive = 1
			    AND hp.EndDate < CAST(@DtAnalyse AS DATE)
        )


		DECLARE @StrongHolidayStartDate DATETIME
	    DECLARE @StrongHolidayEndDate DATETIME

		SET @StrongHolidayStartDate = 
        (
            SELECT MIN(StartDate)
			FROM [dbo].[HolidayPeriods] AS hp
			INNER JOIN [dbo].[Holidays] AS h
			    ON hp.HolidayId = h.Id
			WHERE hp.IsActive = 1 
			    AND h.IsActive = 1
			    AND h.IsStrongType = 1
			    AND hp.StartDate <= CAST(@DtAnalyse AS DATE)
			    AND hp.EndDate >= CAST(@DtAnalyse AS DATE)
        )

		SET @StrongHolidayEndDate = 
        (
            SELECT MAX(EndDate)
			FROM [dbo].[HolidayPeriods] AS hp
			INNER JOIN [dbo].[Holidays] AS h
			    ON hp.HolidayId = h.Id
			WHERE hp.IsActive = 1 
			    AND h.IsActive = 1
			    AND h.IsStrongType = 1
			    AND hp.EndDate < CAST(@DtAnalyse AS DATE)
        )
		
        IF(OBJECT_ID('tempdb..#promo') IS NOT NULL)
	    BEGIN
		    DROP TABLE #promo
	    END
 
       CREATE TABLE #promo 
       (
            LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            PromoBorder DATE, 
            Algtype BIT,
            PRIMARY KEY CLUSTERED(LocationId, ProductId)
       )

       DECLARE @PromoDuration INT
       SELECT @PromoDuration = [Value] 
       FROM [svc].[AnalysisParams]
       WHERE [Name] = 'PromoDuration'

       DECLARE @PromoSubstruct INT
       SELECT @PromoSubstruct = [Value] 
       FROM [svc].[AnalysisParams]
       WHERE [Name] = 'PromoSubstruct'
 
		--добавляем промо, которые пересекаются с анализириумым днем 
	    INSERT INTO #promo (LocationId, ProductId, PromoBorder, Algtype)
	    SELECT 
			am.LocationId 
			,am.ProductId 
			,MIN(am.DtBegin) 
            ,MAX(
				CASE 
					WHEN 
						pt.ExternalId IN ('4', '3', '11', '2', '6', '8', '10') 
						OR pt.ExternalId IN ('12', '13', '18', '19', '20', '21') 
						THEN 1
					ELSE 0
				END
			) as AlgType--не все промо типы считаем за промо
	    FROM [dbo].[PromoPeriods] AS am
        LEFT JOIN [dbo].PromotionMatrix AS pm
	        ON am.ProductId = pm.ProductId
		    AND am.LocationId = pm.LocationId		    
		LEFT JOIN [dbo].[Promotions] AS p
			ON p.Id = pm.PromotionId
            AND CAST(@DtAnalyse AS DATE)  <= p.EndDate
            AND CAST(@DtAnalyse AS DATE)  >= p.StartDate
		LEFT JOIN [dbo].[PromotionTypes] AS pt
			On pt.Id = p.PromotionTypeId
		WHERE am.DtBegin <= CAST(@DtAnalyse AS DATE)         
			AND am.DtEnd >= CAST(@DtAnalyse AS DATE)
		GROUP BY am.LocationId, am.ProductId

	   IF(OBJECT_ID('tempdb..#kvi') IS NOT NULL)
	    BEGIN
		    DROP TABLE #kvi
	    END
 
       CREATE TABLE #kvi 
       (
            LocationId INT NOT NULL, 
            ProductId INT NOT NULL,
            PRIMARY KEY CLUSTERED(LocationId, ProductId)
       )

	   INSERT INTO #kvi (LocationId, ProductId)
	   SELECT 
			am.LocationId, 
			am.ProductId			
	   FROM [dbo].ProductMatrix am
	   WHERE am.Date = CAST(@DtAnalyse AS DATE)
			AND am.IsKvi = 1
     
       IF(OBJECT_ID('tempdb..#suspect_sales') IS NOT NULL)
	    BEGIN
		    DROP TABLE #suspect_sales
	    END
 
       CREATE TABLE #suspect_sales 
       (
            LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            [Date] SMALLDATETIME NOT NULL, 
            Quantity REAL NULL,
            PRIMARY KEY CLUSTERED(LocationId, ProductId, [Date])
       )
 
       -- важный момент - в таблице #suspect_periods, в поле DtBegin записана информация о последней ненудевой продаже!
       IF(OBJECT_ID('tempdb..#suspect_periods') IS NOT NULL)
	    BEGIN
		    DROP TABLE #suspect_periods
	    END
 
       -- здесь DtBegin не включительно, т.е. если с 9 до 11, то значит период с 10 до 11
       CREATE TABLE #suspect_periods 
       (
			LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            DtBegin SMALLDATETIME NOT NULL, 
			DtEnd SMALLDATETIME NOT NULL, 
            Price FLOAT NULL, 
            PromoAlgType TINYINT, 
            isHoliday BIT, 
            isKVI BIT, 
            isPromo BIT, 
            AbcCategory VARCHAR(1),
            SumSales REAL NULL,
            TheshHold SMALLINT,
			PriceIncreased BIT DEFAULT(0),
            PRIMARY KEY CLUSTERED(LocationId, ProductId, DtBegin)
       )
 
       -- отбираем пары, где может быть дефицит за анализируемое время (@DtAnalyse)
       INSERT INTO #suspect_sales (LocationId, ProductId, [Date], Quantity)
       SELECT 
            pms.LocationId
            ,pms.ProductId
            ,CAST(pms.[Datetime] AS SMALLDATETIME)
            ,SUM(pms.Quantity)
       FROM [dbo].[LocationStateHourSales] AS pms
       INNER JOIN [dbo].[Locations] AS loc
            ON loc.Id = pms.LocationId
       INNER JOIN [dbo].[LostSalesAnalysisJobAssortment] AS lsaja
            ON lsaja.LocationId = pms.LocationId
            AND lsaja.ProductId = pms.ProductId
            AND lsaja.LostSalesAnalysisJobId = @JobId
       WHERE pms.Quantity > 0
             AND IIF(DATEPART(HOUR, pms.[Datetime]) = 0, 24, DATEPART(HOUR, pms.[Datetime]))  < IIF(DATEPART(HOUR,loc.CloseTime) = 0, 24, DATEPART(HOUR,loc.CloseTime))
             AND DATEPART(HOUR, pms.[Datetime]) >= DATEPART(HOUR,loc.OpenTime)
             AND pms.LocationId IN 
                (
                    SELECT LocationId 
                    FROM [dbo].[LostSalesAnalysisJobLocations]
                     WHERE LostSalesAnalysisJobId = @JobId
                )
             AND CAST(pms.[Datetime] as DATE) = CAST(@DtAnalyse AS DATE)
             AND pms.[Datetime] < @DtAnalyse
        GROUP BY pms.LocationId
        ,pms.ProductId
        ,CAST(pms.[Datetime] AS SMALLDATETIME)
                
       -- есть пустые периоды внутри дня
       INSERT INTO #suspect_periods ([LocationId], [ProductId], [DtBegin], [DtEnd])    
       SELECT susp_begin.LocationId
            ,susp_begin.ProductId
            ,MAX(susp_begin.[Date])
            ,@DtAnalyse
       FROM #suspect_sales susp_begin           
	   LEFT JOIN #promo AS p
			ON p.LocationId = susp_begin.LocationId
			AND p.ProductId = susp_begin.ProductId 
	   LEFT JOIN #kvi AS k
			ON k.LocationId = susp_begin.LocationId
			AND k.ProductId = susp_begin.ProductId  
       WHERE susp_begin.[Date] <   @DtAnalyse    
       GROUP BY susp_begin.LocationId, 
            susp_begin.ProductId,
            p.LocationId, 
            k.LocationId
       HAVING 
            --период считается пустым, если 
            -- для промо - не было продаж в течение @ParamDefault(3) часов
            -- для kvi - не было продаж в течение @ParamPromo(1) < любого количества времени(пока так поставила) или количества часов по умолчанию(3)
            -- по умочанию не было продаж в течение любого количества времени(пока так поставила) или количества часов по умолчанию(3)
			dbo.usf_CheckThePeriod(
				DATEPART(HOUR, @DtAnalyse) - IIF(DATEPART(HOUR, MAX(susp_begin.[Date])) = 0, 24, DATEPART(HOUR, MAX(susp_begin.[Date]))) - 1,
				CASE WHEN p.LocationId IS NULL then 0 ELSE 1 END,
				CASE WHEN k.LocationId IS NULL then 0 ELSE 1 END,
				@ParamDefault,
				@ParamPromo,
				@paramKVI
			) = 1
       		 
       IF(OBJECT_ID('tempdb..#max_sale_past') IS NOT NULL)
	    BEGIN
		    DROP TABLE #max_sale_past
	    END
 
       CREATE TABLE #max_sale_past 
       (
            LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            [Date] SMALLDATETIME NOT NULL,
            PRIMARY KEY CLUSTERED(LocationId, ProductId, [Date])
       )

       --последняя дата продаж за последний месяц
       INSERT INTO #max_sale_past (LocationId, ProductId, [Date])
       SELECT LocationId
            ,ProductId
            ,DtBegin
       FROM
       (
            SELECT pms.LocationId
                ,pms.ProductId
                ,MAX(pms.[Datetime]) AS DtBegin
            FROM [dbo].[LocationStateHourSales] AS pms
            INNER JOIN [dbo].[Locations] AS loc 
                ON pms.LocationId = loc.Id
            WHERE pms.[Datetime] < @DtAnalyse
                AND IIF(DATEPART(HOUR, pms.[Datetime]) = 0, 24, DATEPART(HOUR, pms.[Datetime]))  < IIF(DATEPART(HOUR,loc.CloseTime) = 0, 24, DATEPART(HOUR,loc.CloseTime))
                AND DATEPART(HOUR, pms.[Datetime]) >= DATEPART(HOUR,loc.OpenTime)
                AND Quantity > 0
                -----------
                AND pms.[Datetime] >= DATEADD(MONTH,-1,@DtAnalyse)
                -----------               
            GROUP BY pms.LocationId, pms.ProductId
       ) as past
 
      
	   -- совсем нет продаж за анализируемый день
       INSERT INTO #suspect_periods ([LocationId], [ProductId], [DtBegin], [DtEnd])    
       SELECT past.LocationId
            ,past.ProductId
            ,past.[Date]
            ,IIF(DATEPART(HOUR, loc.CloseTime) < DATEPART(HOUR, @DtAnalyse) AND DATEPART(HOUR, loc.CloseTime) > 0,
                CAST(CAST(@DtAnalyse AS DATE) AS DATETIME) + CAST(loc.CloseTime AS DATETIME),
                @DtAnalyse)
       FROM #max_sale_past AS past
       INNER JOIN [dbo].[LostSalesAnalysisJobAssortment] AS lsaja
            ON lsaja.LocationId = past.LocationId
            AND lsaja.ProductId = past.ProductId
            AND lsaja.LostSalesAnalysisJobId = @JobId
       LEFT JOIN
       (
            SELECT ss.LocationId
                ,ss.ProductId
                ,MIN(ss.[Date]) AS DtEnd
            FROM #suspect_sales AS ss
            GROUP BY ss.LocationId, ss.ProductId
       ) AS present
            ON past.LocationId = present.LocationId
            AND past.ProductId = present.ProductId
       INNER JOIN [dbo].[Locations] AS loc
            ON loc.Id = past.LocationId
	   LEFT JOIN #promo AS p
			ON p.LocationId = past.LocationId
			AND p.ProductId = past.ProductId
	   LEFT JOIN #kvi AS k
			ON k.LocationId = past.LocationId
			AND k.ProductId = past.ProductId
       WHERE present.LocationId IS NULL
             AND dbo.usf_CheckThePeriod(
				dbo.usf_WorkingHoursDiff
				(
                    DATEADD(HOUR,1,past.[Date]),
                    IIF(DATEPART(HOUR, loc.CloseTime) < DATEPART(HOUR, @DtAnalyse) AND DATEPART(HOUR, loc.CloseTime) > 0,
                        CAST(CAST(@DtAnalyse AS DATE) AS DATETIME) + CAST(loc.CloseTime AS DATETIME),
                        @DtAnalyse),
                    DATEPART(HOUR,loc.OpenTime),
                    DATEPART(HOUR,loc.CloseTime)
				),
				CASE WHEN p.LocationId IS NULL then 0 ELSE 1 END,
				CASE WHEN k.LocationId IS NULL then 0 ELSE 1 END,
				@ParamDefault,
				@ParamPromo,
				@paramKVI
			) = 1
			
		
		-- проставляем нужные параметры
       UPDATE #suspect_periods
       SET 
			Price = ISNULL(pms.PriceSum/pms.Quantity,0)
			,PromoAlgType = ISNULL(p.AlgType, 0)
			,isHoliday = CASE WHEN @HolidayStartDate IS NULL THEN 0 ELSE 1 END 
			,isKVI = CASE WHEN k.LocationId IS NULL THEN 0 ELSE 1 END
			,isPromo = CASE WHEN p.LocationId IS NULL THEN 0 ELSE 1 END
            ,AbcCategory = am.AbcCategory
			,DtBegin = dbo.usf_AddOneWorkingHour
             (
                    DtBegin,
                    DATEPART(HOUR,loc.OpenTime),
                    DATEPART(HOUR,loc.CloseTime)
             )
			,PriceIncreased = am.[PriceIncreased]
		FROM #suspect_periods sp
		INNER JOIN [dbo].[Locations] AS l
			ON l.Id = sp.LocationId
		LEFT JOIN [dbo].[LocationStateHourSales] AS pms
			ON pms.LocationId = sp.LocationId
			AND pms.ProductId = sp.ProductId
			AND pms.[Datetime] = sp.DtBegin
			AND pms.Quantity > 0
		INNER JOIN [dbo].[ProductMatrix] AS am
			ON am.LocationId = sp.LocationId
			AND am.ProductId = sp.ProductId
			AND am.[Date] = CAST(@DtAnalyse AS DATE)
		LEFT JOIN #promo AS p
			ON p.ProductId = sp.ProductId
			AND p.LocationId = sp.LocationId
		LEFT JOIN #kvi AS k
			ON k.LocationId = sp.LocationId
			AND k.ProductId = sp.ProductId
		INNER JOIN [dbo].[Locations] AS loc
			ON loc.Id = sp.LocationId

		UPDATE #suspect_periods
		SET TheshHold = dbo.[usf_GetTheBorder](isPromo, isKVI, @ParamDefault, @ParamPromo, @paramKVI)				
		FROM #suspect_periods sp

		-- если подозрение в промо, то его длина должна быть обрезана до начала промо
		UPDATE #suspect_periods
		SET 
			DtBegin = DATEADD(hour, DATEPART(HOUR,loc.OpenTime), CAST(p.PromoBorder AS DATETIME)) 
		FROM #suspect_periods sp
		INNER JOIN #promo AS p 
			ON p.LocationId = sp.LocationId
			AND p.ProductId = sp.ProductId
		INNER JOIN [dbo].[Locations] AS loc
			ON loc.Id = sp.LocationId
		WHERE p.PromoBorder > sp.DtBegin --обрезать только если промо началось внутри интервала, т.е. строго больше даты начала подозрительного интервала
			
		-- если промо закончилось до анализируемого дня, но задевает начало подозрения, то обрезаем по окончанию промо
		UPDATE #suspect_periods
		SET 
			DtBegin = DATEADD(hour, DATEPART(HOUR,loc.OpenTime), CAST(p.PromoBorder AS DATETIME)) 
		FROM #suspect_periods sp
		INNER JOIN 
        (			
			SELECT 
				sp1.LocationId
				,sp1.ProductId 
				,sp1.DtBegin
				,DATEADD(DAY, 1, MAX(pm.[DtEnd])) AS PromoBorder--потомучто последний день промо не должен быть равен началу периода подозрения без промо                
			FROM #suspect_periods sp1
			INNER JOIN [dbo].[PromoPeriods] AS pm
			    ON pm.ProductId = sp1.ProductId
			    AND pm.LocationId = sp1.LocationId
			WHERE DATEADD(DAY, 1, pm.[DtEnd]) > sp1.DtBegin AND DATEADD(DAY, 1, pm.[DtEnd]) < sp1.DtEnd  -- конец промо находится внутри подозрения	
                AND pm.DtBegin < sp1.DtBegin -- если начало промо находится внутри интервала, то оно не обрезается			
			GROUP BY sp1.LocationId, sp1.ProductId, sp1.DtBegin 		
		) p 
			ON p.LocationId = sp.LocationId
			AND p.ProductId = sp.ProductId
			AND p.DtBegin = sp.DtBegin
		INNER JOIN [dbo].[Locations] AS loc
			ON loc.Id = sp.LocationId
		WHERE p.PromoBorder >= sp.DtBegin	 
			AND sp.isPromo = 0 -- условие означает, что конец периода (текущий день) не входит в промо 


        --TO DO подумать над тем, чтобы раскомментировать
		/*UPDATE #suspect_periods
		SET 
			DtBegin = DATEADD(hour, DATEPART(HOUR,loc.OpenTime), @HolidayStartDate) 
		FROM #suspect_periods sp
		INNER JOIN [dbo].[Locations] AS loc
		    ON loc.Id = sp.LocationId
		WHERE
			ISNULL(@HolidayStartDate, '1900-01-01') >= sp.DtBegin
			--AND sp.isPromo = 0
		*/

		UPDATE #suspect_periods
		SET 
			DtBegin = DATEADD(hour, DATEPART(HOUR,loc.OpenTime), DATEADD(day, 1, @StrongHolidayEndDate)) 
		FROM #suspect_periods sp
		INNER JOIN [dbo].[Locations] AS loc
		    ON loc.Id = sp.LocationId
		WHERE ISNULL(DATEADD(DAY, 1, @StrongHolidayEndDate), '1900-01-01') >= sp.DtBegin
			
	  	-- учет ассортиментной матрицы
		-- удаляем все подозрения, которые хотя бы частично были вне матрицы
		DELETE FROM #suspect_periods
		FROM #suspect_periods smp
		INNER JOIN
		(
            SELECT lsat.LocationId AS locationId
                ,lsat.ProductId AS productID
                ,DtBegin
                ,COUNT(*) AS cnt
                ,DATEDIFF(DAY, CAST(lsat.DtBegin AS DATE), @DtAnalyse) + 1 AS cnt_diff
		    FROM #suspect_periods lsat
		    INNER JOIN [dbo].[ProductMatrix] AS am 
			    ON lsat.LocationId = am.LocationId
			    AND lsat.ProductId = am.ProductId
			    AND CAST(lsat.DtBegin AS DATE) <= am.[Date]
			    AND CAST(lsat.DtEnd AS DATE) >= am.[Date]
		    WHERE am.[Date] > DATEADD(MONTH, -@MonthCountMatrix, @DtAnalyse)
		    GROUP BY lsat.LocationId, lsat.ProductId, DtBegin
		    HAVING COUNT(*) < DATEDIFF(DAY, CAST(lsat.DtBegin AS DATE), @DtAnalyse) + 1
		) AS sel ON	
			sel.locationId = smp.LocationId
			AND sel.productID = smp.ProductId
			AND sel.DtBegin = smp.DtBegin

		/* Обрезаем начало периода отсутствия продаж по ближайшему некорректному сигналу */
		UPDATE sp
		SET sp.[DtBegin] = DATEADD(HOUR														-- round hour up
									,DATEDIFF(HOUR, 0, casv.[MaxValidationDateTime]) 
										+ IIF(DATEPART(MINUTE, casv.[MaxValidationDateTime])
												+DATEPART(SECOND, casv.[MaxValidationDateTime]) > 0
											,1
											,0
										  )
									,0)
		FROM #suspect_periods sp
			CROSS APPLY (
				SELECT MAX(sv.[ValidationDateTime]) AS [MaxValidationDateTime]
				FROM [dbo].[SignalValidations] AS sv
					INNER JOIN [dbo].[LostSalesAnalysisSignals] AS sg
						ON sg.SignalId = sv.SignalId
				WHERE sg.LocationId = sp.LocationId
					AND sg.ProductId = sp.ProductId
					AND sv.ValidationDateTime < sp.[DtEnd]
					AND sv.ValidationDateTime > sp.[DtBegin]
					AND sv.SignalValidationTypeId = 5 --некорректный сигнал
		   ) AS casv
		WHERE casv.[MaxValidationDateTime] IS NOT NULL

		-- проверяем что совсем сильно нигде не обрезалось
		DELETE FROM #suspect_periods
		FROM #suspect_periods sp
		INNER JOIN [dbo].[Locations] AS loc
			ON loc.Id = sp.LocationId
		WHERE 
			dbo.usf_WorkingHoursDiff
			(
                sp.DtBegin,
                sp.DtEnd,
                DATEPART(HOUR,loc.OpenTime),
				DATEPART(HOUR, loc.CloseTime)
			) < sp.TheshHold

        --отбрасываем те периоды, которые не заканчиваются анализируемой датой
		DELETE FROM #suspect_periods
		FROM #suspect_periods sp		
		WHERE sp.DtEnd < @DtAnalyse

        SELECT MIN([Date]) AS minDate, s.LocationId, s.ProductId
        into #test_sales
		FROM [dbo].[LocationStateDaySales] s
        join #suspect_periods sp on s.LocationId = sp.LocationId and s.ProductId = sp.ProductId
        WHERE DATEDIFF(DAY, [Date], @DtAnalyse) < @maxDayCount
        GROUP BY s.LocationId, s.ProductId

        -- удаляем новинки 
	    DELETE FROM #suspect_periods
		FROM #suspect_periods sp
		LEFT JOIN 
        #test_sales AS sel
				ON sel.LocationId = sp.LocationId
                AND sel.ProductId = sp.ProductId			
		WHERE 
			 DATEDIFF(DAY, ISNULL(sel.minDate, sp.DtBegin), sp.DtBegin) < @NewItemsDays
                
	 --   -- удаляем новинки 
	 --   DELETE FROM #suspect_periods
		--FROM #suspect_periods sp
		--LEFT JOIN 
  --      ( 
		--	SELECT MIN([Date]) AS minDate, LocationId, ProductId
		--	FROM [dbo].[LocationStateDaySales]
  --          WHERE DATEDIFF(DAY, [Date], @DtAnalyse) < @maxDayCount
  --          GROUP BY LocationId, ProductId
  --      ) AS sel
		--		ON sel.LocationId = sp.LocationId
  --              AND sel.ProductId = sp.ProductId			
		--WHERE 
		--	 DATEDIFF(DAY, ISNULL(sel.minDate, sp.DtBegin), sp.DtBegin) < @NewItemsDays
			
        IF(OBJECT_ID('tempdb..#truncated_suspect_periods') IS NOT NULL)
	    BEGIN
		    DROP TABLE #truncated_suspect_periods
	    END
 
        CREATE TABLE #truncated_suspect_periods 
        (
			LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            DtBegin SMALLDATETIME NOT NULL, 
			DtEnd SMALLDATETIME NOT NULL, 
            Price FLOAT NULL, 
            PromoAlgType TINYINT, 
            isHoliday BIT, 
            isKVI BIT, 
            isPromo BIT, 
            AbcCategory VARCHAR(1) NULL,
            SumSales REAL NULL,
            TheshHold SMALLINT,
			PriceIncreased BIT DEFAULT(0),
            PRIMARY KEY CLUSTERED(LocationId, ProductId, DtBegin)
        )        


        IF(OBJECT_ID('tempdb..#all_stores') IS NOT NULL)
	    BEGIN
		    DROP TABLE #all_stores
	    END
 
        CREATE TABLE #all_stores 
        (
            LocationId INT NOT NULL, 
            TaskCount INT NOT NULL,
            PRIMARY KEY CLUSTERED(LocationId)
        )

        INSERT INTO #all_stores(LocationId, TaskCount)
        SELECT LocationId, COUNT(*)
        FROM #suspect_periods
        GROUP BY LocationId
                      
        IF (SELECT COUNT(*) 
			FROM #all_stores AS s
				JOIN #LocationConversions AS lc
					ON lc.LocationId = s.LocationId
			--WHERE TaskCount > @SignalCount
			WHERE TaskCount > lc.[SignalCount]
			) > 0
        BEGIN

            --отбираем минимальное количество подозрений только по kvi товарам, сортируя по товарообороту
            INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased)
            SELECT rs.LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased
            FROM 
            (
                SELECT t.LocationId
                    ,t.ProductId
                    ,t.DtBegin
                    ,t.DtEnd
                    ,t.Price
                    ,t.PromoAlgType
                    ,t.isHoliday
                    ,t.isKVI
                    ,t.isPromo
                    ,t.TheshHold
                    ,lt.AbcCategory
                    ,lt.SalesAmount AS SumSales
					,t.PriceIncreased
                    ,Rank() OVER (PARTITION BY t.LocationId ORDER BY lt.SalesAmount DESC, t.ProductId ) AS Rank
                FROM #suspect_periods AS t
					JOIN [dbo].[LocationStateLastTurnover] AS lt
						ON lt.LocationId = t.LocationId
						AND lt.ProductId = t.ProductId
                WHERE lt.IsKvi = 1
            ) rs
				JOIN #LocationConversions AS lc
					ON lc.LocationId = rs.LocationId
			WHERE Rank <= lc.[SignalCount] --@SignalCount

            IF(OBJECT_ID('tempdb..#lost_stores') IS NOT NULL)
	        BEGIN
		        DROP TABLE #lost_stores
	        END
 
            CREATE TABLE #lost_stores 
            (
                LocationId INT NOT NULL, 
                LostCount INT NOT NULL,
                PRIMARY KEY CLUSTERED(LocationId)
            )

            INSERT INTO #lost_stores(LocationId, LostCount)
            SELECT s.LocationId
				  --,@SignalCount - ISNULL(sp.TaskCount, 0)
				  ,lc.[SignalCount] - ISNULL(sp.TaskCount, 0)
            FROM #all_stores AS s
				LEFT JOIN
				(
					SELECT LocationId, COUNT(*) TaskCount
					FROM #truncated_suspect_periods
					GROUP BY LocationId
				) AS sp
					ON sp.LocationId = s.LocationId
				JOIN #LocationConversions AS lc
					ON lc.LocationId = s.LocationId
            WHERE sp.LocationId IS NULL 
                --OR sp.TaskCount < @SignalCount
				OR sp.TaskCount < lc.[SignalCount]

            --если для каких-то магазинов получилось менее минимального количество подозрений, для этих магазинов мы добиваем количество подозрений до минимального товарами сначала категории A 
            IF(SELECT COUNT(*) FROM #lost_stores) > 0
            BEGIN

                INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased)
                SELECT LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased
                FROM 
                (
                    SELECT t.LocationId
                        ,t.ProductId
                        ,t.DtBegin
                        ,t.DtEnd
                        ,t.Price
                        ,t.PromoAlgType
                        ,t.isHoliday
                        ,t.isKVI
                        ,t.isPromo
                        ,t.TheshHold
                        ,lt.AbcCategory
                        ,lt.SalesAmount AS SumSales 
                        ,ls.LostCount
						,t.PriceIncreased
                        ,Rank() OVER (PARTITION BY t.LocationId ORDER BY lt.SalesAmount DESC, t.ProductId ) AS Rank
                    FROM #suspect_periods AS t
                    JOIN [dbo].[LocationStateLastTurnover] AS lt
                        ON t.LocationId = lt.LocationId
                        AND t.ProductId = lt.ProductId
                    JOIN #lost_stores ls
                        ON ls.LocationId = t.LocationId
                    WHERE lt.IsKvi = 0
                        AND lt.AbcCategory = 'A'
                ) rs 
                WHERE Rank <= LostCount

                TRUNCATE TABLE #lost_stores

                INSERT INTO #lost_stores(LocationId, LostCount)
                SELECT s.LocationId
					  --,@SignalCount - ISNULL(sp.TaskCount, 0)
					  ,lc.[SignalCount] - ISNULL(sp.TaskCount, 0)
                FROM #all_stores AS s
					LEFT JOIN 
					(
						SELECT LocationId, COUNT(*) TaskCount
						FROM #truncated_suspect_periods
						GROUP BY LocationId
					) sp
						ON sp.LocationId = s.LocationId
					JOIN #LocationConversions AS lc
						ON lc.LocationId = s.LocationId
                WHERE sp.LocationId IS NULL
                    --OR sp.TaskCount < @SignalCount
					OR sp.TaskCount < lc.[SignalCount]

                --если для каких-то магазинов получилось менее минимального количество подозрений, для этих магазинов мы добиваем количество подозрений до минимального товарами категории B 
                IF(SELECT COUNT(*) FROM #lost_stores) > 0
                BEGIN

                    INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased)
                    SELECT LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased
                    FROM 
                    (
                        SELECT t.LocationId
                            ,t.ProductId
                            ,t.DtBegin
                            ,t.DtEnd
                            ,t.Price
                            ,t.PromoAlgType
                            ,t.isHoliday
                            ,t.isKVI
                            ,t.isPromo
                            ,t.TheshHold
                            ,lt.AbcCategory
                            ,lt.SalesAmount AS SumSales
                            ,ls.LostCount
							,t.PriceIncreased
                            ,Rank() OVER (PARTITION BY t.LocationId ORDER BY lt.SalesAmount DESC, t.ProductId ) AS Rank
                        FROM #suspect_periods AS t
                        JOIN [dbo].[LocationStateLastTurnover] AS lt
                            ON t.LocationId = lt.LocationId
                            AND t.ProductId = lt.ProductId
                        JOIN #lost_stores ls
                            ON ls.LocationId = t.LocationId
                        WHERE lt.IsKvi = 0
                            AND lt.AbcCategory = 'B'
                    ) rs 
                    WHERE Rank <= LostCount

                    TRUNCATE TABLE #lost_stores

                    INSERT INTO #lost_stores(LocationId, LostCount)
                    SELECT s.LocationId
						  --,@SignalCount - ISNULL(sp.TaskCount, 0)
						  ,lc.[SignalCount] - ISNULL(sp.TaskCount, 0)
                    FROM #all_stores AS s
						LEFT JOIN 
						(
							SELECT LocationId, COUNT(*) TaskCount
							FROM #truncated_suspect_periods
							GROUP BY LocationId
						) sp
							ON sp.LocationId = s.LocationId
						JOIN #LocationConversions AS lc
							ON lc.LocationId = s.LocationId
                    WHERE sp.LocationId IS NULL 
                        --OR sp.TaskCount < @SignalCount
						OR sp.TaskCount < lc.[SignalCount]

                    --если для каких-то магазинов получилось менее минимального количество подозрений, для этих магазинов мы добиваем количество подозрений до минимального товарами категории C
                    IF(SELECT COUNT(*) FROM #lost_stores) > 0
                    BEGIN

                        INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased)
                        SELECT LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased
                        FROM 
                        (
                            SELECT t.LocationId
                                ,t.ProductId
                                ,t.DtBegin
                                ,t.DtEnd
                                ,t.Price
                                ,t.PromoAlgType
                                ,t.isHoliday
                                ,t.isKVI
                                ,t.isPromo
                                ,t.TheshHold
                                ,lt.AbcCategory
                                ,lt.SalesAmount AS SumSales
                                ,ls.LostCount
								,t.PriceIncreased
                                ,Rank() OVER (PARTITION BY t.LocationId ORDER BY lt.SalesAmount DESC, t.ProductId ) AS Rank
                            FROM #suspect_periods AS t
                            JOIN [dbo].[LocationStateLastTurnover] AS lt
                                ON t.LocationId = lt.LocationId
                                AND t.ProductId = lt.ProductId
                            JOIN #lost_stores ls
                                ON ls.LocationId = t.LocationId
                            WHERE lt.IsKvi = 0
                                AND lt.AbcCategory = 'C'
                        ) rs 
                        WHERE Rank <= LostCount

                        TRUNCATE TABLE #lost_stores

                        INSERT INTO #lost_stores(LocationId, LostCount)
                        SELECT s.LocationId
							  --,@SignalCount - ISNULL(sp.TaskCount, 0)
							  ,lc.[SignalCount] - ISNULL(sp.TaskCount, 0)
                        FROM #all_stores AS s
							LEFT JOIN 
							(
								SELECT LocationId, COUNT(*) TaskCount
								FROM #truncated_suspect_periods
								GROUP BY LocationId
							) sp
								ON sp.LocationId = s.LocationId
							JOIN #LocationConversions AS lc
								ON lc.LocationId = s.LocationId
                        WHERE sp.LocationId IS NULL 
                            --OR sp.TaskCount < @SignalCount
							OR sp.TaskCount < lc.[SignalCount]

                        --если для каких-то магазинов получилось менее минимального количество подозрений, для этих магазинов мы добиваем количество подозрений до минимального товарами без категории
                        IF(SELECT COUNT(*) FROM #lost_stores) > 0
                        BEGIN

                            INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased)
                            SELECT LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales, PriceIncreased
                            FROM 
                            (
                                SELECT t.LocationId
                                    ,t.ProductId
                                    ,t.DtBegin
                                    ,t.DtEnd
                                    ,t.Price
                                    ,t.PromoAlgType
                                    ,t.isHoliday
                                    ,t.isKVI
                                    ,t.isPromo
                                    ,t.TheshHold
                                    ,lt.AbcCategory
                                    ,lt.SalesAmount AS SumSales
                                    ,ls.LostCount
									,t.PriceIncreased
                                    ,Rank() OVER (PARTITION BY t.LocationId ORDER BY lt.SalesAmount DESC, t.ProductId ) AS Rank
                                FROM #suspect_periods AS t
                                JOIN [dbo].[LocationStateLastTurnover] AS lt
                                    ON t.LocationId = lt.LocationId
                                    AND t.ProductId = lt.ProductId
                                JOIN #lost_stores ls
                                    ON ls.LocationId = t.LocationId
                                WHERE lt.IsKvi = 0
                                    AND lt.AbcCategory IS NULL
                            ) rs 
                            WHERE Rank <= LostCount

                        END--без категории

                    END--C

                END--B

            END--A
                

            BEGIN TRY DROP TABLE #lost_stores END TRY
	        BEGIN CATCH END CATCH
        
        END
        ELSE
        BEGIN
        
            INSERT INTO #truncated_suspect_periods(LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales)
            SELECT LocationId, ProductId, DtBegin, DtEnd, Price, PromoAlgType, isHoliday, isKvi, isPromo, TheshHold, AbcCategory, SumSales
            FROM #suspect_periods

        END            

        IF(OBJECT_ID('tempdb..#last_suspect_periods') IS NOT NULL)
	    BEGIN
		    DROP TABLE #last_suspect_periods
	    END
 
        CREATE TABLE #last_suspect_periods 
        (
            LocationId INT NOT NULL, 
            ProductId INT NOT NULL, 
            DtBegin SMALLDATETIME NOT NULL, 
            PRIMARY KEY CLUSTERED(LocationId, ProductId, DtBegin)
        )

        INSERT INTO #last_suspect_periods(LocationId, ProductId, DtBegin)
        SELECT 
            LocationId
            , ProductId
            , MAX(DtBegin) DtBegin        
        FROM #truncated_suspect_periods
        GROUP BY LocationId, ProductId


		-- BEGIN  Cut by AvgClustHourSales ---
		
		--IF(OBJECT_ID('tempdb..#cluster_sales') IS NOT NULL)
	 --   BEGIN
		--    DROP TABLE #cluster_sales
	 --   END
		
		--CREATE TABLE #cluster_sales 
  --      (
  --          [LocationId] INT NOT NULL, 
  --          [ProductId] INT NOT NULL, 
  --          [DtBegin] SMALLDATETIME NOT NULL, 
  --          [SalesHoursCount] INT NULL,
		--	PRIMARY KEY CLUSTERED([LocationId], [ProductId], [DtBegin])
  --      )

		--;WITH cteCurTasks AS 
		--(
		--	SELECT tsp.LocationId
		--		  ,tsp.ProductId
		--		  ,l.StoreClusterId
		--		  ,tsp.DtBegin AS IntervalBeginTask
		--		  ,tsp.DtEnd AS IntervalEndTask
		--	FROM #truncated_suspect_periods tsp
		--		INNER JOIN Locations l (nolock)
		--			ON l.Id = tsp.LocationId
		--)
		--, cteMinmaxTime AS (
		--	SELECT MIN(t.IntervalBeginTask) AS MinDate
		--		  ,MAX(t.IntervalEndTask) AS MaxDate
		--	FROM cteCurTasks t
		--)
		--, cte_locations AS (
		--	SELECT DISTINCT 
		--		   l.[Id]
		--		  ,l.[StoreClusterId]
		--	FROM [dbo].[Locations] AS l
		--		INNER JOIN cteCurTasks AS t
		--			ON t.[StoreClusterId] = l.[StoreClusterId]
		--)
		--, cteSales AS
		--(
		--	SELECT s.ProductId
		--		  ,s.LocationId
		--		  ,s.[Datetime]
		--		  ,s.Quantity
		--		  ,s.PriceSum
		--		  ,l.StoreClusterId
		--	FROM [dbo].[LocationStateHourSales] AS s
		--		INNER JOIN cte_locations l
		--			ON s.LocationId = l.Id
		--		INNER JOIN cteMinmaxTime t
		--			ON s.[Datetime] BETWEEN t.[MinDate] AND t.[MaxDate]
		--)
		--, cteClusterSales AS
		--(
		--	SELECT t.LocationId
		--		  ,t.ProductId
		--		  ,t.IntervalBeginTask
		--		  ,s.LocationId AS ClusterLocationId
		--		  ,COUNT(s.[Datetime]) AS HoursWithSales
		--	FROM cteCurTasks t
		--		LEFT JOIN cteSales s
		--			ON s.ProductId = t.ProductId
		--			AND s.LocationId <> t.LocationId
		--			AND s.StoreClusterId = t.StoreClusterId
		--			AND s.[Datetime] >= t.IntervalBeginTask
		--			AND s.[Datetime] < t.IntervalEndTask
		--	WHERE s.[Quantity] > 0
		--		AND s.[PriceSum] > 0
		--	GROUP BY t.[LocationId]
		--			,t.[ProductId]
		--			,t.[IntervalBeginTask]
		--			,s.[LocationId]
		--)
		--, cteClusterSalesStat AS
		--(
		--	SELECT s.LocationId
		--		  ,s.ProductId
		--		  ,s.IntervalBeginTask
		--		  ,AVG(
		--			CASE 
		--				WHEN s.HoursWithSales > 0
		--					THEN s.HoursWithSales + 0.0
		--			END
		--		   ) AS [ClusterHoursWithSalesNonzeroAvg]
		--	FROM cteClusterSales s
		--	GROUP BY s.[LocationId]
		--			,s.[ProductId]
		--			,s.[IntervalBeginTask]
		--)
		--INSERT INTO #cluster_sales
		--		  ([LocationId]
		--		  ,[ProductId]
		--		  ,[DtBegin]
		--		  ,[SalesHoursCount])
		--    SELECT cs.[LocationId]
		--		  ,cs.[ProductId]
		--		  ,cs.[IntervalBeginTask] AS [DtBegin]
		--		  ,MAX(ISNULL(cs.ClusterHoursWithSalesNonzeroAvg, 0)) AS [SalesHoursCount]
		--FROM cteClusterSalesStat AS cs
		--GROUP BY cs.[LocationId]
		--		,cs.[ProductId]
		--		,cs.[IntervalBeginTask]
		
		-- END Cut by AvgClustHourSales ---

		-- вставляем результат в таски
		INSERT INTO [dbo].[LostSalesAnalysisTasks]
        (
			 [LostSalesAnalysisJobId]
			,[LocationId]
			,[ProductId] 
			,[StartDateTime]
			,[EndDateTime]
			,[LengthWorkingHours]
			,[ThresholdLengthWorkingHours]
			,[Price]
			,[LengthHours]
			,[IsMarking]
			,[IsKvi]
			,[PromoAlgType]
            ,[AbcCategory]
            ,[SumSales]
			,[PriceIncreased]
        )
		SELECT
			@JobId
			,sp.LocationId
			,sp.ProductId
			,sp.DtBegin
			,sp.DtEnd
			,dbo.usf_WorkingHoursDiff
			(
				sp.DtBegin,
				sp.DtEnd,
				DATEPART(HOUR,loc.OpenTime),
				DATEPART(HOUR, loc.CloseTime)
			)
			,sp.TheshHold
			,sp.Price
			,DATEDIFF(HOUR, IIF(sp.DtBegin = 0, 24, sp.DtBegin), IIF(sp.DtEnd = 0, 24, sp.DtEnd))
			,CASE WHEN (sp.isHoliday = 1) OR (sp.isPromo = 1)
				THEN 1
				ELSE 0
			END AS IsMarking
			,sp.isKVI
			,sp.PromoAlgType
            ,sp.AbcCategory
            ,sp.SumSales
			,sp.[PriceIncreased]
		FROM #truncated_suspect_periods AS sp
			INNER JOIN [dbo].[Locations] AS loc
				ON loc.Id = sp.[LocationId]	
			--INNER JOIN #cluster_sales AS cs
			--	ON cs.[LocationId] = sp.[LocationId]
			--	AND cs.[ProductId] = sp.[ProductId]
			--	AND cs.[DtBegin] = sp.[DtBegin]
        WHERE EXISTS (
                SELECT TOP 1 1
                FROM #last_suspect_periods AS lsp
                WHERE lsp.LocationId = sp.LocationId
                    AND lsp.ProductId = sp.ProductId
                    AND lsp.DtBegin = sp.DtBegin
            )
			--AND cs.SalesHoursCount >= @AvgClustHourSales		-- Condition for cutting by AvgClustHourSales

	DECLARE @LastSyncId INT = 
	(SELECT TOP(1) SyncId
	FROM dbo.SynchronizationDataLog (nolock)
	WHERE IsMasterDataSync = 0
	ORDER BY SyncId DESC)

	DECLARE @LastSyncDate DATETIME = 
	(SELECT EndDate
	FROM dbo.SynchronizationDataLog (nolock)
	WHERE SyncId = @LastSyncId)

	DECLARE @SignalHour INT = 
	(SELECT SignalHour 
	FROM dbo.ActiveJobs (nolock)
	WHERE Id = @JobId)

	INSERT INTO log.CalculationsLog
	(
		JobId,
		LocationCount,
		ProductCount,
		SignalHour,
		LastSyncId,
		LastSyncDate,
		SuspectCount,
		SignalCount
	)
	SELECT
		@JobId,
		sp.LocationCount,
		sp.ProductCount,
		@SignalHour,
		@LastSyncId,
		@LastSyncDate,
		SuspectCount,
		NULL
	FROM(
		SELECT 
			COUNT(DISTINCT s.LocationId) AS LocationCount,
			COUNT(DISTINCT s.ProductId) AS ProductCount,
			COUNT(*) AS SuspectCount
		FROM #truncated_suspect_periods AS s
	) as sp

	INSERT INTO log.CalculationsDetalizationLog
	(
		JobId,
		LocationId,
		SuspectCount,
		SignalCount,
		LastSyncId
	)
	SELECT
		@JobId,
		s.LocationId,
		s.SuspectCount,
		NULL,
		ousync.SyncId
	FROM (
		SELECT 
			sp.LocationId,
			COUNT(*) AS SuspectCount
		FROM #truncated_suspect_periods sp
		GROUP BY sp.LocationId
	) AS s
	OUTER APPLY(
		SELECT TOP(1) tl.SyncId
		FROM log.TransactionDataSynchronizationLocationLog as tl (nolock)
		WHERE tl.LocationId = s.LocationId
		ORDER BY tl.SyncId DESC
	) AS ousync
 

    --обновляем разбивку по субджобам для магазинов по 1 алгоритму
    UPDATE t
    SET t.LostSalesAnalysisSubJobId = sj.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[LostSalesAnalysisSubJobs] AS sj
        ON sj.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND sj.StoreId = t.LocationId
    JOIN [dbo].[LostSalesAnalisysSchemaParams] AS sp
        ON sp.SchemaId = sj.SchemaId
        AND sp.[Key] = 'AlgType'
    WHERE t.LostSalesAnalysisJobId = @JobId 
        AND sp.[Value] = 1

    --обновляем разбивку по субджобам для кластеров по 1 алгоритму
    UPDATE t
    SET t.LostSalesAnalysisSubJobId = sj.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[Locations] AS l
        ON l.Id = t.LocationId
    JOIN [dbo].[LostSalesAnalysisSubJobs] AS sj
        ON sj.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND sj.StoreGroupId = l.StoreClusterId
    JOIN [dbo].[LostSalesAnalisysSchemaParams] AS sp
        ON sp.SchemaId = sj.SchemaId
        AND sp.[Key] = 'AlgType'
    WHERE t.LostSalesAnalysisJobId = @JobId 
        AND sp.[Value] = 1
        AND t.LostSalesAnalysisSubJobId IS NULL
        
    --обновляем разбивку по субджобам для магазинов по 2 алгоритму
    UPDATE t
    SET t.LostSalesAnalysisSubJobId = sj.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[LostSalesAnalysisSubJobs] AS sj
        ON sj.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND sj.StoreId = t.LocationId
    JOIN [dbo].[LostSalesAnalisysSchemaParams] AS sp
        ON sp.SchemaId = sj.SchemaId
        AND sp.[Key] = 'AlgType'
    WHERE t.LostSalesAnalysisJobId = @JobId
        AND sp.[Value] = 2
        AND t.LostSalesAnalysisSubJobId IS NULL

    --обновляем разбивку по субджобам для кластеров по 2 алгоритму
    UPDATE t
    SET t.LostSalesAnalysisSubJobId = sj.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[Locations] AS l
        ON l.Id = t.LocationId
    JOIN [dbo].[LostSalesAnalysisSubJobs] AS sj
        ON sj.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND sj.StoreGroupId = l.StoreClusterId
    JOIN [dbo].[LostSalesAnalisysSchemaParams] AS sp
        ON sp.SchemaId = sj.SchemaId
        AND sp.[Key] = 'AlgType'
    WHERE t.LostSalesAnalysisJobId =@JobId 
        AND sp.[Value] = 2
        AND t.LostSalesAnalysisSubJobId IS NULL

    --обновляем разбивку по батчам внутри субджоба по всем парам не промо и не kvi
    UPDATE t
    SET t.LostSalesAnalysisBatchId = b.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[LostSalesAnalysisBatches] AS b
        ON b.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND b.LostSalesAnalysisSubJobId = t.LostSalesAnalysisSubJobId
    WHERE t.LostSalesAnalysisJobId = @JobId
        AND b.BatchTypeId = 1
        AND t.IsKvi = 0 AND t.PromoAlgType = 0

    --обновляем разбивку по батчам внутри субджоба по всем парам промо
    UPDATE t
    SET t.LostSalesAnalysisBatchId = b.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[LostSalesAnalysisBatches] AS b
        ON b.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND b.LostSalesAnalysisSubJobId = t.LostSalesAnalysisSubJobId
    WHERE t.LostSalesAnalysisJobId = @JobId 
        AND b.BatchTypeId = 3
        AND t.PromoAlgType != 0
        AND t.LostSalesAnalysisBatchId IS NULL

    --обновляем разбивку по батчам внутри субджоба по всем парам kvi
    UPDATE t
    SET t.LostSalesAnalysisBatchId = b.Id
    FROM [dbo].[LostSalesAnalysisTasks] AS t
    JOIN [dbo].[LostSalesAnalysisBatches] AS b
        ON b.LostSalesAnalysisJobId = t.LostSalesAnalysisJobId
        AND b.LostSalesAnalysisSubJobId = t.LostSalesAnalysisSubJobId
    WHERE t.LostSalesAnalysisJobId =@JobId
        AND b.BatchTypeId = 2
        AND t.IsKvi != 0
        AND t.LostSalesAnalysisBatchId IS NULL

	-- очищаем за собой
	BEGIN TRY DROP TABLE #promo END TRY
	BEGIN CATCH END CATCH

	BEGIN TRY DROP TABLE #kvi END TRY
	BEGIN CATCH END CATCH

	BEGIN TRY DROP TABLE #suspect_sales END TRY
	BEGIN CATCH END CATCH

	BEGIN TRY DROP TABLE #suspect_periods END TRY
	BEGIN CATCH END CATCH

	BEGIN TRY DROP TABLE #max_sale_past END TRY
    BEGIN CATCH END CATCH

    BEGIN TRY DROP TABLE #last_suspect_periods END TRY
	BEGIN CATCH END CATCH

    BEGIN TRY DROP TABLE #truncated_suspect_periods END TRY
	BEGIN CATCH END CATCH

    BEGIN TRY DROP TABLE #all_stores END TRY
	BEGIN CATCH END CATCH

	BEGIN TRY DROP TABLE #LocationConversions END TRY
	BEGIN CATCH END CATCH
	------------------------------------------------
	--BEGIN TRY DROP TABLE #cluster_sales END TRY
	--BEGIN CATCH END CATCH
	------------------------------------------------
	UPDATE [dbo].[LostSalesAnalysisJobs]
	SET [Status] = 3,
		FilledTasks = GETDATE()
	WHERE JobId = @JobId

    UPDATE [mng].[Jobs]
	SET [Status] = 3
	WHERE Id = @JobId
      
END
