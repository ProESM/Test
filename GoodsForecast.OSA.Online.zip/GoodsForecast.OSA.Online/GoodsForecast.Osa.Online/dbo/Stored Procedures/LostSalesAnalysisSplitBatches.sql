﻿--===============================
-- Разбивка батчей на пачки 
--===============================
CREATE PROCEDURE [dbo].[LostSalesAnalysisSplitBatches]
 @JobId BIGINT
AS
BEGIN

  IF(OBJECT_ID('tempdb..#tasks') IS NOT NULL)
	BEGIN
		DROP TABLE #tasks
	END
 

  CREATE TABLE #tasks
  (
    Id BIGINT
  )

   DECLARE @subJobId BIGINT
   DECLARE @batchId BIGINT
   DECLARE @locationId INT
   DECLARE @taskCount INT
   DECLARE @batchSize INT = (SELECT [Value] FROM [svc].[AnalysisParams] WHERE [Name] = 'SubBatchSize')
   DECLARE @subBatchIds TABLE (Id BIGINT)
   
   DECLARE split_cur CURSOR FOR 
   SELECT LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, LocationId, COUNT(*)
   FROM [dbo].[LostSalesAnalysisTasks] 
   WHERE LostSalesAnalysisJobId = @JobId
   GROUP BY LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, LocationId
   
   OPEN split_cur
   FETCH NEXT FROM split_cur INTO @subJobId, @batchId, @locationId, @taskCount
   WHILE @@FETCH_STATUS = 0
   BEGIN 
       WHILE @taskCount > 0
       BEGIN

           DELETE FROM @subBatchIds
           TRUNCATE TABLE #tasks

           INSERT INTO [dbo].[LostSalesAnalysisSubBatches](LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, LocationId, TaskCount)
           OUTPUT Inserted.ID INTO @subBatchIds
           VALUES (@JobId, @subJobId, @batchId, @locationId, IIF(@taskCount >= @batchSize, @batchSize, @taskCount))

           INSERT INTO #tasks (Id)
           SELECT TOP(@batchSize)  Id
           FROM [dbo].[LostSalesAnalysisTasks] 
           WHERE LostSalesAnalysisJobId = @JobId
                AND LostSalesAnalysisSubJobId = @subJobId
                AND LostSalesAnalysisBatchId = @batchId
                AND LocationId = @locationId
                AND LostSalesAnalysisSubBatchId IS NULL

           UPDATE lt
           SET LostSalesAnalysisSubBatchId = sb.Id
           FROM [dbo].[LostSalesAnalysisTasks] AS lt
           JOIN #tasks AS t
                ON t.Id = lt.Id
           CROSS JOIN @subBatchIds sb
           WHERE LostSalesAnalysisJobId = @JobId
                AND LostSalesAnalysisSubJobId = @subJobId
                AND LostSalesAnalysisBatchId = @batchId
                AND LocationId = @locationId

            SET @taskCount = @taskCount - @batchSize;

       END

        FETCH NEXT FROM split_cur INTO @subJobId, @batchId, @locationId, @taskCount
   END
   
   CLOSE split_cur
   DEALLOCATE split_cur

   BEGIN TRY DROP TABLE #tasks END TRY
   BEGIN CATCH END CATCH
END
