﻿
CREATE PROCEDURE [dbo].[MergeSignalValidationSync]
AS
   MERGE dbo.SignalValidations t
   USING etl.SignalValidations s
   ON t.SignalId = s.SignalId
   WHEN MATCHED THEN 
   UPDATE 
   SET    ValidationDateTime = s.ValidationDateTime,
          IsCorrect = s.IsCorrect,
          SignalValidationTypeId = s.SignalValidationTypeId,
          ValidationDescription = s.ValidationDescription,
          AuditorName = s.AuditorName
          WHEN NOT MATCHED THEN
   
   INSERT 
     (
       SignalId,
       ValidationDateTime,
       IsCorrect,
       SignalValidationTypeId,
       ValidationDescription,
       AuditorName
     )
   VALUES
     (
       s.SignalId,
       s.ValidationDateTime,
       s.IsCorrect,
       s.SignalValidationTypeId,
       s.ValidationDescription,
       s.AuditorName
     );
