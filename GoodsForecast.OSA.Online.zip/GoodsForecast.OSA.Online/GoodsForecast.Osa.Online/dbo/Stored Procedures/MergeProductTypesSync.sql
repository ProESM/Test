﻿
CREATE PROCEDURE   [dbo].[MergeProductTypesSync]
AS

MERGE INTO dbo.ProductTypes AS trg
USING (
	SELECT ProductTypeId AS ExternalId
		  ,Name
		  ,CAST(1 AS BIT) AS IsActive
	FROM etl.ProductTypes
) AS source
	ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
	UPDATE 
		SET trg.Name = source.Name
WHEN NOT MATCHED BY TARGET THEN
	INSERT (ExternalId
           ,Name
           ,IsActive)
	VALUES  (source.ExternalId
			,source.Name
			,source.IsActive)
WHEN NOT MATCHED BY SOURCE THEN
	UPDATE 
		SET trg.IsActive = 0;
