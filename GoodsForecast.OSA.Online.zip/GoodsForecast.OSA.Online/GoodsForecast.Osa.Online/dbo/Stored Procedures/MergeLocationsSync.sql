﻿
CREATE PROCEDURE [dbo].[MergeLocationsSync]
AS

MERGE INTO dbo.Locations AS trg
USING
(
    SELECT ss.StoreId AS ExternalId,
           ss.Name AS Name,
           ss.ShortName AS ShortName,
           sf.Id AS StoreFormatId,
           sc.Id AS StoreClusterId,
           sr.Id AS StoreRegionId,
           ss.OpenDate AS OpenDate,
           ss.Area AS Area,
           ss.OpenTime AS OpenTime,
           ss.CloseTime AS CloseTime,
           N'Store' AS TypeKey,
           CAST(1 AS BIT) AS IsActive,
           ss.Timezone AS Timezone
    FROM  etl.Stores AS ss
        INNER JOIN dbo.StoreFormats AS sf
            ON sf.ExternalId = ss.StoreFormatId
        INNER JOIN dbo.StoreClusters AS sc
            ON sc.ExternalId = ss.ClusterId
        INNER JOIN dbo.StoreRegions AS sr
            ON sr.ExternalId = ss.RegionId
) AS source
ON trg.ExternalId = source.ExternalId
   AND trg.TypeKey = source.TypeKey
WHEN MATCHED THEN
    UPDATE SET trg.Name = source.Name,
               trg.ShortName = source.ShortName,
               trg.StoreFormatId = source.StoreFormatId,
               trg.StoreClusterId = source.StoreClusterId,
               trg.StoreRegionId = source.StoreRegionId,
               trg.OpenDate = source.OpenDate,
               trg.Area = source.Area,
               trg.OpenTime = source.OpenTime,
               trg.CloseTime = source.CloseTime,
               trg.TypeKey = source.TypeKey,
               trg.IsActive = source.IsActive,
               trg.Timezone = source.Timezone
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        Name,
        ShortName,
        StoreFormatId,
        StoreClusterId,
        StoreRegionId,
        OpenDate,
        Area,
        OpenTime,
        CloseTime,
        TypeKey,
        IsActive,
        Timezone
    )
    VALUES
    (source.ExternalId, source.Name, source.ShortName, source.StoreFormatId, source.StoreClusterId,
     source.StoreRegionId, source.OpenDate, source.Area, source.OpenTime, source.CloseTime, source.TypeKey,
     source.IsActive, source.Timezone)
WHEN NOT MATCHED BY SOURCE AND trg.TypeKey = N'Store' THEN
    UPDATE SET trg.IsActive = 0;
