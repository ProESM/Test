﻿-- =============================================
-- Предрасчет промо периодов
-- =============================================
CREATE PROCEDURE dbo.UpdatePromoPeriods
AS

 SET XACT_ABORT ON 

DECLARE @dt DATE  = GETDATE()
DECLARE @StartDate DATE = DATEADD(d,-90,@dt)

 BEGIN TRAN 
    
    TRUNCATE TABLE dbo.PromoPeriods
    

    ;WITH Groups AS 
    (
        SELECT
            LocationId, 
            ProductId,
            [Date],
            DATEADD(DAY, -ROW_NUMBER() OVER (PARTITION BY LocationId, ProductId ORDER BY  [Date]), [Date]) AS grp
        FROM [dbo].[ProductMatrix]
        WHERE [Date] >= @StartDate
            AND IsPromo = 1
    )
    INSERT INTO dbo.PromoPeriods(LocationId, ProductId, DtBegin, DtEnd)
    SELECT LocationId, ProductId, MIN([Date]), MAX([Date]) 
    FROM Groups
    GROUP BY LocationId, ProductId, grp
    
COMMIT
