﻿


--=======================================================
-- Подготовка параметров по для расчета
--=======================================================
CREATE PROCEDURE [dbo].[LostSalesAnalysisJobPrepareParams]
	@JobId BIGINT
AS
BEGIN

    -- анализируемая дата - дата и время сигнала в местном времени - 1 час, т.е. дата последней синхронизации
    -- все продажи, остатки,время работы магазина  - в местном времени, поэтому работаем тоже в местном
	DECLARE @dt AS DATE
	SELECT @dt = [AnalizeDatetime] 
    FROM [dbo].[LostSalesAnalysisJobs] ls
    WHERE JobId = @JobId
    
    --часовой пояс
    DECLARE @timeZone INT
    SELECT @timeZone = aj.TimezoneId 
    FROM [dbo].[ActiveJobs] aj
    WHERE aj.Id = @JobId

    --количество дней для поиска продаж
    DECLARE @maxDayCount AS INT
	SELECT @maxDayCount = [Value] 
    FROM [svc].[AnalysisParams]
    WHERE [Name] = 'MaxDayCount'

    --период, за который в среднем дожна быть хотя бы одна продажа
    DECLARE @AvgPeriod AS INT
	SELECT @AvgPeriod = [Value] 
    FROM [svc].[AnalysisParams]
    WHERE [Name] = 'AvgPeriod'
   
    -- отбираем только те магазины, которые сегодня продавали
	INSERT INTO [dbo].[LostSalesAnalysisJobLocations]
			   ([LostSalesAnalysisJobId]
			   ,[LocationId])
	SELECT DISTINCT @JobId, LocationId
	FROM [dbo].[LocationStateDaySales] AS c
		INNER JOIN [dbo].[Locations] AS l
			ON l.[Id] = c.[LocationId]
	WHERE c.[Date] = @dt
        AND l.[Timezone] = @timeZone
		-- temporary condition for cut matrix (task OKEY-275)
		--AND l.[Id] IN (
		--	 2  -- ГМ Сыктывкар Октябрьский (Июнь)
		--	,4  -- ГМ Мурманск Шмидта
		--	,15 -- ГМ СПб Выборгское
		--	,20 -- ГМ СПб Колпино Октябрьская
		--	,26 -- ГМ СПб Богатырский_Яхтенная
		--	,34 -- ГМ Воронеж Шишкова
		--	,36 -- ГМ Липецк Европа
		--	,42 -- ГМ Москва Путилково
		--	,43 -- ГМ НН Цех Тары
		--	,46 -- ГМ Москва Дмитровское (РИО)
		--	,50 -- ГМ Москва Святоозерская (Город-3)
		--	,55 -- ГМ Краснодар Мачуги
		--	,58 -- ГМ Сочи Новая Заря (МореМолл)
		--	,60 -- ГМ Астрахань Вокзальная
		--	,65 -- ГМ Ростов Комарова
		--	,67 -- ГМ Тольятти Борковская
		--	,69 -- ГМ Красноярск Сибирский
		--	,71 -- ГМ Новосибирск Аура
		--	,73 -- ГМ Омск Энтузиастов
		--	,75 -- ГМ Екатеринбург Репина (Радуга-Парк)
		--	,77 -- ГМ Тюмень Широтная
		--)

	--EXEC rep.SaveCalculatedSignalsReport @JobId, @dt, @timeZone

	IF(OBJECT_ID('tempdb..#max_date') IS NOT NULL)
	BEGIN
		DROP TABLE #max_date
	END
 
	CREATE TABLE #max_date 
    (
        LocationId INT NOT NULL, 
        ProductId INT NOT NULL, 
        [Date] DATE NOT NULL
	    PRIMARY KEY CLUSTERED(LocationId, ProductId)
    )
    --находим последний день продажи товара для пары товар-магазин за последние 90 дней
	INSERT INTO #max_date (LocationId, ProductId, [Date])
	SELECT 
        LocationId
        ,ProductId 
        ,MAX([Date])
	FROM [dbo].[LocationStateDaySales] s
	WHERE [Date] > DATEADD(DAY, -@maxDayCount, @dt)
	    AND [Date] <= @dt
	    AND LocationId IN 
            (
                SELECT LocationId 
                FROM [dbo].[LostSalesAnalysisJobLocations] 
                WHERE LostSalesAnalysisJobId = @JobId
            )
        AND EXISTS (
                SELECT TOP 1 1
                FROM [dbo].[ProductMatrix] pm
                WHERE pm.LocationId = s.LocationId
                    AND pm.ProductId = s.ProductId
                    AND pm.[Date] = @dt
                   
            )
        AND EXISTS (
                SELECT TOP 1 1
                FROM [dbo].[LocationStateStocks] st
                WHERE st.LocationId = s.LocationId
                    AND st.ProductId = s.ProductId
                    AND st.[Datetime] = @dt
                    AND st.Quantity > 0
                   
            )
       AND NOT EXISTS (
            SELECT TOP 1 1
            FROM [dbo].[SignalValidations] AS sv
            JOIN [dbo].[LostSalesAnalysisSignals] AS sg
                ON sg.SignalId = sv.SignalId
            WHERE sg.LocationId = s.LocationId
                AND sg.ProductId = s.ProductId
                AND CAST(sv.ValidationDateTime AS DATE) = @dt
                AND sv.SignalValidationTypeId = 5 --некорректный сигнал
       )
	GROUP BY LocationId, ProductId
    
     -- отбираем продукты и магазины, по которым за период в среднем была хотя бы одна продажа и период продаж был больше одного дня
	INSERT INTO [dbo].[LostSalesAnalysisJobAssortment] (LostSalesAnalysisJobId, LocationId, ProductId, Avg28, MinDate, MaxDate, Diff)
	SELECT 
        @JobId
        ,LocationId
        ,ProductId
        ,sm/(DATEDIFF(DAY, MinDate, MaxDate)+1)
        ,MinDate
        ,MaxDate
        ,DATEDIFF(DAY, MinDate, MaxDate) + 1 
	FROM
    (
		SELECT 
            lsd.LocationId
            ,lsd.ProductId
            ,SUM(Quantity) sm
            ,DATEADD(day, -@AvgPeriod + 1, MAX(md.[Date])) MinDate
            ,MAX(lsd.[Date]) MaxDate
	    FROM [dbo].[LocationStateDaySales] lsd
	    INNER HASH JOIN #max_date md
		    ON lsd.LocationId = md.LocationId
		    AND lsd.ProductId = md.ProductId
		    AND lsd.[Date] <= md.[Date]
		    AND lsd.[Date] > DATEADD(DAY, -@AvgPeriod, md.[Date])
	    INNER HASH JOIN [dbo].[ProductMatrix] am
		    ON lsd.ProductId = am.ProductId
		    AND lsd.LocationId = am.LocationId
		    AND am.[Date] = @dt
		    AND lsd.LocationId IN 
                (
                    SELECT LocationId 
                    FROM [dbo].[LostSalesAnalysisJobLocations] 
                    WHERE LostSalesAnalysisJobId = @JobId
                )
	    GROUP BY lsd.LocationId, lsd.ProductId
	) as sel
	WHERE sm/(DATEDIFF(DAY, MinDate, MaxDate)+1) >= 1 
        AND DATEDIFF(DAY, MinDate, MaxDate) + 1 > 1

    --создаем субджобы
    INSERT INTO [dbo].[LostSalesAnalysisSubJobs](LostSalesAnalysisJobId, StoreGroupId, StoreId, SchemaId)
    SELECT @JobId,  StoreGroupId, StoreId, SchemaId 
    FROM [dbo].[SchemaBindings] AS sb

    --создаем батчи
    INSERT INTO [dbo].[LostSalesAnalysisBatches](LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, BatchTypeId)
    SELECT sj.LostSalesAnalysisJobId,  sj.Id, bt.Id
    FROM [dbo].[LostSalesAnalysisSubJobs] AS sj
    CROSS JOIN [dbo].[BatchTypes] AS bt
    WHERE sj.LostSalesAnalysisJobId = @JobId
		
	UPDATE [dbo].[LostSalesAnalysisJobs]
		SET [Status] = 2,
		JobPreparedParams = GETDATE()
	WHERE JobId = @JobId

    UPDATE [mng].[Jobs]
		SET [Status] = 2
	WHERE Id = @JobId
	
	BEGIN TRY DROP TABLE #max_date END TRY
	BEGIN CATCH END CATCH

END
