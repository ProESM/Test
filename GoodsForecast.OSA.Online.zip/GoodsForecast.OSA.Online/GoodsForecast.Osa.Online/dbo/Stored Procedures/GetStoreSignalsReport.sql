﻿
--==================================
-- Получение отчета по сигналам магазинов
--==================================
CREATE PROCEDURE [dbo].[GetStoreSignalsReport]
AS
BEGIN
SELECT DISTINCT
	CAST(s.SignalDateTime AS DATE) AS [Date], 
	loc.[ShortName] AS [StoreCode],
	loc.[Name] AS [StoreName],
	CAST((CASE WHEN pe.IsActive IS NULL THEN 0 ELSE 1 END) AS TINYINT) AS IsInPilot, 
	COUNT(DISTINCT aj.Id) AS [ReportsCount],
	COUNT(*) AS [SignalsCount],
	CAST((CASE WHEN DATEPART(HOUR, sj.Created) <> DATEPART(HOUR ,sj.JobResultsProceed) THEN 1 ELSE 0 END) AS TINYINT) AS IsLate,
	SUM(CASE WHEN v.SignalId IS NULL THEN 0 ELSE 1 END) AS SignalsWithFeedbackCount,
	SUM(CASE WHEN v.SignalId IS NOT NULL THEN 0 ELSE 1 END) AS SignalsWithoutFeedbackCount,
	FORMAT((COUNT(CASE WHEN v.SignalValidationTypeId <> 5 OR v.SignalValidationTypeId IS NULL THEN 1 END) * 1.0 / COUNT(*) * 1.0), 'N4') AS [ShopAccuracy],
	FORMAT((COUNT(CASE WHEN v.SignalValidationTypeId <> 5 AND v.SignalValidationTypeId IS NOT NULL THEN 1 END) * 1.0 / COUNT(*) * 1.0), 'N4') AS [SignalsWithFeedbackAccuracy]
FROM 
	(
		SELECT 
			l.Id,
			l.ShortName,
			l.[Name]
		FROM dbo.Locations l
		WHERE l.IsActive = 1
) AS loc 
LEFT JOIN [dbo].[LostSalesAnalysisSignals] s
	ON s.LocationId = loc.Id
LEFT JOIN dbo.SignalValidations v
	ON v.SignalId = s.SignalId
LEFT JOIN dbo.ActiveJobs aj
	ON aj.Id = s.LostSalesAnalysisJobId
LEFT JOIN dbo.LocationsInPilotExploitation pe
	ON pe.LocationId = loc.Id
INNER JOIN dbo.LostSalesAnalysisJobs sj
	ON sj.JobId = s.LostSalesAnalysisJobId
WHERE CAST(s.SignalDateTime AS DATE) = DATEADD(DAY, -1, CAST(GETDATE() AS DATE))
GROUP BY 
	loc.[ShortName], 
	CAST(s.SignalDateTime AS DATE),
	loc.[Name],
	pe.IsActive,
	sj.Created,
	sj.JobResultsProceed
ORDER BY loc.[ShortName]
END