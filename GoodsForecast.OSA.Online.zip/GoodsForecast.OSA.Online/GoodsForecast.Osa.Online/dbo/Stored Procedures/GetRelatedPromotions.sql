﻿--==================================
-- Получение промоакций по свзанным магазинам
--==================================
CREATE PROCEDURE dbo.GetRelatedPromotions
    @RelatedStores dbo.RelatedStores READONLY --Список связанных магазинов
AS
BEGIN

    CREATE TABLE #RelatedStores
    (
        LocationId INT,
        ProductId INT,
        StartDateTime DATETIME,
        EndDateTime DATETIME,
        PRIMARY KEY (LocationId, ProductId)
    )

    INSERT INTO #RelatedStores (LocationId, ProductId, StartDateTime, EndDateTime)
    SELECT t.LocationId, t.ProductId, t.StartDateTime, t.EndDateTime
    FROM @RelatedStores t

    SELECT ls.LocationId
        ,ls.ProductId
        ,ls.DtBegin
        ,ls.DtEnd
    FROM [dbo].[PromoPeriods] AS ls
    INNER JOIN #RelatedStores rs 
        ON rs.ProductId = ls.ProductId 
        AND rs.LocationId = ls.LocationId
    WHERE ls.DtEnd >= rs.StartDateTime 
        AND ls.DtBegin <= rs.EndDateTime

    DROP TABLE #RelatedStores
END
