﻿
CREATE PROCEDURE [dbo].[UpdateLocationStateAggSales]
	@SyncId INT
AS

    SET XACT_ABORT ON 
    
	DECLARE @StartSeekDay DATETIME 

	SELECT  @StartSeekDay = Cast(cast(s.StartDate AS DATE) AS DATETIME)
	FROM dbo.[SynchronizationDataLog] s
	WHERE s.SyncId = @SyncId
	

CREATE TABLE #HourSales
(
    LocationId INT NOT NULL,
    ProductId INT NOT NULL,
    Datetime DATETIME NOT NULL,
    Quantity REAL NOT NULL,
    PriceSum REAL NOT NULL,
    PRIMARY KEY CLUSTERED
    (
        Datetime,
        LocationId,
        ProductId
    )
)


CREATE TABLE #DaySales
(
    LocationId INT NOT NULL,
    ProductId INT NOT NULL,
    Date DATE NOT NULL,
    Quantity REAL NOT NULL,
    PriceSum REAL NOT NULL,
    PRIMARY KEY CLUSTERED
    (
        Date ASC,
        LocationId ASC,
        ProductId ASC
    )
)


	
	INSERT INTO #HourSales
	(
		LocationId,
		ProductId,
		Datetime,
		Quantity,
		PriceSum
	)
	SELECT c.LocationId,
		   c.ProductId,
		   DATEADD(HOUR, DATEDIFF(HOUR, 0, c.Datetime), 0) AS Datetime,
		   SUM(c.Quantity) AS Quantity,
		   SUM(c.PriceSum) AS PriceSum
	FROM dbo.LocationStateCheques c
	WHERE c.Datetime >= @StartSeekDay 
	GROUP BY LocationId,
			 ProductId,
			 DATEADD(HOUR, DATEDIFF(HOUR, 0, Datetime), 0);
			 
	INSERT INTO #DaySales
	(
		LocationId,
		ProductId,
		Date,
		Quantity,
		PriceSum
	)
	SELECT c.LocationId,
		   c.ProductId,
		   CAST(c.Datetime AS DATE) AS Date,
		   SUM(c.Quantity) AS Quantity,
		   SUM(c.PriceSum) AS PriceSum
	FROM dbo.LocationStateCheques c
	WHERE c.Datetime >= @StartSeekDay
	GROUP BY c.LocationId,
			 c.ProductId,
			 CAST(c.Datetime AS DATE);

			 
BEGIN TRAN 

	DELETE  h
	FROM dbo.LocationStateHourSales h
	WHERE h.Datetime >= @StartSeekDay
	
	
	INSERT INTO dbo.LocationStateHourSales
	(
		LocationId,
		ProductId,
		Datetime,
		Quantity,
		PriceSum
	)
	SELECT  h.LocationId,
			h.ProductId,
			h.Datetime,
			h.Quantity,
			h.PriceSum
	FROM #HourSales h 

COMMIT 

BEGIN TRAN 

	DELETE  h
		FROM dbo.LocationStateDaySales h
		WHERE h.Date >= @StartSeekDay

	INSERT INTO dbo.LocationStateDaySales
	(
		LocationId,
		ProductId,
		Date,
		Quantity,
		PriceSum
	)
	SELECT d.LocationId,
		   d.ProductId,
		   d.Date,
		   d.Quantity,
		   d.PriceSum
	FROM #daySales d

COMMIT  
