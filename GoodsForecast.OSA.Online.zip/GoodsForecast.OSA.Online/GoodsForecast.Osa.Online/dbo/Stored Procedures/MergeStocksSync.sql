﻿
 CREATE PROCEDURE  [dbo].[MergeStocksSync]
 AS 

	CREATE TABLE #LocationStateStocks
	(
		LocationId INT NOT NULL,
		ProductId INT NOT NULL,
		[Datetime] DATETIME NOT NULL,
		Quantity REAL NOT NULL,
		PRIMARY KEY CLUSTERED
		(
			[LocationId],
			ProductId,
			[Datetime]
		)
	)

	INSERT INTO #LocationStateStocks
 
	(
		LocationId,
		ProductId,
		Datetime,
		Quantity
	)
	SELECT l.Id AS LocationId,
		   pr.Id AS ProductId,
		   st.Datetime AS Datetime,
		   st.StockQuantity AS Quantity
	FROM etl.Stocks AS st
		INNER JOIN dbo.Locations AS l
			ON l.ExternalId = st.StoreId
			   AND l.TypeKey = N'Store'
		INNER JOIN dbo.Products AS pr
			ON pr.ExternalId = st.ProductId


	 INSERT INTO dbo.LocationStateStocks
	(
		LocationID,
		ProductId,
		Datetime,
		Quantity	
	)
	SELECT s.LocationId,	
		   s.ProductId,
		   s.Datetime,
		   s.Quantity
	FROM #LocationStateStocks s
	WHERE NOT EXISTS ( 
		SELECT 1 
		FROM dbo.LocationStateStocks st
		WHERE st.LocationId = s.LocationId
		 AND st.ProductId = s.ProductId
		 AND st.datetime = s.Datetime
	)
		 
