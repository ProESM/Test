﻿







CREATE PROCEDURE [dbo].[MergeLocationStateSalesSync]
    @SyncId INT 
AS
	
	DECLARE @SyncStartDate DATETIME2(0)

	SELECT @SyncStartDate = s.[StartDate]
	FROM dbo.[SynchronizationDataLog] s
	WHERE s.SyncId = @SyncId
		AND s.[IsMasterDataSync] = 0

	INSERT INTO [GFC.Projects.OSA.Online.Okey.Archive].[archive].[Sales]
           ([SyncId]
           ,[SyncCreated]
           ,[StoreId]
           ,[ProductId]
           ,[ChequeId]
           ,[Datetime]
           ,[Quantity]
           ,[PriceSum]
           ,[Created])
     SELECT @SyncId AS [SyncId]
           ,@SyncStartDate AS [SyncCreated]
           ,sl.[StoreId]
           ,sl.[ProductId]
           ,sl.[ChequeId]
           ,sl.[Datetime]
           ,sl.[Quantity]
           ,sl.[PriceSum]
           ,sl.[Created]
	FROM [etl].[Sales] AS sl

 	CREATE TABLE #LocationStateCheques
	(
		[LocationId] INT NOT NULL,
		[ProductId] INT NOT NULL,
		[ChequeId] BIGINT NOT NULL,
		[Datetime] DATETIME NOT NULL,
		[Quantity] REAL NOT NULL,
		[PriceSum] REAL NOT NULL
		PRIMARY KEY CLUSTERED
		(
		    [Datetime],
			[LocationId],
			[ProductId],
		    [ChequeId]
		)
	);

	--DECLARE  @SyncID int = 1 
	  
	DECLARE @StartSeekDay DATETIME

	SELECT @StartSeekDay = CAST(CAST(s.[StartDate] AS DATE) AS DATETIME)
	FROM dbo.[SynchronizationDataLog] s
	WHERE s.SyncId = @SyncId
		AND s.[IsMasterDataSync] = 0

    INSERT INTO #LocationStateCheques
    (
        [LocationId],
        [ProductId],
        [ChequeId],
        [Datetime],
        [Quantity],
        [PriceSum]
    )
    SELECT l.[Id] AS [LocationId]
		  ,pr.[Id] AS [ProductId]
		  ,CONVERT(BIGINT, st.[ChequeId]) AS [ChequeId]
		  ,st.[Datetime] AS [Datetime]
		  ,SUM(st.[Quantity]) AS [Quantity]
		  ,SUM(st.[PriceSum]) AS [PriceSum]
    FROM [etl].[Sales] AS st
        INNER JOIN [dbo].[Locations] AS l
            ON l.[ExternalId] = st.[StoreId]
			AND l.[TypeKey] = N'Store'
        INNER JOIN [dbo].[Products] AS pr
            ON pr.[ExternalId] = st.[ProductId]
    WHERE st.[Created] >= @StartSeekDay
	GROUP BY l.[Id]
			,pr.[Id]
			,CONVERT(BIGINT, st.[ChequeId])
			,st.[Datetime]


	--Обновляем лог по синхронизации
	UPDATE 
		log.TransactionDataSynchronizationLog
	SET 
		SalesLocationCount = s.LocationCount,
		SalesMaxDate = s.MaxDate,
		SalesMinDate = s.MinDate
	FROM (
		SELECT TOP(1)
			COUNT(DISTINCT LocationId) AS LocationCount,
			MAX([Datetime]) AS MaxDate,
			MIN([Datetime]) AS MinDate
		FROM #LocationStateCheques
	) AS s
	WHERE log.TransactionDataSynchronizationLog.SyncId = @SyncId
	
	--Получаем данные в разрезе магазинов во временную таблицу
	SELECT
		s.LocationId,
		COUNT(*) AS [RowCount],
		MAX(s.[Datetime]) AS MaxDate,
		MIN(s.[Datetime]) AS MinDate
	INTO #SynchronizationLocationData
	FROM #LocationStateCheques s
	GROUP BY s.LocationId

	--Обновляем по существующим данным
	UPDATE 
		log.TransactionDataSynchronizationLocationLog
	SET
		SalesRowCount = l.[RowCount],
		SalesMinDate = l.MinDate,
		SalesMaxDate = l.MaxDate
	FROM #SynchronizationLocationData AS l
	WHERE log.TransactionDataSynchronizationLocationLog.SyncId = @SyncId
	AND log.TransactionDataSynchronizationLocationLog.LocationId = l.LocationId

	--Пишем 0 для тех записей, которых нет в продажах
	UPDATE 
		log.TransactionDataSynchronizationLocationLog
	SET
		SalesRowCount = 0
	FROM log.TransactionDataSynchronizationLocationLog llog
	LEFT JOIN #SynchronizationLocationData AS l
		ON llog.LocationId = l.LocationId
	WHERE l.LocationId IS NULL AND llog.SyncId = @SyncId

	--Добавляем записи, если в остатках не было магазинов, которые есть в продажах
	INSERT INTO log.TransactionDataSynchronizationLocationLog
	(
		SyncId,
		LocationId,
		SalesRowCount,
		StocksRowCount,
		SalesMinDate,
		SalesMaxDate,
		StocksMinDate,
		StocksMaxDate
	)
	SELECT
		@SyncId,
		l.LocationId,
		l.[RowCount],
		0,
		l.MinDate,
		l.MaxDate,
		NULL,
		NULL
	FROM #SynchronizationLocationData l
	LEFT JOIN log.TransactionDataSynchronizationLocationLog llog
		ON l.LocationId = llog.LocationId
		AND llog.SyncId = @SyncId
	WHERE llog.LocationId IS NULL 

	DROP TABLE #SynchronizationLocationData


	MERGE INTO [dbo].[LocationStateCheques] AS trg
	USING (
		SELECT l.[LocationId]
			  ,l.[ProductId]
			  ,l.[ChequeId]
			  ,l.[Datetime]
			  ,l.[Quantity]
			  ,l.[PriceSum]
		FROM #LocationStateCheques l
	) AS source
		ON trg.[LocationId] = source.[LocationId]
		AND trg.[ProductId] = source.[ProductId]
		AND trg.[ChequeId] = source.[ChequeId]
		AND trg.[Datetime] = source.[Datetime]
	WHEN MATCHED
		THEN
			UPDATE SET trg.[Quantity] = source.[Quantity]
					  ,trg.[PriceSum] = source.[PriceSum]
	WHEN NOT MATCHED BY TARGET
		THEN
			INSERT (
				 [LocationId]
				,[ProductId]
				,[ChequeId]
				,[Datetime]
				,[Quantity]
				,[PriceSum])
			VALUES (
				 source.[LocationId]
				,source.[ProductId]
				,source.[ChequeId]
				,source.[Datetime]
				,source.[Quantity]
				,source.[PriceSum]);

 -- INSERT INTO dbo.LocationStateCheques
 --   (
 --       LocationId,
 --       ProductId,
 --       ChequeId,
 --       Datetime,
 --       Quantity,
 --       PriceSum
 --   )
	--SELECT l.LocationId,
 --          l.ProductId,
 --          l.ChequeId,
 --          l.Datetime,
 --          l.Quantity,
 --          l.PriceSum
	--FROM #LocationStateCheques l
	--WHERE NOT EXISTS 
	--(   SELECT 1
	--	FROM dbo.LocationStateCheques el
	--	WHERE l.LocationId = el.LocationId 
	--		AND l.ProductId = el.ProductId 
	--		AND L.ChequeId = EL.ChequeId
	--		AND l.Datetime = el.DateTime
	--		AND el.Datetime >= @StartSeekDay
	--)

	DELETE ss
	FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Sales] AS ss
		INNER JOIN [etl].[Sales] AS es
			ON es.[StoreId] = ss.[StoreId]
			AND es.[ProductId] = ss.[ProductId]
			AND es.[ChequeId] = ss.[ChequeId]
			AND es.[Datetime] = ss.[Datetime]
			AND es.[Created] = ss.[Created]
