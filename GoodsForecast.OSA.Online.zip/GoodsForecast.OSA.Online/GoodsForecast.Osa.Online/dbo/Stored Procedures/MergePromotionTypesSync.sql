﻿
CREATE PROCEDURE [dbo].[MergePromotionTypesSync]
AS

	MERGE INTO dbo.PromotionTypes AS trg
	USING
	(
		SELECT PromoTypeId AS ExternalId,
			   Name,
			   CAST(1 AS BIT) AS IsActive
		FROM etl.PromoTypes
	) AS source
	ON trg.ExternalId = source.ExternalId
	WHEN MATCHED THEN
		UPDATE SET trg.Name = source.Name
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
		(
			ExternalId,
			Name,
			IsActive
		)
		VALUES
		(source.ExternalId, source.Name, source.IsActive)
	WHEN NOT MATCHED BY SOURCE THEN
		UPDATE SET trg.IsActive = 0;
