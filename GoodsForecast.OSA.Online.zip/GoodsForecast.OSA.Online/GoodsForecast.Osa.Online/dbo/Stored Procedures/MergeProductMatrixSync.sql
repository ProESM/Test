﻿

CREATE PROCEDURE [dbo].[MergeProductMatrixSync]
AS
	CREATE TABLE #ProductMatrix
	(
		LocationId INT NOT NULL,
		ProductId INT NOT NULL,
		Date DATE NOT NULL,
		IsKvi BIT NOT NULL,
		IsPromo BIT NOT NULL,
		Price REAL NOT NULL,
		AbcCategory VARCHAR(1) NULL,
		PRIMARY KEY CLUSTERED
		(
			Date ASC,
			LocationId ASC,
			ProductId ASC
		)
	);
 
	INSERT INTO #ProductMatrix  
	(
		LocationId,
		ProductId,
		Date,
		IsKvi,
		IsPromo,
		Price,
		AbcCategory
	)
	SELECT l.Id AS LocationId,
		   pr.Id AS ProductId,
		   pm.Date AS Date,
		   MIN(CASE WHEN kvi.StoreId IS NOT NULL THEN 1 ELSE 0 END)  AS IsKvi,
		   MIN(CASE WHEN oapromo.IsPromo = 1 THEN 1 ELSE 0 END)  AS IsPromo,
		   pm.Price AS Price,
		   MIN(abc.ABCCategory) AS AbcCategory
	FROM etl.ProductMatrix AS pm
		INNER JOIN dbo.Locations AS l
			ON l.ExternalId = pm.StoreId
			   AND l.TypeKey = N'Store'
		INNER JOIN dbo.Products AS pr
			ON pr.ExternalId = pm.ProductId
        LEFT JOIN etl.KviProducts kvi
            ON kvi.StoreId = pm.StoreId
            AND kvi.ProductId = pm.ProductId
        LEFT JOIN etl.AbcProducts AS abc
     		 ON abc.StoreId = pm.StoreId
			  AND abc.ProductId = pm.ProductId 
		OUTER APPLY
		(
			--SELECT TOP 1
			--	   1   AS IsPromo
			--FROM etl.Promotions AS spp
			--WHERE spp.StoreId = pm.StoreId
			--	  AND spp.ProductId = pm.ProductId
			--	  AND spp.StartDate <= pm.Date
			--	  AND spp.EndDate >= pm.Date

			SELECT TOP 1
				   1   AS IsPromo
			FROM [dbo].[PromotionMatrix] AS ppi
				INNER JOIN [dbo].[Promotions] AS pp
					ON pp.[Id] = ppi.[PromotionId]
			WHERE ppi.[LocationId] = l.[Id]
				  AND ppi.[ProductId] = pr.[Id]
				  AND pp.[StartDate] <= pm.[Date]
				  AND pp.[EndDate] >= pm.[Date]
		) AS oapromo
   GROUP BY
           l.Id, 
		   pr.Id  ,
		   pm.Date  ,
		   pm.Price 
    
    DECLARE @dt DATE = GETDATE()
    ;
    WITH cteProductMatrix
    AS (
	   SELECT pm.LocationId,
			   pm.ProductId,
			   pm.Date,
			   pm.IsKvi,
			   pm.IsPromo,
			   pm.Price,
			   pm.AbcCategory
		FROM dbo.ProductMatrix pm
		WHERE pm.date = @dt
    
    )
    MERGE dbo.ProductMatrix t
    USING #ProductMatrix s 
      ON t.LocationId = s.LocationId
       AND t.productId = s.ProductId
       AND t.date = s.[Date]
    WHEN MATCHED THEN UPDATE  SET 
			IsKvi = s.IsKvi,
			IsPromo = s.IsPromo,
			Price = s.Price,
			AbcCategory = s.AbcCategory
         
    WHEN NOT MATCHED THEN INSERT 
    
        (
           LocationId,
		   ProductId,
		   Date,
		   IsKvi,
		   IsPromo,
		   Price,
		   AbcCategory
        )
        VALUES
        (
           s.LocationId,
		   s.ProductId,
		   s.Date,
		   s.IsKvi,
		   s.IsPromo,
		   s.Price,
		   s.AbcCategory 
        );
        
	DECLARE @maxDayCount AS INT
	SELECT @maxDayCount = [Value] 
	FROM [svc].[AnalysisParams]
	WHERE [Name] = 'MaxDayCount'

	DECLARE @PriceChangeLimit FLOAT;
	SELECT @PriceChangeLimit = [Value] 
	FROM [svc].[AnalysisParams]
	WHERE [Name] = 'PriceChangeLimit'

	DECLARE @DtAnalyse DATE = CAST(GETDATE() AS DATE);
	DECLARE @PromoAnalyseDate DATE = DATEADD(DAY, -@maxDayCount, CAST(@DtAnalyse AS DATE));
	DECLARE @AnalyseDate DATE = CAST(@DtAnalyse AS DATE);

	UPDATE pm
	SET [PriceIncreased] = 
		IIF((pm.[Price] - oapreviousprices.[Price]) / oapreviousprices.[Price] > @PriceChangeLimit
			,1
			,0
		)
	FROM [GFC.Projects.OSA.Online.Okey].[dbo].[ProductMatrix] AS pm
		OUTER APPLY (
			SELECT TOP 1 oapm.[Price]
			FROM [dbo].[ProductMatrix] AS oapm
			WHERE oapm.[LocationId] = pm.[LocationId]
				AND oapm.[ProductId] = pm.[ProductId]
				AND oapm.[Date] BETWEEN @PromoAnalyseDate AND @AnalyseDate
				AND oapm.[Price] IS NOT NULL
				AND oapm.[Price] <> 0
				AND oapm.[Price] <> pm.[Price]
			ORDER BY oapm.[Date] DESC
		) AS oapreviousprices
	WHERE pm.[Date] = @DtAnalyse
