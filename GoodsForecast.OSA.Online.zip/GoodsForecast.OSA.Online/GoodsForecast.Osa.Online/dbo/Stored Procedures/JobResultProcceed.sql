﻿

--======================================
-- Перенос сигналов в ПБД
--======================================
CREATE PROCEDURE [dbo].[JobResultProcceed]
    @JobId BIGINT,
    @SubJobId BIGINT = NULL,
    @BatchId BIGINT = NULL,
    @SubBatchId BIGINT = NULL
AS
BEGIN

UPDATE [dbo].[LostSalesAnalysisJobs]
	SET [Status] = 4,
	FilledJobResults = GETDATE()
WHERE JobId = @JobId

UPDATE [mng].[Jobs]
	SET [Status] = 4
WHERE Id = @JobId

--Анализируемая дата
DECLARE @AnalizeDatetime DATETIME
SELECT @AnalizeDatetime = aj.AnalizeDatetime 
FROM [dbo].[LostSalesAnalysisJobs] aj
WHERE aj.JobId = @JobId

--Дневной или ночной сигнал
DECLARE @IsDaily BIT
SELECT @IsDaily = aj.IsDaily 
FROM [dbo].[ActiveJobs] aj
WHERE aj.Id = @JobId

--Минимальное количество сигналов
DECLARE @MinSignalCount INT
SELECT @MinSignalCount = [Value]  
FROM [svc].[AnalysisParams]
WHERE [Name] = IIF(@IsDaily = 0, 'MinNightlySignalCount', 'MinDailySignalCount')

IF(OBJECT_ID('tempdb..#Results') IS NOT NULL)
BEGIN
	DROP TABLE #Results
END
CREATE TABLE #Results (
	LostSalesAnalysisTaskId BIGINT NOT NULL PRIMARY KEY,
	LostSalesAnalysisJobId BIGINT NOT NULL,    
	LocationId INT NOT NULL,
	ProductId INT NOT NULL,
    StoreExternalId NVARCHAR(32) NOT NULL,
    ProductExternaId NVARCHAR(32) NOT NULL,
	SignalDateTime DATETIME NOT NULL,
	IsKvi BIT NOT NULL,
	IsPromo BIT NOT NULL,
	AbcCategory VARCHAR(1) NULL,
	LostSalesStartDateTime DATETIME NOT NULL,
	LostSalesQuantity REAL NOT NULL,
	LostSalesMoney REAL NOT NULL
)
IF(OBJECT_ID('tempdb..#signals') IS NOT NULL)
BEGIN
	DROP TABLE #signals
END
CREATE TABLE  #signals
(
    SignalId BIGINT NOT NULL PRIMARY KEY,
    ParentId BIGINT NULL,
    IsRepeated BIT NOT NULL,
    StoreId NVARCHAR(32) NOT NULL,
    ProductId NVARCHAR(32) NOT NULL,
    LostSalesStartDateTime DATETIME NOT NULL
)

;WITH 
ResultPeriods AS 
(
    SELECT 
            rp.LostSalesAnalysisTaskId
            , rp.LostSalesAnalysisJobId
            , rp.LocationId
            , rp.ProductId
            , l.ExternalId StoreExternalId
            , p.ExternalId ProductExternaId
            , MAX(rp.Created) AS SignalDateTime
            , t.IsKvi 
            , IIF(t.PromoAlgType = 0, 0, 1) AS IsPromo
            , t.AbcCategory
            , rp.[StartDatetime] AS LostSalesStartDateTime
            , SUM(rp.Quantity) AS LostSalesQuantity
            , SUM(rp.Quantity * t.Price) AS LostSalesMoney
            , rp.Probability
			, t.PriceIncreased
        FROM [dbo].[LostSalesAnalysisResultPeriods] AS rp
        INNER JOIN [dbo].LostSalesAnalysisTasks AS t
            ON t.Id = rp.LostSalesAnalysisTaskId
            AND t.LostSalesAnalysisJobId = rp.LostSalesAnalysisJobId
        INNER JOIN [dbo].[Locations] AS l
            ON l.Id = rp.LocationId
        INNER JOIN [dbo].[Products] AS p
            ON p.Id = rp.ProductId
         WHERE rp.LostSalesAnalysisJobId = @JobId 
            AND (@SubJobId IS NULL OR t.LostSalesAnalysisSubJobId = @SubJobId)
            AND (@BatchId IS NULL OR t.LostSalesAnalysisBatchId = @BatchId)
            AND (@SubBatchId IS NULL OR t.LostSalesAnalysisSubBatchId = @SubBatchId)  
            AND rp.IsPhantom = 1 
            --не появилось продаж после начала синхронизации за час до сигнала
            AND NOT EXISTS (
                SELECT 1
                FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Sales] AS s
                WHERE p.ExternalId = s.ProductId
                    AND l.ExternalId = s.StoreId
                    AND s.[Created] >= @AnalizeDatetime
                    AND s.[Created] < DATEADD(HOUR, 1, @AnalizeDatetime)
                    AND s.[Datetime] < @AnalizeDatetime
            )
        GROUP BY  rp.LostSalesAnalysisTaskId
            , rp.LostSalesAnalysisJobId
            , rp.LocationId
            , rp.ProductId
            , l.ExternalId
            , p.ExternalId
            , t.IsKvi 
            , IIF(t.PromoAlgType = 0, 0, 1) 
            , t.AbcCategory
            , t.Price
            , rp.[StartDatetime]
            , rp.Probability
			, t.PriceIncreased
)
INSERT INTO #Results(
LostSalesAnalysisJobId
    , LostSalesAnalysisTaskId
    , LocationId
    , ProductId
    , StoreExternalId
    , ProductExternaId
    , SignalDateTime
    , IsKvi
    , IsPromo
    , AbcCategory
    , LostSalesStartDateTime
    , LostSalesQuantity
    , LostSalesMoney
)
SELECT LostSalesAnalysisJobId
    , LostSalesAnalysisTaskId
    , LocationId
    , ProductId
    , StoreExternalId
    , ProductExternaId
    , SignalDateTime
    , IsKvi
    , IsPromo
    , AbcCategory
    , LostSalesStartDateTime
    , LostSalesQuantity
    , LostSalesMoney
FROM 
(
    SELECT LostSalesAnalysisJobId
        , LostSalesAnalysisTaskId
        , LocationId
        , ProductId
        , StoreExternalId
        , ProductExternaId
        , SignalDateTime
        , IsKvi
        , IsPromo
        , AbcCategory
        , LostSalesStartDateTime
        , LostSalesQuantity
        , LostSalesMoney
        , Rank() OVER (PARTITION BY rp.LocationId ORDER BY rp.PriceIncreased, rp.Probability DESC, rp.ProductId) AS Rank 
    FROM ResultPeriods rp
) AS rs 
WHERE rs.Rank <= @MinSignalCount



INSERT INTO [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Signals] (
    ParentId, 
    StoreId, 
    ProductId, 
    SignalDateTime, 
    ABCCategory, 
    IsKVI, 
    IsPromo, 
    IsRepeated, 
    LostSalesStartDateTime, 
    LostSalesQuantity, 
    LostSalesMoney
)
OUTPUT INSERTED.SignalId, INSERTED.ParentId, INSERTED.IsRepeated, INSERTED.StoreId, INSERTED.ProductId, INSERTED.LostSalesStartDateTime
INTO #signals(SignalId, ParentId, IsRepeated, StoreId, ProductId, LostSalesStartDateTime)
SELECT 
    MAX(s.SignalId) AS ParentId
    , rp.StoreExternalId
    , rp.ProductExternaId
    , rp.SignalDateTime
    , rp.AbcCategory
    , rp.IsKvi
    , rp.IsPromo
    , IIF(MAX(s.SignalId) IS NULL, 0, 1) AS IsRepeated
    , rp.LostSalesStartDateTime
    , rp.LostSalesQuantity
    , rp.LostSalesMoney
FROM #Results AS rp
LEFT JOIN 
(
    SELECT s.SignalId
        , s.LostSalesStartDateTime
        , s.ProductId
        , s.StoreId
    FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Signals] AS s
    WHERE NOT EXISTS
    (
        SELECT 1
        FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].SignalValidations AS sv
        WHERE sv.SignalId = s.SignalId 
    )
) s
    ON rp.StoreExternalId = s.StoreId
    AND rp.ProductExternaId = s.ProductId
    AND s.LostSalesStartDateTime = rp.LostSalesStartDateTime  
GROUP BY rp.StoreExternalId 
    , rp.ProductExternaId
    , rp.SignalDateTime
    , rp.AbcCategory
    , rp.IsKvi
    , rp.IsPromo
    , rp.LostSalesStartDateTime
    , rp.LostSalesMoney
    , rp.LostSalesQuantity

INSERT INTO [dbo].[LostSalesAnalysisSignals](
	LostSalesAnalysisJobId
    , LostSalesAnalysisTaskId
    , SignalId
    , ParentId
    , IsRepeated
    , LocationId
    , ProductId
    , SignalDateTime
    , IsKvi
    , IsPromo
    , AbcCategory
    , LostSalesStartDateTime
    , LostSalesQuantity
    , LostSalesMoney)
SELECT r.LostSalesAnalysisJobId
    , r.LostSalesAnalysisTaskId
    , s.SignalId
    , s.ParentId
    , s.IsRepeated
    , r.LocationId
    , r.ProductId
    , r.SignalDateTime
    , r.IsKvi
    , r.IsPromo
    , r.AbcCategory
    , r.LostSalesStartDateTime
    , r.LostSalesQuantity
    , r.LostSalesMoney
FROM #Results r
JOIN #signals s
    ON r.ProductExternaId = s.ProductId
    AND r.StoreExternalId = s.StoreId
    AND r.LostSalesStartDateTime = s.LostSalesStartDateTime

	UPDATE log.CalculationsLog
	SET SignalCount = r.SignalCount
	FROM (
		SELECT COUNT(*) AS SignalCount
		FROM #Results
	) AS r
	WHERE log.CalculationsLog.JobId = @JobId

	UPDATE log.CalculationsDetalizationLog
	SET SignalCount = r.SignalCount
	FROM (
		SELECT res.LocationId, COUNT(*) AS SignalCount
		FROM #Results res
		GROUP BY res.LocationId
	) AS r
	WHERE log.CalculationsDetalizationLog.JobId = @JobId 
	AND log.CalculationsDetalizationLog.LocationId = r.LocationId

UPDATE [dbo].[LostSalesAnalysisJobs]
	SET [Status] = 5,
	JobResultsProceed = GETDATE()
WHERE JobId = @JobId

UPDATE [mng].[Jobs]
	SET [Status] = 5,
	EndDate = GETDATE()
WHERE Id = @JobId

BEGIN TRY DROP TABLE #signals END TRY
BEGIN CATCH END CATCH

BEGIN TRY DROP TABLE #Results END TRY
BEGIN CATCH END CATCH

END
