﻿

CREATE PROCEDURE [dbo].[StartSynchronization]
   @IsMasterDataSync BIT
AS 

IF EXISTS ( SELECT 1 
			FROM dbo.SynchronizationDataLog s
			WHERE s.IsMasterDataSync = @IsMasterDataSync
				AND s.IsRunning = 1 ) 
BEGIN 
	RAISERROR ('Ошибка. Передача данных уже запушена!',16,2);
	RETURN -1
END 

DECLARE @LastSyncStartDate DATETIME 

SELECT TOP 1  @LastSyncStartDate = s.StartDate
FROM dbo.SynchronizationDataLog  s
WHERE s.IsMasterDataSync = @IsMasterDataSync
	AND s.isRunning = 0 
	AND s.EndDate IS NOT NULL 
ORDER BY s.SyncId DESC 

IF @LastSyncStartDate IS NULL 
	SET @LastSyncStartDate = '1900-01-01'

	
--INSERT INTO dbo.[SyncTransactionaDataLog]
-- (
--      StartDate,
--      EndDate  ,
--      LastSyncStartDate ,
--      IsRunning
-- )
--SELECT 
--	 '2020-11-21',
--	 NULL,
--	 '2020-11-20',
--	 1


	 
INSERT INTO dbo.SynchronizationDataLog
 (
      StartDate,
      EndDate  ,
      LastSyncStartDate ,
      IsRunning,
      IsMasterDataSync
      
 )
SELECT 
	 GETDATE(),
	 NULL,
	 @LastSyncStartDate,
	 1,
     @IsMasterDataSync
    

SELECT SCOPE_IDENTITY() AS 'SyncId'


