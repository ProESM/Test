﻿--==================================
-- Получение остатков по свзанным магазинам
--==================================
CREATE PROCEDURE dbo.GetRelatedStocks
    @RelatedStores dbo.RelatedStores READONLY --Список связанных магазинов
AS
BEGIN

    CREATE TABLE #RelatedStores
    (
        LocationId INT,
        ProductId INT,
        StartDateTime DATETIME,
        EndDateTime DATETIME,
        PRIMARY KEY (LocationId, ProductId)
    )

    INSERT INTO #RelatedStores (LocationId, ProductId, StartDateTime, EndDateTime)
    SELECT t.LocationId, t.ProductId, t.StartDateTime, t.EndDateTime
    FROM @RelatedStores t

    SELECT ls.LocationId
        ,ls.ProductId
        ,ls.[Datetime]
        ,ls.Quantity
    FROM [dbo].[LocationStateStocks] AS ls
    INNER JOIN #RelatedStores rs 
        ON rs.ProductId = ls.ProductId 
        AND rs.LocationId = ls.LocationId
    WHERE ls.[Datetime] >= rs.StartDateTime 
        AND ls.[Datetime] < rs.EndDateTime

    DROP TABLE #RelatedStores
END
