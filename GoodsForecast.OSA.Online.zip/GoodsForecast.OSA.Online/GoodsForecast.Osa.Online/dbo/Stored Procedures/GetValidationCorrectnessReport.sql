﻿
--==================================
-- Получение отчета о правильности проверки
--==================================
CREATE PROCEDURE [dbo].[GetValidationCorrectnessReport]
AS
BEGIN
with validations as(
	select v.*,
	case
		when (SignalValidationTypeId != 6) then 1 else 0
		-- тип 6 = в магазине не было ресурса для проверки
	end as Validated,
	t.EndDatetime,
	s.SignalDateTime,
	dateadd(hour, 1, t.EndDateTime) as DateTime,
	case
		when s.SignalDateTime <= dateadd(hour, 1, t.EndDateTime)
		then 1 else 0
	end as IsSignalIntime,
	case
		when datediff(second, v.ValidationDateTime, case
			when datepart(hour, t.EndDateTime)+1 in (12, 15) then dateadd(hour, 2.5, t.EndDateTime)
			when datepart(hour, t.EndDateTime)+1 = 18 then dateadd(hour, 3, t.EndDateTime)
			else dateadd(hour, 8, t.EndDatetime)
		end) >= 0 then 1 else 0
	end as InValidationIntime
	from SignalValidations v
	left join LostSalesAnalysisSignals s on v.SignalId = s.SignalId
	left join LostSalesAnalysisTasks t on s.LostSalesAnalysisTaskId = t.Id
	where CAST(v.ValidationDateTime AS DATE) >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))
)

SELECT
	t.LocationId,
	l.ExternalId,
	l.ShortName,
	l.Name AS [ShopName],
	CAST((CASE WHEN pe.IsActive IS NULL THEN 0 ELSE 1 END) AS BIT) AS IsInPilot, 
	v.DateTime,
	count(s.SignalId) as SignalsCount,
	count(case when v.IsSignalIntime = 1 then 1 end) as SignalsIntimeCount,
	count(v.Validated) as SignalsWithAnyValidation,
	sum(cast(v.Validated as int)) as HumanValidedSignalsCount,
	sum(cast(v.Validated as int) * cast(v.InValidationIntime as int)) as HumanValidatedIntimeCount,
	sum(cast(v.IsCorrect as int) * cast(v.Validated as int)) as HumanValidatedCorrectSignalsCount,
	sum(cast(
		case when v.IsCorrect is not null then v.IsCorrect else 1 end as int)) as TotalCorrectSignalsCount,
	sum(cast(
		case when v.InValidationIntime = 1 and v.IsCorrect is not null then v.IsCorrect else 1 end as int)) as TotalCorrectIntimeSignalsCount,


	round(sum(cast(v.Validated as float)) / count(s.SignalId), 4) as HumanValidatedPart,
	round(sum(cast(v.Validated as float) * cast(v.InValidationIntime as float)) / count(s.SignalId), 4) as HumanValidatedIntimePart,
	round(sum(cast(v.IsCorrect as float) * cast(v.Validated as int))
		/ case
			when sum(cast(v.Validated as int)) != 0
			then sum(cast(v.Validated as int))
		end, 4) as HumanValidatedPrecision,
	
	round(
		sum(case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
			-- эти поля были перепутаны в определенный период времени, но Money всегда больше, чем Quantity, поэтому здесь и далее вместо LostSalesMoney эта конструкция
		end),
	2) as LostSales,
	round(
		sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(v.Validated as float)),
	2) as HumanValidatedLostSales,
	round(
		sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(v.Validated as float) * cast(v.IsCorrect as float)),
	2) as HumanValidatedCorrectLostSales,
	round(
		sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(case when v.IsCorrect is not null then v.IsCorrect else 1 end as float)),
	2) as TotalCorrectLostSales,
	round(
		sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(case when v.InValidationIntime = 1 and v.IsCorrect is not null then v.IsCorrect else 1 end as float)),
	2) as TotalCorrectIntimeLostSales,

	round(
	sum((case
		when s.LostSalesMoney > s.LostSalesQuantity
		then s.LostSalesMoney
		else s.LostSalesQuantity
	end) * cast(v.Validated as float) * cast(v.IsCorrect as float))
	/ (case
		when (sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(v.Validated as float))) != 0
		then sum((case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) * cast(v.Validated as float))
	end), 4) as HumanValidatedCorrectness,

	round(sum((case
		when s.LostSalesMoney > s.LostSalesQuantity
		then s.LostSalesMoney
		else s.LostSalesQuantity
	end) * cast(case when v.IsCorrect is not null then v.IsCorrect else 1 end as float))
	/ case
		when sum(case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) != 0
		then sum(case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end)
	end, 4) as TotalCorrectness,

	round(sum((case
		when s.LostSalesMoney > s.LostSalesQuantity
		then s.LostSalesMoney
		else s.LostSalesQuantity
	end) * cast(case when v.InValidationIntime = 1 and v.IsCorrect is not null then v.IsCorrect else 1 end as float))
	/ case
		when sum(case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end) != 0
		then sum(case
			when s.LostSalesMoney > s.LostSalesQuantity
			then s.LostSalesMoney
			else s.LostSalesQuantity
		end)
	end, 4) as TotalCorrectnessIntime,

	case
		when sum(v.IsSignalIntime) < count(s.SignalId) then 1
		else 0
	end as HasLateSignals,

  case
	when sum(cast(v.Validated as float)) / count(s.SignalId) > 0.5
		and sum(cast(v.IsCorrect as float) * cast(v.Validated as int))
			/ case
				when sum(cast(v.Validated as int)) != 0
				then sum(cast(v.Validated as int))
			end < 0.2
	then 1 else 0 end as StrangeHumanValidation,

	case
		when count(s.SignalId) > 50 and sum(cast(v.Validated as int)) < 30
		then 1 else 0 end as LowHumalValidation,

	case when count(s.SignalId) = sum(cast(v.Validated as int))
	then 1 else 0 end as FullHumanValidation,

	count(distinct v.AuditorName) as AuditorsCount

  from LostSalesAnalysisSignals s
  join LostSalesAnalysisTasks t
  on s.LostSalesAnalysisTaskId = t.Id
  left join validations v
  on s.SignalId = v.SignalId
  join Locations l on l.Id = t.LocationId
  left join dbo.LocationsInPilotExploitation pe
  on pe.LocationId = t.LocationId
  where CAST(t.EndDateTime AS DATE) = DATEADD(DAY, -1, CAST(GETDATE() AS DATE))
 group by t.LocationId, l.Name, l.ShortName, l.ExternalId, v.DateTime, pe.IsActive
 having count(v.SignalId) > 0 and sum(v.Validated) > 0
 order by t.LocationId, v.DateTime


END