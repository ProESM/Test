﻿

CREATE PROCEDURE [dbo].[MergePromotionsSync]
AS

	MERGE INTO dbo.Promotions AS trg
	USING
	(
		SELECT DISTINCT
			   IIF(LEN(p.[PromoId]) <= 11
				,p.[PromoId] + '_' + CONVERT(NVARCHAR, p.[StartDate], 112) + '_' + CONVERT(NVARCHAR, p.[EndDate], 112)
				,p.[PromoId]) AS [ExternalId]
			  ,p.[Name] AS [Name]
			  ,p.[StartDate] AS [StartDate]
			  ,p.[EndDate] AS [EndDate]
			  ,pt.[Id] AS [PromotionTypeId]
			  ,CAST(1 AS BIT) AS [IsActive]
		FROM [etl].[Promotions] AS p
			INNER JOIN [dbo].[PromotionTypes] AS pt
				ON pt.[ExternalId] = p.[PromoTypeId]
	) AS source
	ON trg.[ExternalId] = source.[ExternalId]
	WHEN MATCHED THEN
		UPDATE SET trg.ExternalId = source.ExternalId,
				   trg.Name = source.Name,
				   trg.StartDate = source.StartDate,
				   trg.EndDate = source.EndDate,
				   trg.PromotionTypeId = source.PromotionTypeId,
				   trg.IsActive = source.IsActive
	WHEN NOT MATCHED BY TARGET THEN
		INSERT
		(
			ExternalId,
			Name,
			StartDate,
			EndDate,
			PromotionTypeId,
			IsActive
		)
		VALUES
		(source.ExternalId, source.Name, source.StartDate, source.EndDate, source.PromotionTypeId, source.IsActive)
	--WHEN NOT MATCHED BY SOURCE THEN
	--	UPDATE SET trg.IsActive = 0
		;
