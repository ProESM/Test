﻿
 
CREATE PROCEDURE [dbo].[MergeProductGroupsSync]
AS
MERGE INTO dbo.ProductGroups AS trg
USING
(
    SELECT p.ProductGroupId AS ExternalId,
           p.ParentId AS ExternalParentId,
           CAST(0 AS INT) AS Level,
           p.Name AS Name,
           NULL AS ParentId,
           CAST(1 AS BIT) AS IsActive
    FROM etl.ProductGroups AS p
    WHERE p.ParentId IS NULL
) AS source
ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
    UPDATE SET trg.ExternalId = source.ExternalId,
               trg.ExternalParentId = source.ExternalParentId,
               trg.Level = source.Level,
               trg.Name = source.Name,
               trg.ParentId = source.ParentId,
               trg.IsActive = source.IsActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        ExternalParentId,
        Level,
        Name,
        ParentId,
        IsActive
    )
    VALUES
    (source.ExternalId, source.ExternalParentId, source.Level, source.Name, source.ParentId, source.IsActive);

/* Level 1 */

MERGE INTO dbo.ProductGroups AS trg
USING
(
    SELECT spg.ProductGroupId AS ExternalId,
           spg.ParentId AS ExternalParentId,
           CAST(1 AS INT) AS Level,
           spg.Name AS Name,
           pg.Id AS ParentId,
           CAST(1 AS BIT) AS IsActive
    FROM etl.ProductGroups AS spg
        INNER JOIN dbo.ProductGroups AS pg
            ON pg.ExternalId = spg.ParentId
               AND pg.Level = 0
    WHERE spg.ParentId IS NOT NULL
) AS source
ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
    UPDATE SET trg.ExternalId = source.ExternalId,
               trg.ExternalParentId = source.ExternalParentId,
               trg.Level = source.Level,
               trg.Name = source.Name,
               trg.ParentId = source.ParentId,
               trg.IsActive = source.IsActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        ExternalParentId,
        Level,
        Name,
        ParentId,
        IsActive
    )
    VALUES
    (source.ExternalId, source.ExternalParentId, source.Level, source.Name, source.ParentId, source.IsActive);

/* Level 2 */

MERGE INTO dbo.ProductGroups AS trg
USING
(
    SELECT spg.ProductGroupId AS ExternalId,
           spg.ParentId AS ExternalParentId,
           CAST(2 AS INT) AS Level,
           spg.Name AS Name,
           pg.Id AS ParentId,
           CAST(1 AS BIT) AS IsActive
    FROM etl.ProductGroups AS spg
        INNER JOIN dbo.ProductGroups AS pg
            ON pg.ExternalId = spg.ParentId
               AND pg.Level = 1
    WHERE spg.ParentId IS NOT NULL
) AS source
ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
    UPDATE SET trg.ExternalId = source.ExternalId,
               trg.ExternalParentId = source.ExternalParentId,
               trg.Level = source.Level,
               trg.Name = source.Name,
               trg.ParentId = source.ParentId,
               trg.IsActive = source.IsActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        ExternalParentId,
        Level,
        Name,
        ParentId,
        IsActive
    )
    VALUES
    (source.ExternalId, source.ExternalParentId, source.Level, source.Name, source.ParentId, source.IsActive);

/* Level 3 */

MERGE INTO dbo.ProductGroups AS trg
USING
(
    SELECT spg.ProductGroupId AS ExternalId,
           spg.ParentId AS ExternalParentId,
           CAST(3 AS INT) AS Level,
           spg.Name AS Name,
           pg.Id AS ParentId,
           CAST(1 AS BIT) AS IsActive
    FROM etl.ProductGroups AS spg
        INNER JOIN dbo.ProductGroups AS pg
            ON pg.ExternalId = spg.ParentId
               AND pg.Level = 2
    WHERE spg.ParentId IS NOT NULL
) AS source
ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
    UPDATE SET trg.ExternalId = source.ExternalId,
               trg.ExternalParentId = source.ExternalParentId,
               trg.Level = source.Level,
               trg.Name = source.Name,
               trg.ParentId = source.ParentId,
               trg.IsActive = source.IsActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        ExternalParentId,
        Level,
        Name,
        ParentId,
        IsActive
    )
    VALUES
    (source.ExternalId, source.ExternalParentId, source.Level, source.Name, source.ParentId, source.IsActive);

/* Level 4 */

MERGE INTO dbo.ProductGroups AS trg
USING
(
    SELECT spg.ProductGroupId AS ExternalId,
           spg.ParentId AS ExternalParentId,
           CAST(4 AS INT) AS Level,
           spg.Name AS Name,
           pg.Id AS ParentId,
           CAST(1 AS BIT) AS IsActive
    FROM etl.ProductGroups AS spg
        INNER JOIN dbo.ProductGroups AS pg
            ON pg.ExternalId = spg.ParentId
               AND pg.Level = 3
    WHERE spg.ParentId IS NOT NULL
) AS source
ON trg.ExternalId = source.ExternalId
WHEN MATCHED THEN
    UPDATE SET trg.ExternalId = source.ExternalId,
               trg.ExternalParentId = source.ExternalParentId,
               trg.Level = source.Level,
               trg.Name = source.Name,
               trg.ParentId = source.ParentId,
               trg.IsActive = source.IsActive
WHEN NOT MATCHED BY TARGET THEN
    INSERT
    (
        ExternalId,
        ExternalParentId,
        Level,
        Name,
        ParentId,
        IsActive
    )
    VALUES
    (source.ExternalId, source.ExternalParentId, source.Level, source.Name, source.ParentId, source.IsActive);

/* Fill HId */

WITH GroupGraph
AS (SELECT CAST('/' AS NVARCHAR(MAX)) + CAST(parent.Id AS NVARCHAR(MAX)) + CAST('/' AS NVARCHAR(MAX)) AS Path,
           parent.Id,
           parent.ParentId
    FROM dbo.ProductGroups AS parent
    WHERE parent.ParentId IS NULL
    UNION ALL
    SELECT parent.Path + CAST(child.Id AS NVARCHAR(MAX)) + CAST('/' AS NVARCHAR(MAX)) AS Path,
           child.Id,
           child.ParentId
    FROM dbo.ProductGroups AS child
        INNER JOIN GroupGraph AS parent
            ON child.ParentId = parent.Id)
UPDATE pg
SET pg.HId = HIERARCHYID::Parse(d.Path)
FROM dbo.ProductGroups AS pg
    INNER JOIN GroupGraph AS d
        ON d.Id = pg.Id;


EXEC dbo.UpdateProductAncestorGroupsSync
