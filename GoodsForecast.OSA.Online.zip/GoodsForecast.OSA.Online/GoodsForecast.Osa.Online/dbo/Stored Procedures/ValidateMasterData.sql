﻿

CREATE PROCEDURE [dbo].[ValidateMasterData] 
AS 

SELECT 1
