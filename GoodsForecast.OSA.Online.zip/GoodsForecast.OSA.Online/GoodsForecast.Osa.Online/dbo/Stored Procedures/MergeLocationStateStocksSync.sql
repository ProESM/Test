﻿




CREATE PROCEDURE [dbo].[MergeLocationStateStocksSync]
	@SyncId INT 
AS

  --DECLARE @SyncID  INT = 1

	DECLARE @SyncStartDate DATETIME2(0)

	SELECT @SyncStartDate = s.[StartDate]
	FROM dbo.[SynchronizationDataLog] s
	WHERE s.SyncId = @SyncId
		AND s.[IsMasterDataSync] = 0

	INSERT INTO [GFC.Projects.OSA.Online.Okey.Archive].[archive].[Stocks]
           ([SyncId]
           ,[SyncCreated]
           ,[StoreId]
           ,[ProductId]
           ,[Datetime]
           ,[StockQuantity]
           ,[Created])
     SELECT @SyncId AS [SyncId]
           ,@SyncStartDate AS [SyncCreated]
           ,[StoreId]
           ,[ProductId]
           ,[Datetime]
           ,[StockQuantity]
           ,[Created]
		FROM [etl].[Stocks] AS st

	CREATE TABLE #LocationStateStocks
	(
		[LocationId] INT NOT NULL,
		[ProductId] INT NOT NULL,
		[Date] DATE NOT NULL,
		[Datetime] DATETIME NOT NULL,
		[Quantity] REAL NOT NULL,
		PRIMARY KEY CLUSTERED
		(
			[LocationId],
			[ProductId],
			[Date],
			[Datetime]
		)
	);
	 
	DECLARE @StartSeekDay DATETIME

	SELECT @StartSeekDay = CAST(CAST(s.[StartDate] AS DATE) AS DATETIME)
	FROM dbo.[SynchronizationDataLog] s
	WHERE s.SyncId = @SyncId
		AND s.[IsMasterDataSync] = 0

	;WITH cteData AS 
	(
		SELECT l.[Id] AS [LocationId]
			  ,pr.[Id] AS [ProductId]
			  ,CAST(st.[Datetime] AS DATE) AS [Date]
			  ,st.[Datetime] AS [Datetime]
			  ,st.[StockQuantity] AS [Quantity]
		FROM [etl].[Stocks] AS st
			INNER JOIN [dbo].[Locations] AS l
				ON l.[ExternalId] = st.[StoreId]
				AND l.[TypeKey] = N'Store'
			INNER JOIN [dbo].[Products] AS pr
				ON pr.[ExternalId] = st.[ProductId]
		WHERE st.[Created] >= @StartSeekDay
	)
	, withMaxDatetimeData AS 
	(
		SELECT d.*
			  ,ROW_NUMBER() OVER(	PARTITION BY d.[LocationId]
												,d.[ProductId]
												,d.[Date]
									ORDER BY d.[Datetime] DESC
								) AS [RowNumber]
		FROM cteData AS d
	)
	INSERT INTO #LocationStateStocks
	(
		[LocationId],
		[ProductId],
		[Date],
		[Datetime],
		[Quantity]
	)
	--SELECT l.Id AS [LocationId],
	--	   pr.Id AS [ProductId],
	--	   CAST(st.[Datetime] AS DATE) AS [Date],
	--	   st.Datetime AS [Datetime],
	--	   st.StockQuantity AS [Quantity]
	--FROM etl.Stocks AS st
	--	INNER JOIN dbo.Locations AS l
	--		ON l.ExternalId = st.StoreId
	--		   AND l.TypeKey = N'Store'
	--	INNER JOIN dbo.Products AS pr
	--		ON pr.ExternalId = st.ProductId
	--WHERE st.[Created] >= @StartSeekDay
	SELECT d.[LocationId]
		  ,d.[ProductId]
		  ,d.[Date]
		  ,d.[Datetime]
		  ,d.[Quantity]
	FROM withMaxDatetimeData AS d
	WHERE d.[RowNumber] = 1

	INSERT INTO log.TransactionDataSynchronizationLog
	(
		SyncId,
		StocksLocationCount,
		SalesLocationCount,
		SalesMinDate,
		SalesMaxDate,
		StocksMinDate,
		StocksMaxDate
	)
	SELECT
		@SyncId,
		COUNT(DISTINCT s.LocationId),
		NULL,
		NULL,
		NULL,
		MIN(s.[Datetime]),
		MAX(s.[Datetime])
	FROM #LocationStateStocks s

	INSERT INTO log.TransactionDataSynchronizationLocationLog
	(
		SyncId,
		LocationId,
		SalesRowCount,
		StocksRowCount,
		SalesMinDate,
		SalesMaxDate,
		StocksMinDate,
		StocksMaxDate
	)
	SELECT
		@SyncId,
		s.LocationId,
		NULL,
		COUNT(*),
		NULL,
		NULL,
		MIN(s.[Datetime]),
		MAX(s.[Datetime])
	FROM #LocationStateStocks s
	GROUP BY s.LocationId

	--;WITH t
	--AS (
	--	 SELECT s.LocationId,
	--			s.ProductId,
	--			s.Datetime,
	--			s.Quantity
	--	 FROM dbo.LocationStateStocks s
	--	 WHERE s.DateTime > @startSeekDay
	--)
	--MERGE t
	MERGE [dbo].[LocationStateStocks] AS t
	USING #LocationStateStocks s
	ON s.[LocationId] = t.[LocationId]
	   AND s.[ProductId] = t.[ProductId]
	   AND s.[Date] = t.[Datetime]
	WHEN MATCHED THEN
		--UPDATE SET t.Quantity = (s.Quantity + t.Quantity)
		UPDATE SET t.Quantity = s.Quantity
	WHEN NOT MATCHED THEN
		INSERT
		(
			LocationId,
			ProductId,
			DATETIME,
			Quantity
		)
		VALUES
		(s.LocationId, s.ProductId, s.[Date], s.Quantity);
	
	DELETE ss
	FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Stocks] AS ss
		INNER JOIN [etl].[Stocks] AS es
			ON es.[StoreId] = ss.[StoreId]
			AND es.[ProductId] = ss.[ProductId]
			AND es.[Datetime] = ss.[Datetime]
			AND es.[Created] = ss.[Created]

