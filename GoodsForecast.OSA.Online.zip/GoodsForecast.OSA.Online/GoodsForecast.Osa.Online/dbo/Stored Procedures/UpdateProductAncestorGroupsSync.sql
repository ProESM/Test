﻿
--USE [master]
--GO
--ALTER DATABASE [GFC.Projects.OSA.Online.Okey] SET  READ_ONLY WITH NO_WAIT
--GO
/* Fill ProductGroupAncestorGroups */

CREATE PROCEDURE [dbo].[UpdateProductAncestorGroupsSync]
AS
DECLARE @GroupTable TABLE
(
    HId HIERARCHYID NOT NULL PRIMARY KEY,
    Id INT NOT NULL
);

INSERT INTO @GroupTable
(
    HId,
    Id
)
SELECT pg.HId,
       pg.Id
FROM  dbo.ProductGroups AS pg;

MERGE  dbo.ProductGroupAncestorGroups AS target
USING
(
    SELECT --TOP (100)
        g1.Id AS ProductGroupId,
        g2.Id AS AncestorProductGroupId,
        g2.HId.GetLevel() - 1 AS AncestorProductGroupLevel
    FROM @GroupTable AS g1
        INNER JOIN @GroupTable AS g2
            ON g1.HId.IsDescendantOf(g2.HId) = 1
--ORDER BY g1.[Id], g2.[Id]
) AS source
ON (
       target.ProductGroupId = source.ProductGroupId
       AND target.AncestorProductGroupId = source.AncestorProductGroupId
   )
WHEN NOT MATCHED THEN
    INSERT
    (
        ProductGroupId,
        AncestorProductGroupId,
        AncestorProductGroupLevel
    )
    VALUES
    (source.ProductGroupId, source.AncestorProductGroupId, source.AncestorProductGroupLevel)
WHEN NOT MATCHED BY SOURCE THEN
    DELETE;
