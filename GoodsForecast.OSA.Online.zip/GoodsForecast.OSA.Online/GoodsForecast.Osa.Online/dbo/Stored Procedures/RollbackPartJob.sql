﻿--==================================
-- Откат части расчета при перезапуске
--==================================
CREATE PROCEDURE [dbo].[RollbackPartJob]
    @JobId BIGINT,
    @Stage TINYINT
AS
BEGIN

    UPDATE mng.Jobs SET EndDate = NULL WHERE Id = @JobId

    IF @Stage = 4
    BEGIN

        DELETE s 
        FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[Signals] s
        JOIN [dbo].LostSalesAnalysisSignals p 
            ON p.SignalId = s.SignalId
        WHERE p.LostSalesAnalysisJobId =  @JobId

        DELETE p 
        FROM [dbo].LostSalesAnalysisSignals p 
        WHERE p.LostSalesAnalysisJobId =  @JobId

        UPDATE [dbo].LostSalesAnalysisJobs 
        SET JobResultsProceed = NULL, 
            MovedToHistory = NULL 
        WHERE JobId = @JobId 

    END

    IF @Stage = 3
    BEGIN

        DELETE p 
        FROM [dbo].LostSalesAnalysisResultPeriods p
        WHERE p.LostSalesAnalysisJobId = @JobId

        DELETE p 
        FROM [dbo].LostSalesAnalysisResultHourlies p 
        WHERE p.LostSalesAnalysisJobId = @JobId

        UPDATE [dbo].LostSalesAnalysisJobs 
        SET FilledJobResults = NULL 
        WHERE JobId = @JobId 

    END

    IF @Stage = 2
    BEGIN

        UPDATE [dbo].LostSalesAnalysisTasks 
        SET LostSalesAnalysisSubBatchId = NULL 
        WHERE LostSalesAnalysisJobId = @JobId

        DELETE 
        FROM [dbo].LostSalesAnalysisSubBatches 
        WHERE LostSalesAnalysisJobId = @JobId 
    END 

    IF @Stage = 1
    BEGIN

        DELETE 
        FROM [dbo].LostSalesAnalysisTasks 
        WHERE LostSalesAnalysisJobId = @JobId

        UPDATE [dbo].LostSalesAnalysisJobs 
        SET FilledTasks = NULL 
        WHERE JobId = @JobId

    END

    
    IF @Stage = 0
    BEGIN

        DELETE 
        FROM [dbo].LostSalesAnalysisBatches 
        WHERE LostSalesAnalysisJobId = @JobId 
 
        DELETE 
        FROM [dbo].LostSalesAnalysisSubJobs 
        WHERE LostSalesAnalysisJobId = @JobId

        DELETE 
        FROM [dbo].LostSalesAnalysisJobAssortment 
        WHERE LostSalesAnalysisJobId = @JobId

        DELETE
        FROM [dbo].LostSalesAnalysisJobLocations 
        WHERE LostSalesAnalysisJobId = @JobId 

        UPDATE [dbo].LostSalesAnalysisJobs 
        SET JobPreparedParams = NULL 
        WHERE JobId = @JobId

    END

END
