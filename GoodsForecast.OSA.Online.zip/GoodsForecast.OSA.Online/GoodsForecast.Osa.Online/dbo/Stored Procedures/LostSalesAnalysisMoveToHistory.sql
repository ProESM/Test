﻿

--=====================================================
-- Перенос в историю данных по расчету
--=====================================================
CREATE PROCEDURE [dbo].[LostSalesAnalysisMoveToHistory]
 @JobId BIGINT = NULL
AS
BEGIN
 
        --вызовем перенос отчета в ПБД        
        INSERT INTO [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[ConsolidatedReport](
                    [Date]
                   ,[WeekDay]
                   ,[WeekNumber]
                   ,[SignalTime]
                   ,[Month]
                   ,[Category]
                   ,[SubCategory]
                   ,[Group]
                   ,[SubGroup]
                   ,[Artikul]
                   ,[ProductName]
                   ,[IsNewItem]
                   ,[Store]
                   ,[StoreCluster]
                   ,[StoreRegion]
                   ,[SignalId]
                   ,[SignalParentId]
                   ,[IsCorrect]
                   ,[SignalValidationTypeId]
                   ,[ValidationDescription]
                   ,[ValidationDateTime]
                   ,[AuditorName]
                   ,[LostSalesQuantity]
                   ,[LostSalesMoney]
                   ,[AddSalesQuantity]
                   ,[AddSalesMoney])
			 SELECT [Date]
                   ,[WeekDay]
                   ,[WeekNumber]
                   ,[SignalTime]
                   ,[Month]
                   ,[Category]
                   ,[SubCategory]
                   ,[Group]
                   ,[SubGroup]
                   ,[Artikul]
                   ,[ProductName]
                   ,[IsNewItem]
                   ,[Store]
                   ,[Cluster]
                   ,[Region]
                   ,[SignalId]
                   ,[SignalParentId]
                   ,[IsCorrect]
                   ,[SignalValidationTypeId]
                   ,[ValidationDescription]
                   ,[ValidationDateTime]
                   ,[AuditorName]
                   ,[LostSalesQuantity]
                   ,[LostSalesMoney]
                   ,[AddSalesQuantity]
                   ,[AddSalesMoney]
        FROM [dbo].[ConsolidatedReport] cr
        WHERE NOT EXISTS (
                SELECT 1
                FROM [GFC.Projects.OSA.Online.Okey.Stg].[dbo].[ConsolidatedReport] stg
                WHERE cr.SignalId = stg.SignalId
            )
            
	BEGIN TRY

    BEGIN TRAN


       INSERT INTO [history].[LostSalesAnalysisSignals]
           (LostSalesAnalysisTaskId, LostSalesAnalysisJobId, SignalId, ParentId, IsRepeated, LocationId, ProductId, SignalDateTime, IsKvi, IsPromo, AbcCategory, 
                LostSalesStartDateTime, LostSalesQuantity, LostSalesMoney)
		SELECT
			LostSalesAnalysisTaskId, LostSalesAnalysisJobId, SignalId, ParentId, IsRepeated, LocationId, ProductId, SignalDateTime, IsKvi, IsPromo, AbcCategory, 
                LostSalesStartDateTime, LostSalesQuantity, LostSalesMoney
		FROM [dbo].[LostSalesAnalysisSignals]
        WHERE SignalDateTime >= DATEADD(DAY, -1, CAST(GETDATE() AS DATE))

       INSERT INTO [history].[LostSalesAnalysisResultPeriods]
           (LostSalesAnalysisTaskId, LostSalesAnalysisJobId, LocationId, ProductId, StartDatetime, EndDatetime, Probability, HoursCount, Quantity, Created, IsPhantom)
		SELECT
			LostSalesAnalysisTaskId, LostSalesAnalysisJobId, LocationId, ProductId, StartDatetime, EndDatetime, Probability, HoursCount, Quantity, Created, IsPhantom
		FROM [dbo].[LostSalesAnalysisResultPeriods]

		INSERT INTO [history].[LostSalesAnalysisResultHourlies]
           (LostSalesAnalysisTaskId, LostSalesAnalysisJobId, LocationId, ProductId, [Datetime], Probability, Quantity, Created, IsPhantom, IsCalculatedInTsa)
		SELECT
			LostSalesAnalysisTaskId, LostSalesAnalysisJobId, LocationId, ProductId, [Datetime], Probability, Quantity, Created, IsPhantom, IsCalculatedInTsa
		FROM [dbo].[LostSalesAnalysisResultHourlies]

        INSERT INTO [history].[LostSalesAnalysisSubJobs]
           (Id, LostSalesAnalysisJobId, StoreGroupId, StoreId, SchemaId)
		SELECT
			Id, LostSalesAnalysisJobId, StoreGroupId, StoreId, SchemaId
		FROM [dbo].[LostSalesAnalysisSubJobs] b
        WHERE NOT EXISTS (
            SELECT 1 
            FROM [history].[LostSalesAnalysisSubJobs] h
            WHERE h.Id = b.Id)

        INSERT INTO [history].[LostSalesAnalysisBatches]
           (Id, LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, BatchTypeId)
		SELECT
			Id, LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, BatchTypeId
		FROM [dbo].[LostSalesAnalysisBatches] b
        WHERE NOT EXISTS (
            SELECT 1 
            FROM [history].[LostSalesAnalysisBatches] h
            WHERE h.Id = b.Id)

        INSERT INTO [history].[LostSalesAnalysisSubBatches]
           (Id, LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, TaskCount, LocationId)
		SELECT
			Id, LostSalesAnalysisJobId, LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, TaskCount, LocationId
		FROM [dbo].[LostSalesAnalysisSubBatches] b
        WHERE NOT EXISTS (
            SELECT 1 
            FROM [history].[LostSalesAnalysisSubBatches] h
            WHERE h.Id = b.Id)
				
		INSERT INTO [history].[LostSalesAnalysisTasks]
           (Id, LostSalesAnalysisJobId, LocationId, ProductId, StartDateTime, EndDateTime, 
           Price, LengthWorkingHours, ThresholdLengthWorkingHours, Created, LengthHours, IsMarking, PromoAlgType, IsKvi,
           LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, LostSalesAnalysisSubBatchId, AbcCategory, SumSales)
		SELECT
			Id, LostSalesAnalysisJobId, LocationId, ProductId, StartDateTime, EndDateTime, 
            Price, LengthWorkingHours, ThresholdLengthWorkingHours, Created, LengthHours, IsMarking, PromoAlgType, IsKvi,
            LostSalesAnalysisSubJobId, LostSalesAnalysisBatchId, LostSalesAnalysisSubBatchId, AbcCategory, SumSales
		FROM [dbo].[LostSalesAnalysisTasks] b
        WHERE NOT EXISTS (
            SELECT 1 
            FROM [history].[LostSalesAnalysisTasks] h
            WHERE h.Id = b.Id)

        INSERT INTO [history].[LostSalesAnalysisJobAssortment]
           (LostSalesAnalysisJobId, LocationId, ProductId, Avg28, MinDate, MaxDate, Diff)
		SELECT
			LostSalesAnalysisJobId, LocationId, ProductId, Avg28, MinDate, MaxDate, Diff
		FROM [dbo].[LostSalesAnalysisJobAssortment]

        INSERT INTO [history].[LostSalesAnalysisJobLocations]
           (LostSalesAnalysisJobId, LocationId)
		SELECT
			LostSalesAnalysisJobId, LocationId
		FROM [dbo].[LostSalesAnalysisJobLocations]

		--------------------------------------------

        DELETE FROM [dbo].[LostSalesAnalysisSignals] WHERE SignalDateTime < DATEADD(MONTH, -1, CAST(GETDATE() AS DATE))

		TRUNCATE TABLE [dbo].[LostSalesAnalysisResultPeriods]

		TRUNCATE TABLE [dbo].[LostSalesAnalysisResultHourlies]

		DELETE t 
        FROM [dbo].[LostSalesAnalysisTasks] t
        INNER JOIN [dbo].[LostSalesAnalysisSignals] s
            ON t.Id = s.LostSalesAnalysisTaskId
        WHERE s.SignalDateTime < DATEADD(MONTH, -1, CAST(GETDATE() AS DATE))      
        
		DELETE sb 
        FROM [dbo].[LostSalesAnalysisSubBatches] sb
        INNER JOIN [dbo].[LostSalesAnalysisTasks] t
            ON t.LostSalesAnalysisSubBatchId = sb.Id
        INNER JOIN [dbo].[LostSalesAnalysisSignals] s
            ON t.Id = s.LostSalesAnalysisTaskId
        WHERE s.SignalDateTime < DATEADD(MONTH, -1, CAST(GETDATE() AS DATE))  
        
		DELETE b 
        FROM [dbo].[LostSalesAnalysisBatches] b
        INNER JOIN [dbo].[LostSalesAnalysisTasks] t
            ON t.LostSalesAnalysisBatchId = b.Id
        INNER JOIN [dbo].[LostSalesAnalysisSignals] s
            ON t.Id = s.LostSalesAnalysisTaskId
        WHERE s.SignalDateTime < DATEADD(MONTH, -1, CAST(GETDATE() AS DATE)) 
        
		DELETE sj
        FROM [dbo].[LostSalesAnalysisSubJobs] sj
        INNER JOIN [dbo].[LostSalesAnalysisTasks] t
            ON t.LostSalesAnalysisSubJobId = sj.Id
        INNER JOIN [dbo].[LostSalesAnalysisSignals] s
            ON t.Id = s.LostSalesAnalysisTaskId
        WHERE s.SignalDateTime < DATEADD(MONTH, -1, CAST(GETDATE() AS DATE)) 

		TRUNCATE TABLE [dbo].[LostSalesAnalysisJobAssortment]

		TRUNCATE TABLE [dbo].[LostSalesAnalysisJobLocations]

      --  IF @JobId IS NOT NULL
		    --UPDATE [dbo].[LostSalesAnalysisJobs]
			   -- SET [Status] = 6,
			   -- MovedToHistory = GETDATE()
		    --WHERE JobId = @JobId

		UPDATE j
		SET j.[Status] = 6,
			j.[MovedToHistory] = GETDATE()
		FROM [dbo].[LostSalesAnalysisJobs] AS j
		WHERE CAST(j.[AnalizeDatetime] AS DATE) = DATEADD(DAY, -1, CAST(GETDATE() AS DATE))


        COMMIT TRAN       

	END TRY
	BEGIN CATCH
		ROLLBACK TRAN
	END CATCH
END
